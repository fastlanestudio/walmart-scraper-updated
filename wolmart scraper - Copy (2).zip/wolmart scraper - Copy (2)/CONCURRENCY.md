# Concurrency, Throughput, and Anti-Bot Pacing Architecture

## Core Philosophy: Anti-Bot Defense Trumps Raw Speed

Walmart's perimeter defense (historically PerimeterX / HUMAN Security) actively analyzes:
1. **TLS Fingerprint & HTTP/2 Frames**: Handled by `curl_cffi` using the `impersonate="chrome124"` profile.
2. **IP-Level Request Frequency & Concurrency**: Bursting or hammering any single IP triggers rate-limiting (HTTP 429), access denial (HTTP 403), or PerimeterX CAPTCHA challenges (`#px-captcha`, "Robot or human?").

**Golden Rule**: *Speed and not-getting-blocked are both hard requirements. If they conflict, blocking risk wins every time.*
If live telemetry indicates that scraping runs are too slow, the remedy is **adding more proxies**, never increasing request pacing beyond safe per-proxy thresholds.

---

## Safe Concurrency & Throughput Formulas

Rather than hardcoding arbitrary concurrency limits (e.g., 50 or 100 threads), `WalmartScraper` dynamically computes and logs safe concurrency based strictly on the number of distinct proxy endpoints available in the pool.

$$\text{Total Safe Concurrency} = N_{\text{proxies}} \times \text{limit}_{\text{per\_proxy\_concurrency}}$$

$$\text{Total Safe Throughput (RPM)} = N_{\text{proxies}} \times \text{limit}_{\text{per\_proxy\_rpm}}$$

### Default Conservative Parameters

| Parameter | Default Value | Rationale |
| :--- | :--- | :--- |
| `DEFAULT_PER_PROXY_CONCURRENCY` | `1` | Strictly one in-flight request per IP. Overlapping parallel requests on the same IP are an immediate red flag for bot detection systems. |
| `DEFAULT_MAX_REQUESTS_PER_MINUTE_PER_PROXY` | `6.0` req/min | Conservative single-digit rate (1 request every 10 seconds per IP). Keeps traffic well below anomaly-detection thresholds. |
| `DEFAULT_COOLDOWN_SECONDS` | `60.0`s | Quarantine duration when an IP triggers an HTTP 403/429 or CAPTCHA challenge, scaled with exponential backoff on repeat offenses. |
| `MAX_RETRIES_PER_REQUEST` | `3` | Number of attempts routed across alternate proxies when an IP gets challenged or fails. |

### Concrete Examples

- **1 Proxy / Direct IP**:
  - Safe Concurrency = $1 \times 1 = 1$ in-flight request
  - Safe Throughput = $1 \times 6.0 = 6.0$ requests/minute (360 requests/hour)
- **10 Proxies**:
  - Safe Concurrency = $10 \times 1 = 10$ in-flight requests
  - Safe Throughput = $10 \times 6.0 = 60.0$ requests/minute (3,600 requests/hour)
- **50 Proxies**:
  - Safe Concurrency = $50 \times 1 = 50$ in-flight requests
  - Safe Throughput = $50 \times 6.0 = 300.0$ requests/minute (18,000 requests/hour)

At startup, `WalmartScraper` logs these calculated values:
```text
ProxyPool initialized: 10 distinct proxy slots | Per-proxy limit: 1 in-flight, 6.0 req/min (min interval: 10.0s) | TOTAL SAFE CONCURRENCY: 10 max in-flight requests | TOTAL SAFE THROUGHPUT: 60.0 requests/min
```

---

## Why Per-Proxy Limits Instead of a Global Limit

A global semaphore (e.g. `asyncio.Semaphore(50)`) does **not** protect individual proxy IPs. If the event loop schedules multiple requests back-to-back through the same proxy connection, that IP bursts 10-20 requests in a split second, triggering instant PerimeterX blocks.

In `walmart/scraper.py`:
- Each proxy IP is managed by an independent `ProxySlot`.
- Each `ProxySlot` owns:
  1. A dedicated `curl_cffi.requests.AsyncSession` for connection pooling and HTTP/2 multiplexing (never recreated per request).
  2. Its own `asyncio.Semaphore(per_proxy_concurrency)`.
  3. Its own token-bucket / interval pacing lock (`pace()`), ensuring a minimum delay of $\frac{60}{\text{RPM}}$ seconds between consecutive requests on that specific IP.

---

## Pre-Parse Block Detection & Signal-Responsive Backoff

Requests undergo strict pre-parse verification via `check_response_for_challenge(status_code, html, url)`:
1. **HTTP 403 / 429**: Treated as anti-bot blocks, raising `ChallengePage`.
2. **HTTP 200 with Challenge Signatures**: Any response containing `#px-captcha`, `client.perimeterx.net`, `_pxAppId`, `Robot or human?`, or dialog signatures immediately raises `ChallengePage`. Challenge HTML is **never** passed to JSON or selectolax parsers.
3. **Quarantine & Alternate Proxy Rotation**:
   - The challenged `ProxySlot` is placed into cooldown (`cooldown_until = now + cooldown_duration * 2^(blocks - 1)`).
   - The retry is immediately routed to an **alternative** non-cooling proxy slot in the pool rather than hammering the challenged IP again.

---

## Where to Tune Rates Once Telemetry Exists

All pacing and concurrency parameters are exposed as constants at the top of [walmart/scraper.py](file:///c:/Users/ASUS/Downloads/$700%20scraper/wolmart%20scraper/walmart/scraper.py) and can also be overridden directly when instantiating `WalmartScraper`:

```python
from walmart.scraper import WalmartScraper

scraper = WalmartScraper(
    proxies=["http://user:pass@proxy1:8080", "http://user:pass@proxy2:8080"],
    max_requests_per_minute_per_proxy=8.0,  # Tune here (e.g. 6.0 -> 8.0 or 10.0)
    per_proxy_concurrency=1,               # Tune here (1 is safest, 2 max if telemetry allows)
    cooldown_seconds=90.0,                 # Quarantine duration on challenge
    impersonate="chrome124",               # Browser TLS fingerprint
)
```

### Tuning Guidelines from Live Testing:

1. **If Challenge Rate > 1%**:
   - Reduce `max_requests_per_minute_per_proxy` (e.g., from 6.0 down to 4.0).
   - Ensure `per_proxy_concurrency` remains at `1`.
   - Increase `cooldown_seconds` (e.g., from 60s to 120s).
2. **If Challenge Rate is Near 0% Across Multiple Runs**:
   - Safely experiment with nudging `max_requests_per_minute_per_proxy` incrementally (e.g., from 6.0 to 8.0, then 10.0).
   - If higher collection throughput is required, **increase the proxy pool size** ($N$) rather than pushing single-IP rates beyond 10-12 RPM.
