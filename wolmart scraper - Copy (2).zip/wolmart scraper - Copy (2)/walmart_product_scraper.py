#!/usr/bin/env python3
"""
walmart_product_scraper.py — ScrapeOps-aligned Product Scraper for Walmart.com.

Follows the ScrapeOps decoupled crawler+scraper architecture:
- Reads product URLs from a JSONL file produced by walmart_crawler.py, or accepts a single URL via CLI.
- Fetches HTML through ScrapeOps Proxy Aggregator (https://proxy.scrapeops.io/v1/)
  or ScrapeOps Residential Proxy (residential-proxy.scrapeops.io:8181).
- Extracts product records using high-speed embedded JSON (__NEXT_DATA__) + selectolax fallback.
- Strictly validates outputs into core.schema.ProductRecord and classifies deals via core.deal_classifier.
- Outputs records into a JSONL file and optionally upserts into SQLite (data/walmart.db).

Usage:
    python walmart_product_scraper.py --urls-file walmart_product_urls.jsonl --output walmart_products.jsonl
    python walmart_product_scraper.py --url "https://www.walmart.com/ip/10315355" --output single.jsonl
"""
import argparse
import asyncio
import json
import logging
import os
import sys
from urllib.parse import urlencode
from typing import Optional

from curl_cffi.requests import AsyncSession
from core.schema import ProductRecord
from core.store import StoreDB
from walmart.scraper import (
    WalmartScraper,
    ProxyPool,
    _extract_embedded_json,
    _extract_product_from_json,
    _extract_missing_fields_via_selectolax,
    check_response_for_challenge,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("walmart_product_scraper")

SCRAPEOPS_PROXY_API = "https://proxy.scrapeops.io/v1/"
SCRAPEOPS_RESIDENTIAL_HOST = "residential-proxy.scrapeops.io:8181"


def get_scrapeops_api_key(cli_key: Optional[str] = None) -> str:
    """Read ScrapeOps API key from CLI argument, environment, or Claude config."""
    if cli_key:
        return cli_key.strip()
    env_key = os.environ.get("SCRAPEOPS_API_KEY")
    if env_key:
        return env_key.strip()

    claude_settings = os.path.expanduser("~/.claude/settings.json")
    if os.path.exists(claude_settings):
        try:
            with open(claude_settings, "r", encoding="utf-8") as f:
                settings = json.load(f)
                key = settings.get("env", {}).get("SCRAPEOPS_API_KEY")
                if key:
                    return key.strip()
        except Exception:
            pass
    return ""


async def scrape_single_product(
    scraper: WalmartScraper,
    url: str,
    api_key: str = "",
    use_residential_proxy: bool = False,
    store_info: Optional[dict] = None,
    category: str = "Grocery",
    sub_category: str = "Products",
    zipcode: str = "10001",
) -> Optional[ProductRecord]:
    """
    Fetch and parse a single Walmart product using ScrapeOps or configured proxy pool.
    """
    store_meta = store_info or {"store_name": "Walmart Secaucus Supercenter", "store_location": "Secaucus, NJ"}
    html = None

    # If using ScrapeOps Proxy API endpoint directly
    if api_key and not use_residential_proxy:
        proxy_params = {
            "api_key": api_key,
            "url": url,
            "residential": "true",
            "country": "us",
        }
        api_url = f"{SCRAPEOPS_PROXY_API}?{urlencode(proxy_params)}"
        async with AsyncSession(timeout=45) as session:
            resp = await session.get(api_url)
            if resp.status_code == 200:
                html = resp.text
            else:
                logger.warning("ScrapeOps Proxy API returned HTTP %s for %s", resp.status_code, url)
                return None

    # Scrape via WalmartScraper (which handles proxy pooling, challenge detection, and extraction)
    record = await scraper.scrape_product(
        url=url,
        store_info=store_meta,
        category=category,
        sub_category=sub_category,
        zipcode=zipcode,
        html=html,
    )
    return record


async def process_urls(
    urls: list[str],
    output_file: str,
    api_key: str = "",
    use_residential_proxy: bool = False,
    concurrency: int = 2,
    db_path: Optional[str] = None,
    zipcode: str = "10001",
):
    """
    Process list of product URLs with bounded concurrency, stream to JSONL, and optionally save to DB.
    """
    # Configure proxy pool
    proxies = []
    if api_key and use_residential_proxy:
        proxies.append(f"http://scrapeops:{api_key}@{SCRAPEOPS_RESIDENTIAL_HOST}")

    scraper = WalmartScraper(
        proxies=proxies if proxies else None,
        per_proxy_concurrency=concurrency,
        max_requests_per_minute_per_proxy=10.0 if api_key else 6.0,
    )

    db = StoreDB(db_path) if db_path else None
    run_id = f"scrapeops_{zipcode}"
    if db:
        db.begin_run(run_id, mode="scrapeops", store_zipcode=zipcode)

    out_dir = os.path.dirname(output_file)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)

    store_info = await scraper.select_store(zipcode)
    semaphore = asyncio.Semaphore(concurrency)
    scraped_count = 0
    failed_count = 0

    with open(output_file, "w", encoding="utf-8") as f_out:
        async def worker(u: str):
            nonlocal scraped_count, failed_count
            async with semaphore:
                try:
                    rec = await scrape_single_product(
                        scraper=scraper,
                        url=u,
                        api_key=api_key,
                        use_residential_proxy=use_residential_proxy,
                        store_info=store_info,
                        zipcode=zipcode,
                    )
                    if rec:
                        rec_dict = rec.to_dict()
                        f_out.write(json.dumps(rec_dict) + "\n")
                        f_out.flush()
                        scraped_count += 1
                        if db:
                            p_key = db._product_key(rec_dict)
                            db.upsert_product(p_key, run_id, rec_dict, is_test=0, data_source="scrapeops")
                        logger.info("[%d/%d] Scraped: %s (%s)", scraped_count, len(urls), rec.product_title[:35], rec.regular_price)
                    else:
                        failed_count += 1
                except Exception as e:
                    failed_count += 1
                    logger.warning("Error scraping %s: %s", u, e)

        tasks = [worker(url) for url in urls]
        await asyncio.gather(*tasks)

    if db:
        db.finish_run(run_id, status="done")

    logger.info("Scraping finished. Successfully extracted %d records (%d failed/excluded) -> %s", scraped_count, failed_count, output_file)


def main():
    parser = argparse.ArgumentParser(description="ScrapeOps Walmart Product Details Scraper")
    parser.add_argument("--urls-file", help="JSONL file of product URLs (from walmart_crawler.py)")
    parser.add_argument("--url", help="Single product URL to scrape")
    parser.add_argument("--output", default="walmart_products.jsonl", help="Output JSONL path (default: walmart_products.jsonl)")
    parser.add_argument("--db", help="Optional SQLite database path to save records (e.g. data/walmart.db)")
    parser.add_argument("--concurrency", type=int, default=2, help="Concurrency limit (default: 2)")
    parser.add_argument("--zipcode", default="10001", help="Store location zip code (default: 10001)")
    parser.add_argument("--api-key", help="ScrapeOps API key (overrides SCRAPEOPS_API_KEY env)")
    parser.add_argument("--residential", action="store_true", help="Use ScrapeOps Residential Proxy tunnel instead of Proxy API")
    args = parser.parse_args()

    api_key = get_scrapeops_api_key(args.api_key)
    if api_key:
        logger.info("ScrapeOps proxy enabled (Key: %s••••••••)", api_key[:6])
    else:
        logger.info("No ScrapeOps API key found — running in direct/curl_cffi mode")

    urls_to_scrape = []
    if args.url:
        urls_to_scrape.append(args.url.strip())
    elif args.urls_file:
        if not os.path.exists(args.urls_file):
            logger.error("URLs file not found: %s", args.urls_file)
            sys.exit(1)
        with open(args.urls_file, "r", encoding="utf-8") as f:
            for line in f:
                line_str = line.strip()
                if not line_str:
                    continue
                try:
                    data = json.loads(line_str)
                    u = data.get("url") or data.get("canonicalUrl")
                    if u:
                        urls_to_scrape.append(u.strip())
                except json.JSONDecodeError:
                    if line_str.startswith("http"):
                        urls_to_scrape.append(line_str)

    if not urls_to_scrape:
        logger.error("No URLs provided. Supply --url or --urls-file.")
        sys.exit(1)

    logger.info("Loaded %d product URLs to scrape", len(urls_to_scrape))
    asyncio.run(process_urls(
        urls=urls_to_scrape,
        output_file=args.output,
        api_key=api_key,
        use_residential_proxy=args.residential,
        concurrency=args.concurrency,
        db_path=args.db,
        zipcode=args.zipcode,
    ))


if __name__ == "__main__":
    main()
