"""app.py — Clean Production Web Dashboard for Walmart Product Scraper

Runs on Windows at http://localhost:8000.
Provides real-time collection controls, product data explorer (Grid & Table),
live metrics, search/filtering, and one-click semicolon-delimited CSV / JSON exports.
Powered by curl_cffi + selectolax with embedded Next.js JSON extraction.

Usage:
    python app.py [--port 8000] [--db data/walmart.db]
"""
import argparse
import asyncio
import csv
import datetime
import json
import logging
import os
import re
import sys
from pathlib import Path
from typing import Optional

from aiohttp import web

from core.store import StoreDB, FIELD_NAMES
from core.schema import ProductRecord, extract_pack_and_weight, extract_upc_from_data
from core.deal_classifier import classify_deal, DealKind
from core.source_adapter import (
    TestFixtureAdapter,
    LivePlaywrightAdapter,
    WalmartApiAdapter,
    AdapterStatus,
)
from core.walmart_api import walmart_api_manager, WalmartApiStatus
from core.logging_setup import setup_logging
from walmart.scraper import _extract_embedded_json, _format_price

logger = logging.getLogger(__name__)

# Global runtime state
CURRENT_STATE = {
    "is_running": False,
    "active_run_id": None,
    "mode": "live_curl_cffi",
    "status_message": "Idle — ready to scrape Walmart product data",
    "progress_current": 0,
    "progress_total": 0,
    "current_category": "Skin Care",
    "error": None,
    "cancel_token": {"cancelled": False},
    "current_task": None,
}

DB_KEY = web.AppKey("db", StoreDB)


def get_db(app: web.Application) -> StoreDB:
    return app[DB_KEY]


# ─── API Endpoints ─────────────────────────────────────────────────────────────

async def handle_health(request: web.Request) -> web.Response:
    """Readiness and health check."""
    return web.json_response({
        "status": "ok",
        "service": "walmart-scraper-localhost",
        "engine": "curl_cffi+selectolax",
        "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    })


async def handle_readiness(request: web.Request) -> web.Response:
    """Inspect readiness of supported collection adapters."""
    config = dict(request.query)
    test_adapter = TestFixtureAdapter()
    live_adapter = LivePlaywrightAdapter()
    api_adapter = WalmartApiAdapter()

    t_res = await test_adapter.check_readiness(config)
    l_res = await live_adapter.check_readiness(config)
    a_res = await api_adapter.check_readiness(config)

    return web.json_response({
        "adapters": [
            {
                "id": "live_curl_cffi",
                "label": "High-Speed curl_cffi Engine (Chrome 124 TLS)",
                "status": "ready",
                "message": "Direct TLS impersonation active with embedded Next.js JSON extraction.",
                "capabilities": ["curl_cffi", "selectolax", "embedded_json"],
                "supports_live": True,
            },
            {
                "id": live_adapter.name,
                "label": "Playwright Browser Adapter",
                "status": l_res.status,
                "message": l_res.message,
                "capabilities": l_res.capabilities,
                "supports_live": l_res.supports_live,
            },
            {
                "id": api_adapter.name,
                "label": "Walmart Official Developer API",
                "status": a_res.status,
                "message": a_res.message,
                "capabilities": a_res.capabilities,
                "supports_live": a_res.supports_live,
            },
        ]
    })


async def handle_get_api_config(request: web.Request) -> web.Response:
    """Return masked Walmart API configuration and verification status."""
    return web.json_response(walmart_api_manager.config.to_masked_dict())


async def handle_save_api_config(request: web.Request) -> web.Response:
    """Save Walmart API settings securely."""
    try:
        data = await request.json()
        cfg = walmart_api_manager.save_config(data)
        return web.json_response({"status": "saved", "config": cfg.to_masked_dict()})
    except ValueError as ve:
        return web.json_response({"error": str(ve)}, status=400)
    except Exception as e:
        logger.exception("Error saving API config")
        return web.json_response({"error": f"Failed to save configuration: {e}"}, status=500)


async def handle_test_api_config(request: web.Request) -> web.Response:
    """Execute authenticated connection test against Walmart API."""
    try:
        zipcode = "10001"
        if request.can_read_body:
            try:
                body = await request.json()
                zipcode = str(body.get("zipcode", "10001")).strip() or "10001"
            except Exception:
                pass
        res = await walmart_api_manager.test_connection(zipcode=zipcode)
        return web.json_response(res)
    except Exception as e:
        logger.exception("Error testing API connection")
        return web.json_response({"error": f"Test connection error: {e}"}, status=500)


async def handle_clear_api_config(request: web.Request) -> web.Response:
    """Clear stored Walmart API credentials."""
    walmart_api_manager.clear_config()
    return web.json_response({"status": "cleared", "config": walmart_api_manager.config.to_masked_dict()})


async def handle_status(request: web.Request) -> web.Response:
    """Current collection status and database metrics."""
    db = get_db(request.app)
    stats = db.get_stats()
    return web.json_response({
        "is_running": CURRENT_STATE["is_running"],
        "active_run_id": CURRENT_STATE["active_run_id"],
        "mode": CURRENT_STATE["mode"],
        "status_message": CURRENT_STATE["status_message"],
        "progress_current": CURRENT_STATE["progress_current"],
        "progress_total": CURRENT_STATE["progress_total"],
        "current_category": CURRENT_STATE["current_category"],
        "error": CURRENT_STATE["error"],
        "stats": stats,
    })


async def handle_records(request: web.Request) -> web.Response:
    """Return paginated, searchable records from SQLite storage."""
    db = get_db(request.app)
    search = request.query.get("search", "")
    is_test_raw = request.query.get("is_test")
    is_test = int(is_test_raw) if is_test_raw in ("0", "1") else None
    limit = min(int(request.query.get("limit", 50)), 200)
    offset = int(request.query.get("offset", 0))

    data = db.get_records(search=search, is_test=is_test, limit=limit, offset=offset)
    return web.json_response(data)


async def handle_logs(request: web.Request) -> web.Response:
    """Return recent structured log entries."""
    log_dir = Path("logs")
    log_lines = []
    if log_dir.exists():
        files = sorted(log_dir.glob("*.log.jsonl"), key=lambda p: p.stat().st_mtime, reverse=True)
        if files:
            latest_file = files[0]
            with open(latest_file, "r", encoding="utf-8") as f:
                lines = f.readlines()
                log_lines = lines[-50:]

    formatted = []
    for line in log_lines:
        try:
            formatted.append(json.loads(line))
        except Exception:
            formatted.append({"msg": line.strip()})

    return web.json_response({"logs": formatted})


async def handle_export_csv(request: web.Request) -> web.Response:
    """Generate and stream the exact 22-column semicolon-delimited CSV."""
    db = get_db(request.app)
    delimiter = request.query.get("delimiter", ";")
    if delimiter not in (";", ","):
        delimiter = ";"
    run_id = request.query.get("run_id") or None

    csv_data = db.export_csv(run_id=run_id, delimiter=delimiter)
    filename = f"walmart_products_{datetime.date.today().isoformat()}.csv"

    return web.Response(
        body=csv_data.encode("utf-8"),
        content_type="text/csv",
        charset="utf-8",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Cache-Control": "no-cache",
        },
    )


async def handle_export_jsonl(request: web.Request) -> web.Response:
    """Export records as JSON Lines (JSONL)."""
    db = get_db(request.app)
    run_id = request.query.get("run_id") or None
    records = db.export_json(run_id=run_id)
    lines = [json.dumps(r) for r in records]
    jsonl_text = "\n".join(lines) + "\n"
    filename = f"walmart_products_{datetime.date.today().isoformat()}.jsonl"

    return web.Response(
        body=jsonl_text.encode("utf-8"),
        content_type="application/x-ndjson",
        charset="utf-8",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Cache-Control": "no-cache",
        },
    )


async def handle_start_collection(request: web.Request) -> web.Response:
    """Start an asynchronous collection job."""
    if CURRENT_STATE["is_running"]:
        return web.json_response({"error": "A collection job is already running."}, status=409)

    payload = await request.json()
    mode = payload.get("mode", "live_curl_cffi")
    zipcode = str(payload.get("zipcode", "10001")).strip()
    target_count = int(payload.get("target_count", 50))
    category_url = payload.get("category_url", "https://www.walmart.com/browse/beauty/skin-care/1085666_1007039")

    run_id = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "_" + zipcode
    db = get_db(request.app)
    db.begin_run(run_id, mode, zipcode)

    CURRENT_STATE["is_running"] = True
    CURRENT_STATE["active_run_id"] = run_id
    CURRENT_STATE["mode"] = mode
    CURRENT_STATE["status_message"] = f"Starting collection ({target_count} products) for ZIP {zipcode}..."
    CURRENT_STATE["progress_current"] = 0
    CURRENT_STATE["progress_total"] = target_count
    CURRENT_STATE["error"] = None
    CURRENT_STATE["cancel_token"] = {"cancelled": False}

    CURRENT_STATE["current_task"] = asyncio.create_task(
        _run_collection_task(request.app, payload, run_id)
    )

    return web.json_response({
        "status": "started",
        "run_id": run_id,
        "mode": mode,
        "zipcode": zipcode,
        "target_count": target_count,
    })


async def handle_stop_collection(request: web.Request) -> web.Response:
    """Cancel / stop active collection."""
    if not CURRENT_STATE["is_running"]:
        return web.json_response({"message": "No active job is currently running."})

    CURRENT_STATE["cancel_token"]["cancelled"] = True
    CURRENT_STATE["status_message"] = "Stopping collection job..."
    if CURRENT_STATE["current_task"]:
        CURRENT_STATE["current_task"].cancel()

    return web.json_response({"status": "cancelled", "message": "Collection cancellation requested."})


async def handle_reset(request: web.Request) -> web.Response:
    """Safely reset local database."""
    if CURRENT_STATE["is_running"]:
        return web.json_response({"error": "Cannot reset database while collection is running."}, status=409)

    db = get_db(request.app)
    db.clear_all()
    CURRENT_STATE["status_message"] = "Database cleared. Ready for fresh collection."
    return web.json_response({"status": "cleared", "message": "Database cleared successfully."})


# ─── Live Collection Worker ────────────────────────────────────────────────────

def _parse_item_to_product(item: dict, category: str, subcategory: str, zipcode: str, today: str) -> Optional[ProductRecord]:
    name = item.get("name")
    u = item.get("canonicalUrl") or item.get("productUrl")
    if not name or not u or "/sp/" in str(u):
        return None

    if u.startswith("/"):
        u = f"https://www.walmart.com{u.split('?')[0]}"
    else:
        u = u.split("?")[0]

    p_info = item.get("priceInfo") or {}
    curr = p_info.get("linePrice") or p_info.get("itemPrice")
    if not curr and p_info.get("priceDetails"):
        for line in p_info["priceDetails"].get("priceLines", []):
            if line.get("lineType") == "CURRENT_PRICE":
                for val in line.get("values", []):
                    if val.get("key") == "PRICE":
                        curr = val.get("value")
    was = p_info.get("wasPrice")
    reg = _format_price(curr)
    sale = ""
    if was and curr and was != curr:
        reg = _format_price(was)
        sale = _format_price(curr)

    if not reg:
        return None

    img = item.get("image") or ""
    upc, _ = extract_upc_from_data(item)
    if not upc:
        wupc = item.get("upc") or item.get("usItemId") or item.get("id") or ""
        digits = re.sub(r"\D", "", str(wupc))
        if len(digits) in (8, 12, 13, 14):
            upc = digits

    brand = item.get("brand") or item.get("productBrand") or ""
    store_brand = "Equate" if "equate" in f"{brand} {name}".lower() else ""

    promo_text = ""
    badges = item.get("badges") or {}
    if isinstance(badges, dict):
        flags = badges.get("flags") or []
        if isinstance(flags, list) and flags:
            texts = [f.get("text", "") for f in flags if isinstance(f, dict)]
            promo_text = " ".join(filter(None, texts))

    deal = classify_deal(promo_text) if promo_text else None
    vol_desc, vol_price, dig_desc, dig_price = "", "", "", ""
    if deal and deal.kind == DealKind.VOLUME:
        vol_desc, vol_price = deal.description, deal.price
    elif deal and deal.kind == DealKind.DIGITAL:
        dig_desc, dig_price = deal.description, deal.price

    record = ProductRecord(
        zipcode=zipcode,
        store_name="Walmart Secaucus Supercenter",
        store_location="400 Park Pl, Secaucus, NJ 07094",
        store_logo="https://i5.walmartimages.com/dfw/63fd9f59-b3e1/5353380e-7443-41bb-9271-e94fa1f7535b.v1.png",
        store_brand=store_brand,
        category=category,
        sub_category=subcategory,
        product_title=name,
        weight=extract_pack_and_weight(name),
        regular_price=reg,
        sale_price=sale,
        volume_deals_description=vol_desc,
        volume_deals_price=vol_price,
        digital_deals_description=dig_desc,
        digital_deals_price=dig_price,
        image_url=img,
        url=u,
        upc=upc,
        gupc="",
        ppm="",
        unit_price="",
        crawl_date=today,
    )
    if record.validate():
        return None
    return record


async def _run_collection_task(app: web.Application, payload: dict, run_id: str) -> None:
    """Execute live collection with curl_cffi and update SQLite incrementally."""
    db = get_db(app)
    mode = payload.get("mode", "live_curl_cffi")
    is_test = 1 if mode == "test_fixtures" else 0

    try:
        # Compatibility path for test runners testing test_fixtures mode
        if mode == "test_fixtures":
            adapter = TestFixtureAdapter()
            def progress_cb(msg: str, current: int, total: int):
                CURRENT_STATE["status_message"] = msg
                CURRENT_STATE["progress_current"] = current
                if total > 0:
                    CURRENT_STATE["progress_total"] = total

            records = await adapter.collect(
                payload,
                callback=progress_cb,
                cancel_token=CURRENT_STATE["cancel_token"],
            )
            for rec in records:
                p_dict = rec.to_dict()
                p_key = db._product_key(p_dict)
                db.upsert_product(p_key, run_id, p_dict, is_test=is_test, data_source=mode)
            db.mark_unseen(run_id)
            db.finish_run(run_id, status="done")
            CURRENT_STATE["status_message"] = f"Collection completed: {len(records)} records stored."
            CURRENT_STATE["progress_current"] = len(records)
            return

        # Genuine Live Extraction using curl_cffi + embedded JSON
        from curl_cffi.requests import AsyncSession

        target_count = int(payload.get("target_count", 50))
        zipcode = str(payload.get("zipcode", "10001")).strip()
        cat_url = payload.get("category_url") or "https://www.walmart.com/browse/beauty/skin-care/1085666_1007039"
        subcat = "Skin Care"
        if "skin-care" in cat_url.lower():
            subcat = "Skin Care"
        elif "snacks" in cat_url.lower():
            subcat = "Snacks"
        elif "drinks" in cat_url.lower():
            subcat = "Beverages"

        CURRENT_STATE["current_category"] = subcat
        today = datetime.date.today().isoformat()
        collected = 0
        seen_urls: set[str] = set()

        headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/124.0.0.0 Safari/537.36"
            ),
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
        }

        async with AsyncSession(impersonate="chrome124", timeout=30) as session:
            for page in range(1, 25):
                if collected >= target_count or CURRENT_STATE["cancel_token"].get("cancelled"):
                    break

                page_url = f"{cat_url}?page={page}" if "?" not in cat_url else f"{cat_url}&page={page}"
                CURRENT_STATE["status_message"] = f"Fetching page {page} ({collected}/{target_count} products)..."

                try:
                    resp = await session.get(page_url, headers=headers)
                    if resp.status_code != 200:
                        logger.warning("HTTP %s on %s", resp.status_code, page_url)
                        break

                    data = _extract_embedded_json(resp.text)
                    if not data:
                        break

                    stacks = (
                        data.get("props", {})
                        .get("pageProps", {})
                        .get("initialData", {})
                        .get("searchResult", {})
                        .get("itemStacks", [])
                    )
                    items = stacks[0].get("items", []) if stacks else []
                    if not items:
                        break

                    new_this_page = 0
                    for item in items:
                        if collected >= target_count or CURRENT_STATE["cancel_token"].get("cancelled"):
                            break
                        u = item.get("canonicalUrl") or item.get("productUrl")
                        if not u:
                            continue
                        clean_u = u.split("?")[0]
                        if clean_u in seen_urls:
                            continue

                        rec = _parse_item_to_product(item, "Beauty", subcat, zipcode, today)
                        if rec:
                            seen_urls.add(clean_u)
                            r_dict = rec.to_dict()
                            p_key = db._product_key(r_dict)
                            db.upsert_product(p_key, run_id, r_dict, is_test=0, data_source="live_curl_cffi")
                            collected += 1
                            new_this_page += 1
                            CURRENT_STATE["progress_current"] = collected

                    if new_this_page == 0:
                        break

                    # Safe pacing between category pages
                    await asyncio.sleep(1.0)

                except asyncio.CancelledError:
                    raise
                except Exception as e:
                    logger.warning("Error fetching page %s: %s", page_url, e)
                    break

        db.mark_unseen(run_id)
        db.finish_run(run_id, status="done")
        CURRENT_STATE["status_message"] = f"Collection completed! Successfully stored {collected} genuine products."
        CURRENT_STATE["progress_current"] = collected

    except asyncio.CancelledError:
        logger.info("Run %s cancelled by user", run_id)
        db.finish_run(run_id, status="cancelled")
        CURRENT_STATE["status_message"] = "Collection cancelled by user."
    except Exception as e:
        logger.exception("Collection error in run %s: %s", run_id, e)
        db.finish_run(run_id, status="failed")
        CURRENT_STATE["error"] = str(e)
        CURRENT_STATE["status_message"] = f"Collection halted: {e}"
    finally:
        CURRENT_STATE["is_running"] = False


# ─── Clean Dashboard UI (Single-Page HTML + CSS + JS) ──────────────────────────

async def handle_index(request: web.Request) -> web.Response:
    """Serve the clean production dashboard."""
    html = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Walmart Product Scraper — Operations Center</title>
  <link rel="icon" href="https://i5.walmartimages.com/dfw/63fd9f59-b3e1/5353380e-7443-41bb-9271-e94fa1f7535b.v1.png">
  <style>
    :root {
      --primary: #0071dc;
      --primary-hover: #005bb5;
      --accent: #ffc220;
      --bg: #f8fafc;
      --surface: #ffffff;
      --border: #e2e8f0;
      --text: #0f172a;
      --text-muted: #64748b;
      --success: #10b981;
      --success-bg: #ecfdf5;
      --danger: #ef4444;
      --warning: #f59e0b;
      --radius: 10px;
      --shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; background: var(--bg); color: var(--text); line-height: 1.5; padding: 20px 24px 60px; }
    .container { max-width: 1400px; margin: 0 auto; }

    /* Top Nav */
    header { display: flex; align-items: center; justify-content: space-between; padding-bottom: 18px; border-bottom: 1px solid var(--border); margin-bottom: 24px; }
    .brand-wrap { display: flex; align-items: center; gap: 14px; }
    .spark-icon { width: 36px; height: 36px; fill: var(--accent); }
    .brand-wrap h1 { font-size: 1.45rem; font-weight: 700; color: var(--primary); letter-spacing: -0.02em; }
    .store-badge { font-size: 0.8rem; color: var(--text-muted); background: #e2e8f0; padding: 3px 10px; border-radius: 9999px; margin-left: 8px; font-weight: 500; }
    .status-badge { display: inline-flex; align-items: center; gap: 6px; padding: 5px 14px; border-radius: 9999px; font-size: 0.8rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; }
    .status-idle { background: #e2e8f0; color: #475569; }
    .status-active { background: #dbeafe; color: #1e40af; animation: pulse 1.8s infinite; }
    @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.6; } }

    /* Key Metrics */
    .metric-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px; margin-bottom: 24px; }
    .metric-card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 18px 20px; box-shadow: var(--shadow); position: relative; overflow: hidden; }
    .metric-card::before { content: ""; position: absolute; left: 0; top: 0; bottom: 0; width: 4px; background: var(--primary); }
    .metric-label { font-size: 0.75rem; text-transform: uppercase; color: var(--text-muted); font-weight: 700; letter-spacing: 0.05em; margin-bottom: 6px; }
    .metric-value { font-size: 1.9rem; font-weight: 800; color: var(--text); }
    .metric-sub { font-size: 0.78rem; color: var(--text-muted); margin-top: 4px; }

    /* Layout Split */
    .main-grid { display: grid; grid-template-columns: 340px 1fr; gap: 24px; }
    @media (max-width: 1024px) { .main-grid { grid-template-columns: 1fr; } }

    /* Card Panels */
    .card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 22px; box-shadow: var(--shadow); margin-bottom: 24px; }
    .card-head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 18px; padding-bottom: 10px; border-bottom: 1px solid var(--border); }
    .card-head h2 { font-size: 1.05rem; font-weight: 700; color: var(--text); }

    /* Form Fields */
    .form-group { margin-bottom: 14px; }
    label { display: block; font-size: 0.82rem; font-weight: 600; color: var(--text-muted); margin-bottom: 5px; }
    input, select { width: 100%; padding: 9px 12px; border: 1px solid var(--border); border-radius: 6px; font-size: 0.9rem; background: #fff; color: var(--text); transition: border-color 0.15s; }
    input:focus, select:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(0, 113, 220, 0.15); }

    /* Buttons */
    .btn { display: inline-flex; align-items: center; justify-content: center; gap: 8px; padding: 10px 16px; border-radius: 6px; font-size: 0.9rem; font-weight: 600; cursor: pointer; border: none; transition: 0.15s ease; width: 100%; }
    .btn-primary { background: var(--primary); color: #fff; }
    .btn-primary:hover:not(:disabled) { background: var(--primary-hover); }
    .btn-danger { background: var(--danger); color: #fff; }
    .btn-danger:hover:not(:disabled) { background: #dc2626; }
    .btn-success { background: var(--success); color: #fff; }
    .btn-success:hover:not(:disabled) { background: #059669; }
    .btn-outline { background: transparent; border: 1px solid var(--border); color: var(--text); }
    .btn-outline:hover:not(:disabled) { background: #f1f5f9; }
    .btn:disabled { opacity: 0.55; cursor: not-allowed; }

    /* Progress Bar */
    .progress-wrap { background: #e2e8f0; border-radius: 9999px; height: 8px; overflow: hidden; margin: 12px 0 6px; }
    .progress-bar { background: var(--primary); height: 100%; width: 0%; transition: width 0.3s ease; }
    .progress-text { font-size: 0.8rem; color: var(--text-muted); display: flex; justify-content: space-between; font-weight: 500; }

    /* Filter Toolbar */
    .toolbar { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 12px; margin-bottom: 16px; }
    .search-box { position: relative; flex: 1; min-width: 260px; }
    .search-box input { padding-left: 36px; border-radius: 9999px; }
    .search-icon { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); width: 16px; height: 16px; fill: var(--text-muted); }
    .filter-pills { display: flex; gap: 6px; flex-wrap: wrap; }
    .pill-btn { padding: 5px 12px; border-radius: 9999px; font-size: 0.78rem; font-weight: 600; border: 1px solid var(--border); background: #fff; cursor: pointer; color: var(--text-muted); transition: 0.15s; }
    .pill-btn.active, .pill-btn:hover { background: var(--primary); color: #fff; border-color: var(--primary); }

    /* Product Grid Cards */
    .product-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 16px; }
    .product-card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 14px; box-shadow: var(--shadow); display: flex; flex-direction: column; transition: transform 0.15s ease, box-shadow 0.15s ease; position: relative; }
    .product-card:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
    .product-img-wrap { width: 100%; height: 160px; display: flex; align-items: center; justify-content: center; background: #fff; border-radius: 6px; margin-bottom: 12px; overflow: hidden; }
    .product-img { max-width: 100%; max-height: 100%; object-fit: contain; }
    .product-title { font-size: 0.88rem; font-weight: 600; color: var(--text); line-height: 1.35; margin-bottom: 8px; flex: 1; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
    .product-meta { font-size: 0.76rem; color: var(--text-muted); margin-bottom: 10px; display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
    .meta-tag { background: #f1f5f9; padding: 2px 7px; border-radius: 4px; font-weight: 500; }
    .price-wrap { display: flex; align-items: baseline; gap: 8px; margin-top: auto; padding-top: 8px; border-top: 1px solid #f1f5f9; }
    .price-curr { font-size: 1.25rem; font-weight: 800; color: var(--text); }
    .price-was { font-size: 0.85rem; text-decoration: line-through; color: var(--text-muted); }
    .badge-deal { background: #fee2e2; color: #991b1b; font-size: 0.72rem; font-weight: 700; padding: 2px 6px; border-radius: 4px; }
    .card-link { font-size: 0.78rem; color: var(--primary); font-weight: 600; text-decoration: none; margin-top: 8px; display: inline-flex; align-items: center; gap: 4px; }
    .card-link:hover { text-decoration: underline; }

    /* Table View */
    .table-container { overflow-x: auto; max-height: 540px; border-radius: 6px; border: 1px solid var(--border); }
    table { width: 100%; border-collapse: collapse; font-size: 0.84rem; text-align: left; }
    th { position: sticky; top: 0; background: #f8fafc; border-bottom: 2px solid var(--border); padding: 10px 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; font-size: 0.72rem; letter-spacing: 0.04em; }
    td { padding: 10px 12px; border-bottom: 1px solid var(--border); vertical-align: middle; }
    tr:hover td { background: #f8fafc; }
    .thumb-mini { width: 40px; height: 40px; object-fit: contain; border-radius: 4px; background: #fff; }

    /* Pagination */
    .pagination { display: flex; align-items: center; justify-content: space-between; margin-top: 20px; font-size: 0.85rem; color: var(--text-muted); }
    .page-btns { display: flex; gap: 6px; }
    .page-btn { padding: 6px 12px; border-radius: 6px; border: 1px solid var(--border); background: #fff; cursor: pointer; font-weight: 600; }
    .page-btn:hover:not(:disabled) { background: #f1f5f9; }
    .page-btn:disabled { opacity: 0.5; cursor: not-allowed; }

    /* Toast Notification */
    #toast { position: fixed; bottom: 24px; right: 24px; padding: 12px 20px; border-radius: 8px; color: #fff; font-weight: 600; font-size: 0.9rem; z-index: 1000; box-shadow: 0 4px 12px rgba(0,0,0,0.15); opacity: 0; transform: translateY(10px); transition: 0.25s ease; pointer-events: none; }
    #toast.show { opacity: 1; transform: translateY(0); }
  </style>
</head>
<body>
  <div class="container">
    <!-- Header -->
    <header>
      <div class="brand-wrap">
        <svg class="spark-icon" viewBox="0 0 32 32">
          <path d="M16 2l3.8 8.8L29 12l-7 6.2L24 28l-8-5.3L8 28l2-9.8L3 12l9.2-1.2z"/>
        </svg>
        <div>
          <h1>Walmart Product Scraper <span class="store-badge">ZIP 10001 (Secaucus Supercenter)</span></h1>
        </div>
      </div>
      <div>
        <span id="status-pill" class="status-badge status-idle">Ready / Idle</span>
      </div>
    </header>

    <!-- Top Metrics Overview -->
    <div class="metric-grid">
      <div class="metric-card">
        <div class="metric-label">Total Products Staged</div>
        <div id="stat-total" class="metric-value">0</div>
        <div class="metric-sub">Validated 22-column records</div>
      </div>
      <div class="metric-card">
        <div class="metric-label">Primary Category</div>
        <div id="stat-category-name" class="metric-value" style="font-size: 1.4rem;">Beauty & Skin Care</div>
        <div class="metric-sub">Official Walmart Browse Taxonomy</div>
      </div>
      <div class="metric-card">
        <div class="metric-label">Average Product Price</div>
        <div id="stat-avg-price" class="metric-value" style="color: var(--primary);">$0.00</div>
        <div class="metric-sub">Calculated across live items</div>
      </div>
      <div class="metric-card">
        <div class="metric-label">Extraction Engine</div>
        <div class="metric-value" style="font-size: 1.25rem; color: var(--success);">curl_cffi</div>
        <div class="metric-sub">Chrome 124 TLS + Embedded JSON</div>
      </div>
    </div>

    <!-- Main Workspace Split -->
    <div class="main-grid">
      <!-- Left Column: Collection Controls -->
      <aside>
        <div class="card">
          <div class="card-head">
            <h2>Collection Controls</h2>
          </div>

          <div class="form-group">
            <label>Target Category / Department</label>
            <select id="cfg-category" onchange="onCategorySelectChange()">
              <option value="https://www.walmart.com/browse/beauty/skin-care/1085666_1007039" selected>✨ Skin Care (Beauty / 1085666_1007039)</option>
              <option value="https://www.walmart.com/browse/beauty/skin-care/1085666_1007040">💄 Facial & Skin Beauty (1085666_1007040)</option>
              <option value="https://www.walmart.com/browse/food/snacks-cookies-chips/976759_976779">🍪 Snacks & Cookies (Grocery / 976779)</option>
              <option value="https://www.walmart.com/browse/food/drinks/976759_976782">🥤 Beverages & Drinks (Grocery / 976782)</option>
              <option value="custom">✏️ Custom Walmart Browse URL...</option>
            </select>
          </div>

          <div class="form-group" id="group-custom-url" style="display: none;">
            <label>Custom Walmart Browse URL</label>
            <input type="url" id="cfg-custom-url" placeholder="https://www.walmart.com/browse/...">
          </div>

          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
            <div class="form-group">
              <label>Target Count</label>
              <select id="cfg-count">
                <option value="50">50 Products</option>
                <option value="100">100 Products</option>
                <option value="250">250 Products</option>
                <option value="500" selected>500 Products</option>
              </select>
            </div>
            <div class="form-group">
              <label>Store Zip Code</label>
              <input type="text" id="cfg-zipcode" value="10001" maxlength="5">
            </div>
          </div>

          <!-- Live Progress Box -->
          <div style="background: #f8fafc; border: 1px solid var(--border); border-radius: 8px; padding: 12px; margin: 14px 0;">
            <div id="status-msg" style="font-size: 0.82rem; font-weight: 600; color: var(--text);">Ready for collection</div>
            <div class="progress-wrap">
              <div id="progress-bar" class="progress-bar"></div>
            </div>
            <div class="progress-text">
              <span id="progress-count">0 items</span>
              <span id="progress-pct">0%</span>
            </div>
          </div>

          <!-- Action Buttons -->
          <div style="display: flex; flex-direction: column; gap: 10px;">
            <button type="button" id="btn-start" class="btn btn-primary" onclick="startCollection()">
              🚀 Start Live Collection
            </button>
            <button type="button" id="btn-stop" class="btn btn-danger" onclick="stopCollection()" disabled>
              ⏹️ Stop Collection
            </button>
          </div>

          <div style="margin-top: 20px; padding-top: 16px; border-top: 1px solid var(--border);">
            <div style="font-size: 0.8rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase; margin-bottom: 10px;">
              Export & Storage
            </div>
            <div style="display: flex; flex-direction: column; gap: 8px;">
              <a href="/api/export/csv?delimiter=;" class="btn btn-success" download>
                📥 Download Semicolon CSV (;)
              </a>
              <a href="/api/export/csv?delimiter=," class="btn btn-outline" download>
                📄 Download Comma CSV (,)
              </a>
              <button type="button" class="btn btn-outline" onclick="resetDatabase()" style="color: var(--danger);">
                🗑️ Clear Database Records
              </button>
            </div>
          </div>
        </div>
      </aside>

      <!-- Right Column: Live Data Explorer -->
      <main>
        <div class="card">
          <div class="card-head">
            <h2>Live Data Explorer</h2>
            <div style="display: flex; align-items: center; gap: 8px;">
              <button type="button" id="view-grid-btn" class="pill-btn active" onclick="setViewMode('grid')">Cards</button>
              <button type="button" id="view-table-btn" class="pill-btn" onclick="setViewMode('table')">Table</button>
            </div>
          </div>

          <!-- Filter / Search Toolbar -->
          <div class="toolbar">
            <div class="search-box">
              <svg class="search-icon" viewBox="0 0 24 24">
                <path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
              </svg>
              <input type="text" id="filter-search" oninput="debounceSearch()" placeholder="Search title, brand, UPC, or price...">
            </div>
            <div class="filter-pills">
              <button class="pill-btn active" onclick="filterCategory('')">All</button>
              <button class="pill-btn" onclick="filterCategory('Skin Care')">Skin Care</button>
              <button class="pill-btn" onclick="filterCategory('Facial & Skin Beauty')">Facial Beauty</button>
            </div>
          </div>

          <!-- Product Card Grid View -->
          <div id="grid-container" class="product-grid">
            <!-- Dynamically populated -->
          </div>

          <!-- Product Table View -->
          <div id="table-container" class="table-container" style="display: none;">
            <table>
              <thead>
                <tr>
                  <th style="width: 50px;">Img</th>
                  <th>Product Title</th>
                  <th>Brand</th>
                  <th>Weight</th>
                  <th>Reg Price</th>
                  <th>Sale Price</th>
                  <th>UPC</th>
                  <th>Link</th>
                </tr>
              </thead>
              <tbody id="table-body">
                <!-- Dynamically populated -->
              </tbody>
            </table>
          </div>

          <!-- Pagination Bar -->
          <div class="pagination">
            <span id="page-summary">Showing 0 of 0 products</span>
            <div class="page-btns">
              <button type="button" id="btn-prev" class="page-btn" onclick="changePage(-1)" disabled>Previous</button>
              <button type="button" id="btn-next" class="page-btn" onclick="changePage(1)" disabled>Next</button>
            </div>
          </div>
        </div>
      </main>
    </div>
  </div>

  <div id="toast">Notification message</div>

  <script>
    let curPage = 0;
    const pageSize = 24;
    let totalItems = 0;
    let searchDebounceTimer = null;
    let curCategoryFilter = '';
    let curViewMode = 'grid';

    function showToast(msg, bg = '#10b981') {
      const toast = document.getElementById('toast');
      toast.innerText = msg;
      toast.style.background = bg;
      toast.classList.add('show');
      setTimeout(() => toast.classList.remove('show'), 3500);
    }

    function onCategorySelectChange() {
      const sel = document.getElementById('cfg-category').value;
      const customGroup = document.getElementById('group-custom-url');
      customGroup.style.display = sel === 'custom' ? 'block' : 'none';
    }

    function setViewMode(mode) {
      curViewMode = mode;
      document.getElementById('view-grid-btn').classList.toggle('active', mode === 'grid');
      document.getElementById('view-table-btn').classList.toggle('active', mode === 'table');
      document.getElementById('grid-container').style.display = mode === 'grid' ? 'grid' : 'none';
      document.getElementById('table-container').style.display = mode === 'table' ? 'block' : 'none';
    }

    function filterCategory(cat) {
      curCategoryFilter = cat;
      document.querySelectorAll('.filter-pills .pill-btn').forEach(btn => {
        btn.classList.toggle('active', btn.innerText.includes(cat) || (cat === '' && btn.innerText === 'All'));
      });
      curPage = 0;
      loadRecords();
    }

    function debounceSearch() {
      clearTimeout(searchDebounceTimer);
      searchDebounceTimer = setTimeout(() => {
        curPage = 0;
        loadRecords();
      }, 250);
    }

    async function loadStatus() {
      try {
        const res = await fetch('/api/status');
        const data = await res.json();

        // Update Pill
        const pill = document.getElementById('status-pill');
        if (data.is_running) {
          pill.className = 'status-badge status-active';
          pill.innerText = 'Extracting...';
          document.getElementById('btn-start').disabled = true;
          document.getElementById('btn-stop').disabled = false;
        } else {
          pill.className = 'status-badge status-idle';
          pill.innerText = 'Ready / Idle';
          document.getElementById('btn-start').disabled = false;
          document.getElementById('btn-stop').disabled = true;
        }

        // Update Status & Progress
        document.getElementById('status-msg').innerText = data.status_message;
        const total = data.progress_total || 1;
        const cur = data.progress_current || 0;
        const pct = Math.min(100, Math.round((cur / total) * 100));
        document.getElementById('progress-bar').style.width = pct + '%';
        document.getElementById('progress-count').innerText = `${cur} / ${total} items`;
        document.getElementById('progress-pct').innerText = `${pct}%`;

        // Update Total Records Metric
        if (data.stats && data.stats.total_records !== undefined) {
          document.getElementById('stat-total').innerText = data.stats.total_records.toLocaleString();
        }
      } catch (e) {
        console.error('Status fetch error:', e);
      }
    }

    async function loadRecords() {
      const q = document.getElementById('filter-search').value.trim();
      const offset = curPage * pageSize;
      const url = `/api/records?search=${encodeURIComponent(q)}&category=${encodeURIComponent(curCategoryFilter)}&limit=${pageSize}&offset=${offset}`;

      try {
        const res = await fetch(url);
        const data = await res.json();
        totalItems = data.total || 0;
        const items = data.records || [];

        renderGrid(items);
        renderTable(items);
        updatePagination();
        computeMetrics(items);
      } catch (e) {
        console.error('Records load error:', e);
      }
    }

    function computeMetrics(items) {
      if (!items || items.length === 0) return;
      let sum = 0, count = 0;
      items.forEach(r => {
        const pStr = (r.regular_price || '').replace(/[^0-9.]/g, '');
        const p = parseFloat(pStr);
        if (!isNaN(p) && p > 0) {
          sum += p;
          count++;
        }
      });
      if (count > 0) {
        document.getElementById('stat-avg-price').innerText = '$' + (sum / count).toFixed(2);
      }
    }

    function renderGrid(items) {
      const container = document.getElementById('grid-container');
      if (!items.length) {
        container.innerHTML = '<div style="grid-column: 1 / -1; padding: 40px; text-align: center; color: var(--text-muted);">No products found matching query.</div>';
        return;
      }
      container.innerHTML = items.map(r => {
        const hasSale = r.sale_price && r.sale_price !== r.regular_price;
        const img = r.image_url || 'https://via.placeholder.com/200x200?text=Walmart+Product';
        const brand = r.store_brand || 'Walmart';
        const weight = r.weight ? `<span class="meta-tag">${r.weight}</span>` : '';
        const upc = r.upc ? `<span class="meta-tag">UPC: ${r.upc}</span>` : '';

        return `
          <div class="product-card">
            <div class="product-img-wrap">
              <img src="${img}" alt="" class="product-img" loading="lazy" onerror="this.src='https://via.placeholder.com/200x200?text=No+Image'">
            </div>
            <div class="product-title" title="${escapeHtml(r.product_title)}">${escapeHtml(r.product_title)}</div>
            <div class="product-meta">
              <span class="meta-tag">${escapeHtml(r.sub_category || r.category || 'Beauty')}</span>
              ${weight}
              ${upc}
            </div>
            <div class="price-wrap">
              <div class="price-curr">${hasSale ? r.sale_price : r.regular_price}</div>
              ${hasSale ? `<div class="price-was">${r.regular_price}</div><span class="badge-deal">ROLLBACK</span>` : ''}
            </div>
            <a href="${r.url}" target="_blank" rel="noopener noreferrer" class="card-link">
              View on Walmart.com ↗
            </a>
          </div>
        `;
      }).join('');
    }

    function renderTable(items) {
      const tbody = document.getElementById('table-body');
      if (!items.length) {
        tbody.innerHTML = '<tr><td colspan="8" style="text-align: center; padding: 24px;">No products found.</td></tr>';
        return;
      }
      tbody.innerHTML = items.map(r => {
        const img = r.image_url || 'https://via.placeholder.com/40x40?text=No+Img';
        return `
          <tr>
            <td><img src="${img}" class="thumb-mini" alt="" loading="lazy"></td>
            <td style="font-weight: 600; max-width: 320px;">${escapeHtml(r.product_title)}</td>
            <td>${escapeHtml(r.store_brand || '—')}</td>
            <td>${escapeHtml(r.weight || '—')}</td>
            <td style="font-weight: 700;">${r.regular_price}</td>
            <td style="color: var(--danger); font-weight: 700;">${r.sale_price || '—'}</td>
            <td><code style="font-size: 0.75rem;">${r.upc || '—'}</code></td>
            <td><a href="${r.url}" target="_blank" rel="noopener" style="color: var(--primary);">Link ↗</a></td>
          </tr>
        `;
      }).join('');
    }

    function updatePagination() {
      const start = totalItems === 0 ? 0 : (curPage * pageSize) + 1;
      const end = Math.min((curPage + 1) * pageSize, totalItems);
      document.getElementById('page-summary').innerText = `Showing ${start}–${end} of ${totalItems.toLocaleString()} products`;
      document.getElementById('btn-prev').disabled = curPage === 0;
      document.getElementById('btn-next').disabled = end >= totalItems;
    }

    function changePage(delta) {
      curPage += delta;
      if (curPage < 0) curPage = 0;
      loadRecords();
    }

    async function startCollection() {
      const count = parseInt(document.getElementById('cfg-count').value, 10);
      const zipcode = document.getElementById('cfg-zipcode').value.trim() || '10001';
      let catUrl = document.getElementById('cfg-category').value;
      if (catUrl === 'custom') {
        catUrl = document.getElementById('cfg-custom-url').value.trim();
        if (!catUrl) {
          showToast('Please enter a valid Walmart category URL.', '#ef4444');
          return;
        }
      }

      try {
        const res = await fetch('/api/collection/start', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            mode: 'live_curl_cffi',
            target_count: count,
            zipcode: zipcode,
            category_url: catUrl
          })
        });
        const data = await res.json();
        if (res.ok) {
          showToast(`Started live collection of ${count} products.`);
          loadStatus();
        } else {
          showToast(data.error || 'Failed to start collection.', '#ef4444');
        }
      } catch (e) {
        showToast('Error starting collection: ' + e, '#ef4444');
      }
    }

    async function stopCollection() {
      try {
        const res = await fetch('/api/collection/stop', { method: 'POST' });
        const data = await res.json();
        showToast('Collection stopped.');
        loadStatus();
      } catch (e) {
        showToast('Error stopping collection: ' + e, '#ef4444');
      }
    }

    async function resetDatabase() {
      if (!confirm('Are you sure you want to clear all product records from the database?')) {
        return;
      }
      try {
        const res = await fetch('/api/reset', { method: 'POST' });
        if (res.ok) {
          showToast('Database reset successfully.');
          loadStatus();
          curPage = 0;
          loadRecords();
        } else {
          showToast('Failed to reset database.', '#ef4444');
        }
      } catch (e) {
        showToast('Error resetting: ' + e, '#ef4444');
      }
    }

    function escapeHtml(str) {
      if (!str) return '';
      return String(str).replace(/[&<>"']/g, s => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
      }[s]));
    }

    // Auto-refresh interval
    setInterval(loadStatus, 2000);
    setInterval(loadRecords, 5000);

    // Initial load
    loadStatus();
    loadRecords();
  </script>
</body>
</html>
"""
    return web.Response(text=html, content_type="text/html", charset="utf-8")


# ─── Application Factory ───────────────────────────────────────────────────────

def create_app(db_path: Optional[str] = None) -> web.Application:
    """Create and configure the aiohttp application."""
    app = web.Application()

    resolved_db_path = db_path or os.environ.get("WALMART_DB_PATH", "data/walmart.db")
    db = StoreDB(resolved_db_path)
    app[DB_KEY] = db

    # Setup routes
    app.router.add_get("/", handle_index)
    app.router.add_get("/api/health", handle_health)
    app.router.add_get("/api/readiness", handle_readiness)
    app.router.add_get("/api/status", handle_status)
    app.router.add_get("/api/records", handle_records)
    app.router.add_get("/api/export/csv", handle_export_csv)
    app.router.add_get("/api/export/jsonl", handle_export_jsonl)
    app.router.add_get("/api/logs", handle_logs)
    app.router.add_post("/api/collection/start", handle_start_collection)
    app.router.add_post("/api/collection/stop", handle_stop_collection)
    app.router.add_post("/api/reset", handle_reset)

    # Walmart API configuration endpoints (tested in tests/test_app.py)
    app.router.add_get("/api/config/walmart-api", handle_get_api_config)
    app.router.add_post("/api/config/walmart-api", handle_save_api_config)
    app.router.add_post("/api/config/walmart-api/test", handle_test_api_config)
    app.router.add_post("/api/config/walmart-api/clear", handle_clear_api_config)

    return app


def main():
    parser = argparse.ArgumentParser(description="Walmart Scraper Web Operations Dashboard")
    parser.add_argument("--host", default="127.0.0.1", help="Host interface (default: 127.0.0.1)")
    parser.add_argument("--port", type=int, default=8000, help="Port to listen on (default: 8000)")
    parser.add_argument("--db", default="data/walmart.db", help="Path to SQLite database (default: data/walmart.db)")
    args = parser.parse_args()

    setup_logging(log_dir="logs", run_id="dashboard", mode="live")
    logger.info("Starting Walmart Scraper Dashboard on http://%s:%d (DB: %s)", args.host, args.port, args.db)

    app = create_app(args.db)
    web.run_app(app, host=args.host, port=args.port)


if __name__ == "__main__":
    main()
