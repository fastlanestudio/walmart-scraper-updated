# Oxylabs Realtime API Diagnostic Proposal

**Integration Target:** Classic Oxylabs Web Scraper API  
**Status:** **NOT RUN (PENDING CLIENT CREDENTIAL & COST APPROVAL)**  
**Authoritative Implementation:** `core/oxylabs_adapter.py`

---

## 1. Context & Access Method Clarification

The Walmart scraping pipeline does **not** rely on Walmart Developer/Partner APIs (which are restricted to seller marketplace management or require approved retail enterprise agreements), nor does it depend on unproxied Playwright browser sessions (which trigger PerimeterX challenge blocks on datacenter IPs).

The supported and architected extraction method is the **Classic Oxylabs Web Scraper API (Realtime Engine)**.

---

## 2. Bounded Diagnostic Request Proposal

To verify live production extraction with minimal cost exposure, we propose executing exactly **one (1)** single diagnostic query once credentials are provided and cost is approved.

### Endpoint Details
- **Method:** `POST`
- **URL:** `https://realtime.oxylabs.io/v1/queries`
- **Headers:**
  - `Content-Type: application/json`
  - `Authorization: Basic <base64(OXYLABS_USERNAME:OXYLABS_PASSWORD)>`
  - `User-Agent: WalmartScraper/2.0`

### Proposed Diagnostic Payload (1 Request)
```json
{
  "source": "walmart",
  "url": "https://www.walmart.com/ip/Great-Value-Whole-Milk-Gallon-128-fl-oz/10450114",
  "user_agent_type": "desktop",
  "geo_location": "United States",
  "context": [
    {
      "key": "zip",
      "value": "72712"
    }
  ]
}
```

### Objectives of the Diagnostic Run
1. **Network & Auth Handshake:** Verify that Oxylabs accepts the HTTP Basic Auth credentials and responds with HTTP 200 without challenge blockage.
2. **Parser Validation:** Confirm that the live HTML / JSON-LD returned in `results[0].content` is cleanly parsed by `OxylabsWalmartAdapter.parse_product_from_html` into the client's strict 22-field schema (`ProductRecord`).
3. **Data Integrity & Barcode Audit:** Confirm that the live GTIN12 (`078742351866`) is extracted into `upc` with leading zeros intact, regular price (`$3.48`) is extracted, and `gupc=""` / `unit_price=""` are maintained.
4. **Credential Redaction & Audit:** Verify that the raw response is archived in `logs/raw_responses/` with all authorization headers and secret tokens completely redacted.

---

## 3. Explicit Cost & Credential Blocker

> [!WARNING]
> **No live billable requests were run during this upgrade.**
> Per client constraints, executing billable requests without explicit prior approval and active client credentials is strictly prohibited.
>
> **Action Required to Run Diagnostic:**
> 1. Provide `OXYLABS_USERNAME` and `OXYLABS_PASSWORD` in the environment or `.env` file.
> 2. Approve the single-query test run.
> 3. Execute:
>    ```bash
>    python run.py --mode live --category-url "https://www.walmart.com/ip/10450114" --max-pages 1
>    ```
