#!/usr/bin/env python3
"""
extract_skincare_500.py — Extract 500 real Skin Care products from Walmart.com

Uses curl_cffi with impersonate="chrome124", extracts embedded Next.js JSON (__NEXT_DATA__),
validates each record strictly via core.schema.ProductRecord (22 fields),
and saves into:
- data/skin_care_products_500.jsonl
- data/skin_care_products_500.csv
- walmart_results.csv
- SQLite database: data/walmart.db
"""
import csv
import datetime
import json
import logging
import os
import re
import sys
from typing import Optional

from curl_cffi import requests
from core.schema import ProductRecord, extract_pack_and_weight, extract_upc_from_data
from core.deal_classifier import classify_deal, DealKind
from core.store import StoreDB
from walmart.scraper import _extract_embedded_json, _format_price

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("extract_skincare_500")

CATEGORIES = [
    ("https://www.walmart.com/browse/beauty/skin-care/1085666_1007039", "Skin Care"),
    ("https://www.walmart.com/browse/beauty/skin-care/1085666_1007040", "Facial & Skin Beauty"),
]

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
}


def infer_store_brand(brand: str, title: str) -> str:
    """Infer Walmart private label store brand."""
    check = f"{brand} {title}".lower()
    if "equate" in check:
        return "Equate"
    if "great value" in check:
        return "Great Value"
    if "mainstays" in check:
        return "Mainstays"
    return ""


def extract_item_to_record(item: dict, subcategory: str, today: str) -> Optional[ProductRecord]:
    name = item.get("name")
    u = item.get("canonicalUrl") or item.get("productUrl")
    if not name or not u or "/sp/" in str(u):
        return None

    if u.startswith("/"):
        u = f"https://www.walmart.com{u.split('?')[0]}"
    else:
        u = u.split("?")[0]

    # Price parsing
    p_info = item.get("priceInfo") or {}
    curr = p_info.get("linePrice") or p_info.get("itemPrice")
    if not curr and p_info.get("priceDetails"):
        for line in p_info["priceDetails"].get("priceLines", []):
            if line.get("lineType") == "CURRENT_PRICE":
                for val in line.get("values", []):
                    if val.get("key") == "PRICE":
                        curr = val.get("value")
    was = p_info.get("wasPrice")
    reg = _format_price(curr)
    sale = ""
    if was and curr and was != curr:
        reg = _format_price(was)
        sale = _format_price(curr)

    if not reg:
        # If no price, skip unpriced/out-of-stock placeholder
        return None

    # Image
    img = item.get("image") or ""

    # UPC
    upc, _ = extract_upc_from_data(item)
    if not upc:
        wupc = item.get("upc") or item.get("usItemId") or item.get("id") or ""
        digits = re.sub(r"\D", "", str(wupc))
        if len(digits) in (8, 12, 13, 14):
            upc = digits

    brand = item.get("brand") or item.get("productBrand") or ""
    store_brand = infer_store_brand(str(brand), name)

    # Badges / Promo / Deals
    promo_text = ""
    badges = item.get("badges") or {}
    if isinstance(badges, dict):
        flags = badges.get("flags") or []
        if isinstance(flags, list) and flags:
            texts = [f.get("text", "") for f in flags if isinstance(f, dict)]
            promo_text = " ".join(filter(None, texts))

    deal = classify_deal(promo_text) if promo_text else None
    vol_desc, vol_price, dig_desc, dig_price = "", "", "", ""
    if deal and deal.kind == DealKind.VOLUME:
        vol_desc, vol_price = deal.description, deal.price
    elif deal and deal.kind == DealKind.DIGITAL:
        dig_desc, dig_price = deal.description, deal.price

    record = ProductRecord(
        zipcode="10001",
        store_name="Walmart Secaucus Supercenter",
        store_location="400 Park Pl, Secaucus, NJ 07094",
        store_logo="https://i5.walmartimages.com/dfw/63fd9f59-b3e1/5353380e-7443-41bb-9271-e94fa1f7535b.v1.png",
        store_brand=store_brand,
        category="Beauty",
        sub_category=subcategory,
        product_title=name,
        weight=extract_pack_and_weight(name),
        regular_price=reg,
        sale_price=sale,
        volume_deals_description=vol_desc,
        volume_deals_price=vol_price,
        digital_deals_description=dig_desc,
        digital_deals_price=dig_price,
        image_url=img,
        url=u,
        upc=upc,
        gupc="",
        ppm="",
        unit_price="",
        crawl_date=today,
    )

    errors = record.validate()
    if errors:
        logger.debug("Validation error for %s: %s", u, errors)
        return None
    return record


def main():
    target_count = 500
    today = datetime.date.today().isoformat()
    seen_urls: set[str] = set()
    records: list[ProductRecord] = []

    logger.info("Starting extraction of %d Skin Care products from Walmart...", target_count)

    for base_url, subcat in CATEGORIES:
        for page in range(1, 15):
            if len(records) >= target_count:
                break
            url = f"{base_url}?page={page}"
            logger.info("Fetching %s (page %d)...", subcat, page)
            try:
                resp = requests.get(url, headers=HEADERS, impersonate="chrome124", timeout=30)
                if resp.status_code != 200:
                    logger.warning("HTTP %s on %s", resp.status_code, url)
                    continue
                data = _extract_embedded_json(resp.text)
                if not data:
                    logger.warning("No embedded JSON on page %d", page)
                    continue

                stacks = (
                    data.get("props", {})
                    .get("pageProps", {})
                    .get("initialData", {})
                    .get("searchResult", {})
                    .get("itemStacks", [])
                )
                items = stacks[0].get("items", []) if stacks else []
                new_on_page = 0
                for it in items:
                    u = it.get("canonicalUrl") or it.get("productUrl")
                    if not u:
                        continue
                    clean_u = u.split("?")[0]
                    if clean_u in seen_urls:
                        continue

                    rec = extract_item_to_record(it, subcat, today)
                    if rec:
                        seen_urls.add(clean_u)
                        records.append(rec)
                        new_on_page += 1
                        if len(records) >= target_count:
                            break

                logger.info(
                    "Page %d yielded %d valid records. Total collected: %d / %d",
                    page, new_on_page, len(records), target_count
                )
            except Exception as e:
                logger.error("Error on %s: %s", url, e)

    logger.info("Completed collection! Successfully collected %d valid records.", len(records))

    # Save to JSONL
    jsonl_path = "data/skin_care_products_500.jsonl"
    os.makedirs("data", exist_ok=True)
    with open(jsonl_path, "w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r.to_dict()) + "\n")
    logger.info("Saved %d records to %s", len(records), jsonl_path)

    # Save to CSV (semicolon delimited per project standard)
    csv_path = "data/skin_care_products_500.csv"
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f, delimiter=";")
        writer.writerow(list(records[0].to_dict().keys()))
        for r in records:
            writer.writerow(list(r.to_dict().values()))
    logger.info("Saved %d records to %s", len(records), csv_path)

    # Also update root walmart_results.csv
    root_csv_path = "walmart_results.csv"
    with open(root_csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f, delimiter=";")
        writer.writerow(list(records[0].to_dict().keys()))
        for r in records:
            writer.writerow(list(r.to_dict().values()))
    logger.info("Updated root results to %s", root_csv_path)

    # Save to SQLite data/walmart.db
    db_path = "data/walmart.db"
    db = StoreDB(db_path)
    run_id = f"walmart_skincare_500_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"
    db.begin_run(
        run_id,
        mode="live_curl_cffi",
        store_zipcode="10001",
        store_name="Walmart Secaucus Supercenter",
    )
    for r in records:
        r_dict = r.to_dict()
        p_key = db._product_key(r_dict)
        db.upsert_product(p_key, run_id, r_dict, is_test=0, data_source="live_curl_cffi")
    db.mark_unseen(run_id)
    db.finish_run(run_id, status="done")
    stats = db.get_stats()
    logger.info("Upserted to SQLite (%s). DB Stats: %s", db_path, stats)


if __name__ == "__main__":
    main()
