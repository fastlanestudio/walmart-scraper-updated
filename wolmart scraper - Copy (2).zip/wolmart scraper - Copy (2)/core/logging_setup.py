import logging
import json
import datetime
import sys
from pathlib import Path


class JsonLineFormatter(logging.Formatter):
    """Formats log records as single-line JSON objects for machine-readable audit."""

    EXTRA_FIELDS = [
        "run_id", "mode", "store_zipcode", "category", "sub_category",
        "product_url", "error_type", "products_scraped", "products_excluded",
        "retry_count", "proxy_response_ms", "canary_count", "block_detected",
        # Additional fields that may be passed via extra={}
        "store_name", "store_location", "errors", "weight",
    ]

    def format(self, record: logging.LogRecord) -> str:
        obj = {
            "ts": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        for f in self.EXTRA_FIELDS:
            if hasattr(record, f):
                obj[f] = getattr(record, f)
        if record.exc_info:
            obj["exc"] = self.formatException(record.exc_info)
        return json.dumps(obj, ensure_ascii=False)


class HumanReadableFormatter(logging.Formatter):
    """Human-friendly formatter for the console handler."""

    _FMT = "%(asctime)s [%(levelname)-8s] %(name)s — %(message)s"
    _DATE_FMT = "%Y-%m-%d %H:%M:%S"

    def __init__(self):
        super().__init__(fmt=self._FMT, datefmt=self._DATE_FMT)


def setup_logging(
    log_dir: str | Path,
    run_id: str,
    mode: str,
    level: int = logging.INFO,
) -> Path:
    """Configure the root logger with:
    - A console handler (human-readable format)
    - A JSONL file handler (machine-readable, named <run_id>.log.jsonl)

    Returns the absolute path to the JSONL log file.
    """
    log_dir = Path(log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)

    jsonl_path = log_dir / f"{run_id}.log.jsonl"

    root_logger = logging.getLogger()
    root_logger.setLevel(level)

    # Remove any previously attached handlers to avoid duplicate output
    # when setup_logging is called more than once (e.g., in tests)
    for h in list(root_logger.handlers):
        root_logger.removeHandler(h)
        h.close()

    # ── Console handler ────────────────────────────────────────────────────────
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    console_handler.setFormatter(HumanReadableFormatter())
    root_logger.addHandler(console_handler)

    # ── JSONL file handler ─────────────────────────────────────────────────────
    file_handler = logging.FileHandler(str(jsonl_path), encoding="utf-8")
    file_handler.setLevel(level)
    file_handler.setFormatter(JsonLineFormatter())
    root_logger.addHandler(file_handler)

    # Emit an initial log record so the file is created immediately
    logging.getLogger(__name__).info(
        "Logging initialised",
        extra={"run_id": run_id, "mode": mode},
    )

    return jsonl_path
