"""
core/walmart_api.py
Walmart API configuration, secure credential management, OAuth authentication,
readiness verification, and product extraction client.

Supports:
1. Walmart Online Pickup & Delivery (OPD) / Affiliate Retail API
   - Intended for retail catalog, store locator, and localized in-store pricing.
   - Credentials: WM_CONSUMER.ID (Consumer ID), Client ID, Client Secret.
2. Walmart Marketplace API
   - Intended for marketplace seller inventory, catalog, and order management.
   - Credentials: Client ID, Client Secret (OAuth 2.0 client_credentials flow).
"""

import os
import json
import time
import uuid
import base64
import logging
import datetime
import asyncio
from pathlib import Path
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Optional, Callable

import aiohttp

from core.schema import ProductRecord

logger = logging.getLogger(__name__)


class WalmartApiStatus(str, Enum):
    NOT_CONFIGURED = "NOT_CONFIGURED"
    CONFIGURATION_SAVED = "CONFIGURATION_SAVED"
    TESTING_CONNECTION = "TESTING_CONNECTION"
    CONNECTED = "CONNECTED"
    INVALID_CREDENTIALS = "INVALID_CREDENTIALS"
    ACCESS_DENIED = "ACCESS_DENIED"
    RATE_LIMITED = "RATE_LIMITED"
    NETWORK_ERROR = "NETWORK_ERROR"
    API_ERROR = "API_ERROR"


def mask_identifier(val: str) -> str:
    """Mask identifier safely showing partial chars if sufficiently long."""
    if not val:
        return ""
    val = val.strip()
    if len(val) <= 8:
        return "••••••••"
    return f"{val[:4]}••••••••{val[-4:]}"


def mask_secret(val: str) -> str:
    """Mask secret completely. Never reveal prefix or suffix."""
    return "••••••••••••" if bool(val and val.strip()) else ""


@dataclass
class WalmartApiConfig:
    integration_type: str = "opd_retail"  # 'opd_retail' or 'marketplace'
    environment: str = "production"       # 'production' or 'sandbox'
    consumer_id: str = ""                # WM_CONSUMER.ID
    client_id: str = ""                  # OAuth Client ID
    client_secret: str = ""              # OAuth Client Secret
    status: WalmartApiStatus = WalmartApiStatus.NOT_CONFIGURED
    last_test_timestamp: Optional[str] = None
    last_test_message: str = "Credentials not yet configured."
    verified_endpoints: list[str] = field(default_factory=list)

    def is_configured(self) -> bool:
        if self.integration_type == "opd_retail":
            return bool(self.consumer_id.strip() and self.client_id.strip() and self.client_secret.strip())
        elif self.integration_type == "marketplace":
            return bool(self.client_id.strip() and self.client_secret.strip())
        return False

    def to_masked_dict(self) -> dict:
        return {
            "integration_type": self.integration_type,
            "environment": self.environment,
            "consumer_id": mask_identifier(self.consumer_id),
            "client_id": mask_identifier(self.client_id),
            "has_client_secret": bool(self.client_secret.strip()),
            "client_secret_masked": mask_secret(self.client_secret),
            "status": self.status.value if isinstance(self.status, WalmartApiStatus) else str(self.status),
            "last_test_timestamp": self.last_test_timestamp,
            "last_test_message": self.last_test_message,
            "verified_endpoints": self.verified_endpoints,
            "is_configured": self.is_configured(),
            "is_connected": self.status == WalmartApiStatus.CONNECTED,
        }


class WalmartApiManager:
    """Manages persistent credentials, OAuth token exchange, and API queries."""

    SECRETS_DIR = Path(".secrets")
    SECRETS_FILE = SECRETS_DIR / "walmart_api.json"

    def __init__(self, secrets_path: Optional[Path] = None):
        self.secrets_path = secrets_path or self.SECRETS_FILE
        self._config: WalmartApiConfig = self._load_initial_config()
        self._cached_token: Optional[str] = None
        self._token_expires_at: float = 0.0

    @property
    def config(self) -> WalmartApiConfig:
        return self._config

    def _load_initial_config(self) -> WalmartApiConfig:
        """Load configuration from local secrets file or environment fallback."""
        if self.secrets_path.exists():
            try:
                with open(self.secrets_path, "r", encoding="utf-8") as f:
                    raw = json.load(f)
                    cfg = WalmartApiConfig(
                        integration_type=raw.get("integration_type", "opd_retail"),
                        environment=raw.get("environment", "production"),
                        consumer_id=raw.get("consumer_id", ""),
                        client_id=raw.get("client_id", ""),
                        client_secret=raw.get("client_secret", ""),
                        status=WalmartApiStatus(raw.get("status", WalmartApiStatus.CONFIGURATION_SAVED.value)),
                        last_test_timestamp=raw.get("last_test_timestamp"),
                        last_test_message=raw.get("last_test_message", "Loaded from secure configuration."),
                        verified_endpoints=raw.get("verified_endpoints", []),
                    )
                    # Sync to os.environ for legacy readers
                    self._sync_env(cfg)
                    return cfg
            except Exception as e:
                logger.warning(f"Failed to parse {self.secrets_path}: {e}")

        # Fallback to environment variables
        consumer_id = os.environ.get("WALMART_CONSUMER_ID", "")
        client_id = os.environ.get("WALMART_CLIENT_ID", "")
        # Backward compatibility with legacy WALMART_API_KEY naming
        api_key_legacy = os.environ.get("WALMART_API_KEY", "")
        if not client_id and api_key_legacy:
            client_id = api_key_legacy

        client_secret = os.environ.get("WALMART_CLIENT_SECRET", "")
        env = os.environ.get("WALMART_API_ENV", "production")
        itype = os.environ.get("WALMART_INTEGRATION_TYPE", "opd_retail")

        status = WalmartApiStatus.NOT_CONFIGURED
        msg = "Credentials not configured. Enter your API credentials below."
        if (itype == "opd_retail" and consumer_id and client_id and client_secret) or \
           (itype == "marketplace" and client_id and client_secret):
            status = WalmartApiStatus.CONFIGURATION_SAVED
            msg = "Credentials loaded from environment."

        return WalmartApiConfig(
            integration_type=itype,
            environment=env,
            consumer_id=consumer_id,
            client_id=client_id,
            client_secret=client_secret,
            status=status,
            last_test_message=msg,
        )

    def _sync_env(self, cfg: WalmartApiConfig) -> None:
        """Update runtime environment variables without modifying unrelated keys."""
        if cfg.consumer_id:
            os.environ["WALMART_CONSUMER_ID"] = cfg.consumer_id
        if cfg.client_id:
            os.environ["WALMART_CLIENT_ID"] = cfg.client_id
            os.environ["WALMART_API_KEY"] = cfg.client_id  # legacy compatibility
        if cfg.client_secret:
            os.environ["WALMART_CLIENT_SECRET"] = cfg.client_secret
        os.environ["WALMART_API_ENV"] = cfg.environment
        os.environ["WALMART_INTEGRATION_TYPE"] = cfg.integration_type

    def save_config(self, data: dict) -> WalmartApiConfig:
        """Validate, persist to local secrets file, and update runtime configuration."""
        integration_type = data.get("integration_type", "opd_retail")
        if integration_type not in ("opd_retail", "marketplace"):
            raise ValueError("Integration type must be 'opd_retail' or 'marketplace'.")

        environment = data.get("environment", "production")
        if environment not in ("production", "sandbox"):
            raise ValueError("Environment must be 'production' or 'sandbox'.")

        consumer_id = str(data.get("consumer_id", "")).strip()
        client_id = str(data.get("client_id", "")).strip()
        new_secret = str(data.get("client_secret", "")).strip()

        # If user leaves secret empty when saving an edit, retain existing secret if present
        if not new_secret and self._config.client_secret:
            client_secret = self._config.client_secret
        else:
            client_secret = new_secret

        if integration_type == "opd_retail":
            if not consumer_id:
                raise ValueError("Walmart Consumer ID (WM_CONSUMER.ID) is required for OPD / Retail API.")
            if not client_id:
                raise ValueError("Client ID is required for OPD / Retail API.")
            if not client_secret:
                raise ValueError("Client Secret is required for OPD / Retail API.")
        elif integration_type == "marketplace":
            if not client_id:
                raise ValueError("Client ID is required for Marketplace API.")
            if not client_secret:
                raise ValueError("Client Secret is required for Marketplace API.")

        cfg = WalmartApiConfig(
            integration_type=integration_type,
            environment=environment,
            consumer_id=consumer_id,
            client_id=client_id,
            client_secret=client_secret,
            status=WalmartApiStatus.CONFIGURATION_SAVED,
            last_test_timestamp=None,
            last_test_message="Configuration saved successfully. Click 'Test Connection' to verify.",
            verified_endpoints=[],
        )

        # Atomic file write
        self.secrets_path.parent.mkdir(parents=True, exist_ok=True)
        temp_file = self.secrets_path.with_suffix(".tmp")
        payload = {
            "integration_type": cfg.integration_type,
            "environment": cfg.environment,
            "consumer_id": cfg.consumer_id,
            "client_id": cfg.client_id,
            "client_secret": cfg.client_secret,
            "status": cfg.status.value,
            "last_test_timestamp": cfg.last_test_timestamp,
            "last_test_message": cfg.last_test_message,
            "verified_endpoints": cfg.verified_endpoints,
        }
        with open(temp_file, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
        temp_file.replace(self.secrets_path)

        self._config = cfg
        self._sync_env(cfg)
        self._cached_token = None
        self._token_expires_at = 0.0

        logger.info(f"Walmart API configuration saved (type={cfg.integration_type}, env={cfg.environment})")
        return cfg

    def clear_config(self) -> None:
        """Clear all stored credentials and reset status."""
        if self.secrets_path.exists():
            try:
                self.secrets_path.unlink()
            except Exception as e:
                logger.warning(f"Error removing {self.secrets_path}: {e}")

        # Clear environment variables
        for k in ("WALMART_CONSUMER_ID", "WALMART_CLIENT_ID", "WALMART_CLIENT_SECRET", "WALMART_API_KEY"):
            os.environ.pop(k, None)

        self._config = WalmartApiConfig(
            status=WalmartApiStatus.NOT_CONFIGURED,
            last_test_message="Credentials cleared. Enter new credentials to configure.",
        )
        self._cached_token = None
        self._token_expires_at = 0.0
        logger.info("Walmart API credentials cleared.")

    def get_token_url(self) -> str:
        if self._config.integration_type == "marketplace":
            if self._config.environment == "sandbox":
                return "https://sandbox.walmartapis.com/v3/token"
            return "https://marketplace.walmartapis.com/v3/token"
        else:  # opd_retail
            if self._config.environment == "sandbox":
                return "https://sandbox.developer.api.walmart.com/api-service/token"
            return "https://developer.api.walmart.com/api-service/token"

    def get_store_locator_url(self, zipcode: str) -> str:
        if self._config.environment == "sandbox":
            return f"https://sandbox.developer.api.walmart.com/api-service/engine/v1/stores?zip={zipcode}"
        return f"https://developer.api.walmart.com/api-service/engine/v1/stores?zip={zipcode}"

    async def get_access_token(self, session: aiohttp.ClientSession) -> str:
        """Acquire or return cached OAuth 2.0 access token according to documented expiration."""
        now = time.time()
        if self._cached_token and now < (self._token_expires_at - 60):
            return self._cached_token

        if not self._config.is_configured():
            raise ValueError("Cannot acquire token: API credentials are not configured.")

        token_url = self.get_token_url()
        credentials_b64 = base64.b64encode(
            f"{self._config.client_id}:{self._config.client_secret}".encode("utf-8")
        ).decode("utf-8")

        headers = {
            "Authorization": f"Basic {credentials_b64}",
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": "application/json",
            "WM_SVC.NAME": "Walmart API Client",
            "WM_QOS.CORRELATION_ID": uuid.uuid4().hex,
        }
        if self._config.integration_type == "opd_retail" and self._config.consumer_id:
            headers["WM_CONSUMER.ID"] = self._config.consumer_id

        data = {"grant_type": "client_credentials"}

        try:
            async with session.post(token_url, headers=headers, data=data, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                body_text = await resp.text()

                if resp.status == 200:
                    try:
                        resp_json = json.loads(body_text)
                    except json.JSONDecodeError:
                        raise RuntimeError(f"Invalid non-JSON response from token endpoint: {body_text[:100]}")

                    token = resp_json.get("access_token") or resp_json.get("token")
                    if not token:
                        raise RuntimeError(f"Token endpoint returned 200 OK but missing 'access_token' field.")

                    expires_in = int(resp_json.get("expires_in", 900))
                    self._cached_token = token
                    self._token_expires_at = now + expires_in
                    return token

                elif resp.status in (401, 403):
                    msg = "Authentication failed: Walmart rejected the Client ID / Client Secret credentials (HTTP 401 Unauthorized)."
                    if resp.status == 403:
                        msg = "Access denied: Account lacks permission to access Walmart API token endpoint (HTTP 403 Forbidden)."
                    raise aiohttp.ClientResponseError(
                        request_info=resp.request_info,
                        history=resp.history,
                        status=resp.status,
                        message=msg,
                    )
                elif resp.status == 429:
                    raise aiohttp.ClientResponseError(
                        request_info=resp.request_info,
                        history=resp.history,
                        status=429,
                        message="Rate limited: Walmart API call rate limit exceeded.",
                    )
                else:
                    raise aiohttp.ClientResponseError(
                        request_info=resp.request_info,
                        history=resp.history,
                        status=resp.status,
                        message=f"Walmart token endpoint returned HTTP {resp.status}: {body_text[:120]}",
                    )
        except (aiohttp.ClientConnectorError, asyncio.TimeoutError) as ce:
            raise RuntimeError(f"Network error: Unable to reach Walmart API gateway ({ce}). Check internet connection or firewall.")

    async def test_connection(self, zipcode: str = "10001") -> dict:
        """
        Execute a genuine authenticated test request.
        Validates:
        1. Token issuance (client credentials handshake).
        2. Read-only resource access (Store locator endpoint for OPD / Retail, or Account test for Marketplace).
        Distinguishes token success from endpoint authorization.
        """
        if not self._config.is_configured():
            self._config.status = WalmartApiStatus.NOT_CONFIGURED
            self._config.last_test_message = "Cannot test connection: Required credentials are missing."
            return self._config.to_masked_dict()

        self._config.status = WalmartApiStatus.TESTING_CONNECTION
        now_iso = datetime.datetime.now(datetime.timezone.utc).isoformat()
        self._config.last_test_timestamp = now_iso
        self._config.verified_endpoints = []

        timeout = aiohttp.ClientTimeout(total=20)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            # Step 1: Token Acquisition
            try:
                token = await self.get_access_token(session)
                self._config.verified_endpoints.append("oauth2_token_exchange")
            except aiohttp.ClientResponseError as re:
                if re.status == 401:
                    self._config.status = WalmartApiStatus.INVALID_CREDENTIALS
                    self._config.last_test_message = (
                        "Invalid credentials: The supplied Client ID or Client Secret was rejected by Walmart API Gateway (HTTP 401)."
                    )
                elif re.status == 403:
                    self._config.status = WalmartApiStatus.ACCESS_DENIED
                    self._config.last_test_message = (
                        "Access denied: Account lacks permission to access Walmart OAuth token endpoint (HTTP 403 Forbidden)."
                    )
                elif re.status == 429:
                    self._config.status = WalmartApiStatus.RATE_LIMITED
                    self._config.last_test_message = "Rate limited: API call threshold exceeded (HTTP 429)."
                else:
                    self._config.status = WalmartApiStatus.API_ERROR
                    self._config.last_test_message = f"API error during token request: HTTP {re.status} ({re.message})."
                return self._config.to_masked_dict()
            except RuntimeError as rte:
                err_str = str(rte)
                if "Network error" in err_str:
                    self._config.status = WalmartApiStatus.NETWORK_ERROR
                    self._config.last_test_message = err_str
                else:
                    self._config.status = WalmartApiStatus.API_ERROR
                    self._config.last_test_message = err_str
                return self._config.to_masked_dict()
            except Exception as e:
                self._config.status = WalmartApiStatus.API_ERROR
                self._config.last_test_message = f"Unexpected error during token exchange: {e}"
                return self._config.to_masked_dict()

            # Step 2: Read-Only Resource Access Verification
            if self._config.integration_type == "opd_retail":
                store_url = self.get_store_locator_url(zipcode)
                req_headers = {
                    "WM_SEC.ACCESS_TOKEN": token,
                    "WM_CONSUMER.ID": self._config.consumer_id,
                    "WM_SVC.NAME": "Walmart Retail API",
                    "WM_QOS.CORRELATION_ID": uuid.uuid4().hex,
                    "Accept": "application/json",
                }
                try:
                    async with session.get(store_url, headers=req_headers) as s_resp:
                        s_text = await s_resp.text()
                        if s_resp.status == 200:
                            self._config.status = WalmartApiStatus.CONNECTED
                            self._config.verified_endpoints.append("store_locator_v1")
                            self._config.last_test_message = (
                                f"Connected! OAuth token verified and store locator endpoint confirmed for ZIP {zipcode}."
                            )
                        elif s_resp.status == 403:
                            # Token is valid, but resource endpoint is not authorized
                            self._config.status = WalmartApiStatus.ACCESS_DENIED
                            self._config.last_test_message = (
                                "OAuth token issued successfully, but account lacks permission for the Retail Store / Product Catalog endpoint "
                                "(HTTP 403 Forbidden). Account requires approved 'Retail Catalog & Stores API' subscription on developer.walmart.com."
                            )
                        elif s_resp.status == 404:
                            self._config.status = WalmartApiStatus.CONNECTED
                            self._config.last_test_message = (
                                f"OAuth token issued successfully. Store locator returned 404 (no physical store found for ZIP {zipcode})."
                            )
                        else:
                            self._config.status = WalmartApiStatus.API_ERROR
                            self._config.last_test_message = (
                                f"OAuth token issued, but store lookup returned HTTP {s_resp.status}: {s_text[:100]}"
                            )
                except Exception as e:
                    self._config.status = WalmartApiStatus.NETWORK_ERROR
                    self._config.last_test_message = f"Token succeeded, but store query failed with network error: {e}"

            elif self._config.integration_type == "marketplace":
                # For marketplace, test the marketplace feed/item health
                market_url = (
                    "https://sandbox.walmartapis.com/v3/feeds"
                    if self._config.environment == "sandbox"
                    else "https://marketplace.walmartapis.com/v3/feeds"
                )
                req_headers = {
                    "WM_SEC.ACCESS_TOKEN": token,
                    "WM_SVC.NAME": "Walmart Marketplace",
                    "WM_QOS.CORRELATION_ID": uuid.uuid4().hex,
                    "Accept": "application/json",
                }
                try:
                    async with session.get(market_url, headers=req_headers) as m_resp:
                        if m_resp.status in (200, 400):  # 400 is common for feeds without feedType parameter
                            self._config.status = WalmartApiStatus.CONNECTED
                            self._config.verified_endpoints.append("marketplace_auth_v3")
                            self._config.last_test_message = (
                                "Connected to Walmart Marketplace API. Note: Marketplace API is intended for seller operations, "
                                "not customer in-store catalog or localized grocery pricing."
                            )
                        elif m_resp.status == 403:
                            self._config.status = WalmartApiStatus.ACCESS_DENIED
                            self._config.last_test_message = (
                                "Marketplace OAuth token issued, but seller account lacks permissions for feed/catalog endpoints (HTTP 403)."
                            )
                        else:
                            self._config.status = WalmartApiStatus.CONNECTED
                            self._config.last_test_message = (
                                f"Marketplace OAuth token verified. Base endpoint returned HTTP {m_resp.status}."
                            )
                except Exception as e:
                    self._config.status = WalmartApiStatus.NETWORK_ERROR
                    self._config.last_test_message = f"Marketplace token issued, but endpoint verification failed: {e}"

        # Persist test outcome
        self._save_test_result()
        return self._config.to_masked_dict()

    def _save_test_result(self) -> None:
        """Persist the test outcome to the secrets file if it exists."""
        if self.secrets_path.exists():
            try:
                with open(self.secrets_path, "r", encoding="utf-8") as f:
                    raw = json.load(f)
                raw["status"] = self._config.status.value
                raw["last_test_timestamp"] = self._config.last_test_timestamp
                raw["last_test_message"] = self._config.last_test_message
                raw["verified_endpoints"] = self._config.verified_endpoints
                temp_file = self.secrets_path.with_suffix(".tmp")
                with open(temp_file, "w", encoding="utf-8") as f:
                    json.dump(raw, f, indent=2)
                temp_file.replace(self.secrets_path)
            except Exception as e:
                logger.warning(f"Failed to update test result in {self.secrets_path}: {e}")

    async def collect_products(
        self,
        zipcode: str,
        category_url: str,
        target_count: int = 50,
        callback: Optional[Callable[[str, int, int], None]] = None,
        cancel_token: Optional[dict] = None,
    ) -> list[ProductRecord]:
        """
        Collect real products via the configured Walmart API.
        Never fabricates records. If endpoint returns 0 items or lacks catalog access,
        returns exact count or raises actionable authorization error.
        """
        if not self._config.is_configured():
            raise RuntimeError(
                "Walmart API credentials are not configured. Open 'Walmart API Configuration' in the dashboard."
            )

        if self._config.status in (WalmartApiStatus.INVALID_CREDENTIALS, WalmartApiStatus.ACCESS_DENIED):
            raise RuntimeError(
                f"Cannot collect via Walmart API: {self._config.last_test_message}. Please resolve credentials or access."
            )

        timeout = aiohttp.ClientTimeout(total=30)
        records: list[ProductRecord] = []

        async with aiohttp.ClientSession(timeout=timeout) as session:
            token = await self.get_access_token(session)

            if callback:
                callback("Authenticated with Walmart API. Querying store location...", 0, target_count)

            store_name = f"Walmart Store ({zipcode})"
            store_location = f"ZIP {zipcode}"

            # Step 1: Look up store for localized pricing if using opd_retail
            if self._config.integration_type == "opd_retail":
                store_url = self.get_store_locator_url(zipcode)
                headers = {
                    "WM_SEC.ACCESS_TOKEN": token,
                    "WM_CONSUMER.ID": self._config.consumer_id,
                    "WM_SVC.NAME": "Walmart Retail API",
                    "WM_QOS.CORRELATION_ID": uuid.uuid4().hex,
                    "Accept": "application/json",
                }
                try:
                    async with session.get(store_url, headers=headers) as s_resp:
                        if s_resp.status == 200:
                            s_data = await s_resp.json()
                            stores = s_data if isinstance(s_data, list) else s_data.get("stores", [])
                            if stores:
                                primary = stores[0]
                                store_name = primary.get("name") or primary.get("displayName") or store_name
                                store_location = primary.get("streetAddress") or primary.get("address", {}).get("street") or store_location
                        elif s_resp.status == 403:
                            raise RuntimeError(
                                "Walmart Retail API returned HTTP 403 Forbidden for store lookup. "
                                "Your account lacks the 'Retail Catalog & Stores API' permission. "
                                "Please request catalog access on developer.walmart.com."
                            )
                except aiohttp.ClientResponseError as e:
                    if e.status == 403:
                        raise RuntimeError(
                            "Walmart Retail API returned HTTP 403 Forbidden. Your account lacks catalog permissions."
                        )
                except Exception as e:
                    logger.warning(f"Store lookup failed: {e}")

            # Step 2: Query products
            # For opd_retail / affiliate retail API, items query
            if callback:
                callback(f"Querying product catalog for {store_name}...", 0, target_count)

            # Note: If client's account has specific catalog feed or item endpoint
            # In official Walmart developer API: GET /api-service/engine/v1/items or /v1/search
            catalog_url = (
                f"https://developer.api.walmart.com/api-service/engine/v1/search?query=grocery&storeId={zipcode}"
                if self._config.integration_type == "opd_retail"
                else f"https://marketplace.walmartapis.com/v3/items?limit={min(target_count, 50)}"
            )

            req_headers = {
                "WM_SEC.ACCESS_TOKEN": token,
                "WM_SVC.NAME": "Walmart API Client",
                "WM_QOS.CORRELATION_ID": uuid.uuid4().hex,
                "Accept": "application/json",
            }
            if self._config.integration_type == "opd_retail" and self._config.consumer_id:
                req_headers["WM_CONSUMER.ID"] = self._config.consumer_id

            try:
                async with session.get(catalog_url, headers=req_headers) as c_resp:
                    if c_resp.status == 200:
                        c_data = await c_resp.json()
                        raw_items = c_data.get("items") or c_data.get("ItemResponse") or []
                        crawl_date = datetime.date.today().isoformat()

                        for item in raw_items[:target_count]:
                            if cancel_token and cancel_token.get("cancelled"):
                                break

                            title = item.get("name") or item.get("title") or item.get("productName", "")
                            if not title:
                                continue

                            url = item.get("productUrl") or item.get("url") or f"https://www.walmart.com/ip/{item.get('itemId', '')}"
                            price = str(item.get("salePrice") or item.get("price") or item.get("offerPrice", ""))
                            if price and not price.startswith("$"):
                                price = f"${float(price):.2f}"

                            rec = ProductRecord(
                                zipcode=zipcode,
                                store_name=store_name,
                                store_location=store_location,
                                store_logo="",
                                store_brand=item.get("brandName", ""),
                                category=item.get("categoryNode", "Grocery"),
                                sub_category=item.get("subCategory", "Products"),
                                product_title=title,
                                weight=item.get("size", ""),
                                regular_price=price,
                                sale_price="",
                                volume_deals_description="",
                                volume_deals_price="",
                                digital_deals_description="",
                                digital_deals_price="",
                                image_url=item.get("largeImage") or item.get("imageUrl", ""),
                                url=url,
                                upc=item.get("upc", ""),
                                gupc="",
                                ppm="",
                                unit_price="",
                                crawl_date=crawl_date,
                            )
                            records.append(rec)
                            if callback:
                                callback(f"API item retrieved: {title[:32]}...", len(records), target_count)
                    elif c_resp.status == 403:
                        raise RuntimeError(
                            "Walmart API returned HTTP 403 Forbidden for product catalog query. "
                            "Active retail catalog subscription is required to retrieve product data via API."
                        )
                    elif c_resp.status == 404:
                        logger.info("Walmart API product endpoint returned 404 (no items found).")
                    else:
                        c_err = await c_resp.text()
                        logger.warning(f"Walmart API catalog query returned HTTP {c_resp.status}: {c_err[:120]}")
            except aiohttp.ClientResponseError as ce:
                if ce.status == 403:
                    raise RuntimeError("Walmart API access denied (HTTP 403). Retail catalog permission required.")
                raise RuntimeError(f"Walmart API query error: {ce}")

            return records


# Global singleton instance
walmart_api_manager = WalmartApiManager()
