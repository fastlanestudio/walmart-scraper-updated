import re
from dataclasses import dataclass
from enum import Enum
from typing import Optional


class DealKind(Enum):
    VOLUME = "volume"
    DIGITAL = "digital"
    SALE = "sale"
    NONE = "none"


@dataclass
class DealResult:
    kind: DealKind
    description: str = ""
    price: str = ""
    savings: str = ""


# Price extraction pattern: $X.XX or $X
_PRICE_PATTERN = re.compile(r'\$\d+(?:\.\d{1,2})?')

# "now $X.XX" pattern for "save $X with explicit new price"
_NOW_PRICE_PATTERN = re.compile(r'\bnow\s+(\$\d+(?:\.\d{1,2})?)', re.IGNORECASE)

# N for $X pattern
_N_FOR_PATTERN = re.compile(r'\b\d+\s+for\s+\$\d+(?:\.\d{1,2})?\b', re.IGNORECASE)

# Buy N get N free / N% off
_BUY_GET_PATTERN = re.compile(
    r'\bbuy\s+\d+\s+get\s+\d+\s+(free|\d+%\s*off)\b',
    re.IGNORECASE,
)

# X% off — NOT preceded by "clip" or "coupon" (checked by context)
_PCT_OFF_PATTERN = re.compile(r'\b\d+%\s*off\b', re.IGNORECASE)
_COUPON_PCT_CONTEXT = re.compile(r'\b(clip|coupon)\b', re.IGNORECASE)

# Digital deal patterns
_DIGITAL_PATTERNS = [
    re.compile(r'\bclip\s+coupon\b', re.IGNORECASE),
    re.compile(r'\bdigital\s+coupon\b', re.IGNORECASE),
    re.compile(r'\bclipping\b', re.IGNORECASE),
    re.compile(r'\bactivate\b', re.IGNORECASE),
    re.compile(r'\bwalmart\+\s+exclusive\b', re.IGNORECASE),
    re.compile(r'\bwalmart\s+plus\s+exclusive\b', re.IGNORECASE),
    re.compile(r'\bmember\s+exclusive\b', re.IGNORECASE),
    re.compile(r'\bsavings\s+catcher\b', re.IGNORECASE),
    re.compile(r'\badd\s+to\s+cart\s+for\s+price\b', re.IGNORECASE),
]

# Volume deal simple keyword patterns
_VOLUME_KEYWORD_PATTERNS = [
    re.compile(r'\bbogo\b', re.IGNORECASE),
    re.compile(r'\bb1g1\b', re.IGNORECASE),
    re.compile(r'\bbuy\s+one\s+get\s+one\b', re.IGNORECASE),
    re.compile(r'\brollback\b', re.IGNORECASE),
    re.compile(r'\bclearance\b', re.IGNORECASE),
    re.compile(r'\breduced\s+price\b', re.IGNORECASE),
    re.compile(r'\bspecial\s+buy\b', re.IGNORECASE),
    re.compile(r'\bflash\s+pick\b', re.IGNORECASE),
    re.compile(r'\blimited\s+time\b', re.IGNORECASE),
    re.compile(r'\beveryday\s+low\s+price\b', re.IGNORECASE),
    re.compile(r'\bprice\s+drop\b', re.IGNORECASE),
]


def _extract_price(text: str) -> str:
    """Extract the first explicit price from text, or '' if none."""
    match = _PRICE_PATTERN.search(text)
    return match.group(0) if match else ""


def _is_digital(text: str) -> bool:
    return any(p.search(text) for p in _DIGITAL_PATTERNS)


def _is_volume(text: str) -> bool:
    # N for $X
    if _N_FOR_PATTERN.search(text):
        return True
    # buy N get N free/off
    if _BUY_GET_PATTERN.search(text):
        return True
    # BOGO, rollback, clearance, etc.
    if any(p.search(text) for p in _VOLUME_KEYWORD_PATTERNS):
        return True
    # X% off — only if NOT preceded by clip/coupon context
    if _PCT_OFF_PATTERN.search(text) and not _COUPON_PCT_CONTEXT.search(text):
        return True
    # "save $X" (with or without "now $X.XX")
    if re.search(r'\bsave\s+\$\d+', text, re.IGNORECASE):
        return True
    return False


def classify_deal(promo_text: str) -> DealResult:
    """
    Classify a promotional text string into a DealResult.

    Rules:
    - If text is specifically 'Rollback $X.XX' (Rollback with price), it is SALE (discounted price).
    - Keyword 'Rollback' by itself is treated as VOLUME.
    - If text is 'Clip Coupon: Save $X', payable price is empty and savings is '$X'.
    - If text is 'Digital coupon save $X', price is '$X' and kind is DIGITAL.
    - Extracts price from text if an explicit payable price is present.
    """
    if not promo_text or not promo_text.strip():
        return DealResult(kind=DealKind.NONE)

    text = promo_text.strip()

    # Rollback with explicit price check (e.g. 'Rollback $3.99')
    if re.search(r'\brollback\s+\$\d+', text, re.IGNORECASE):
        price = _extract_price(text)
        return DealResult(kind=DealKind.SALE, description=promo_text, price=price)

    is_dig = _is_digital(text)
    is_vol = _is_volume(text)

    if is_dig:
        # Check if specifically "Clip Coupon: Save $X" or similar
        if re.search(r'\bclip\s+coupon\b', text, re.IGNORECASE) and re.search(r'\bsave\s+\$\d+', text, re.IGNORECASE):
            save_match = re.search(r'\bsave\s+(\$\d+(?:\.\d{1,2})?)', text, re.IGNORECASE)
            now_match = _NOW_PRICE_PATTERN.search(text)
            price = now_match.group(1) if now_match else ""
            savings = save_match.group(1) if save_match else ""
            return DealResult(kind=DealKind.DIGITAL, description=promo_text, price=price, savings=savings)

        price = _extract_price(text)
        return DealResult(kind=DealKind.DIGITAL, description=promo_text, price=price)

    if is_vol:
        price = _extract_price(text)
        now_match = _NOW_PRICE_PATTERN.search(text)
        if now_match:
            price = now_match.group(1)
        return DealResult(kind=DealKind.VOLUME, description=promo_text, price=price)

    return DealResult(kind=DealKind.NONE)

    return DealResult(kind=DealKind.NONE)
