"""core/oxylabs_adapter.py
Oxylabs Realtime Web Scraper API adapter for Walmart catalog data.

Uses the Classic Oxylabs Realtime API:
  - Endpoint: https://realtime.oxylabs.io/v1/queries
  - Auth: HTTP Basic Auth using OXYLABS_USERNAME and OXYLABS_PASSWORD
  - Source: walmart
  - Response parsing: 22-field ProductRecord from JSON-LD / __NEXT_DATA__ / HTML
  - Raw response logging to logs/raw_responses/ with sanitized credentials
"""
import os
import re
import json
import uuid
import datetime
import logging
from typing import Optional, Callable, Any
from urllib.parse import urlparse

import urllib.request
import urllib.error
import base64

from core.schema import ProductRecord, extract_upc_from_data, extract_pack_and_weight, is_approx_weight
from core.deal_classifier import classify_deal, DealKind
from core.source_adapter import BaseSourceAdapter, AdapterStatus

logger = logging.getLogger(__name__)

OXYLABS_REALTIME_URL = "https://realtime.oxylabs.io/v1/queries"
RAW_RESPONSE_DIR = os.path.join("logs", "raw_responses")


def sanitize_credentials(text: str, username: str = "", password: str = "") -> str:
    """Remove username, password, or basic auth headers from text/urls."""
    if not text:
        return ""
    sanitized = str(text)
    if password:
        sanitized = sanitized.replace(password, "***REDACTED***")
    if username:
        sanitized = sanitized.replace(username, "***REDACTED_USER***")
    sanitized = re.sub(r'Basic\s+[A-Za-z0-9+/=]+', 'Basic ***REDACTED***', sanitized)
    sanitized = re.sub(r'://[^:]+:[^@]+@', '://***:***@', sanitized)
    return sanitized


class OxylabsWalmartAdapter(BaseSourceAdapter):
    """Oxylabs Realtime Web Scraper API adapter for Walmart.com."""

    def __init__(
        self,
        username: Optional[str] = None,
        password: Optional[str] = None,
        api_url: str = OXYLABS_REALTIME_URL,
    ):
        self._username = username or os.environ.get("OXYLABS_USERNAME", "")
        self._password = password or os.environ.get("OXYLABS_PASSWORD", "")
        self.api_url = api_url
        os.makedirs(RAW_RESPONSE_DIR, exist_ok=True)

    @property
    def name(self) -> str:
        return "oxylabs"

    def is_configured(self) -> bool:
        user = self._username or os.environ.get("OXYLABS_USERNAME", "")
        pw = self._password or os.environ.get("OXYLABS_PASSWORD", "")
        return bool(user.strip() and pw.strip())

    async def check_readiness(self, config: dict) -> AdapterStatus:
        user = (config.get("oxylabs_username") or self._username or os.environ.get("OXYLABS_USERNAME", "")).strip()
        pw = (config.get("oxylabs_password") or self._password or os.environ.get("OXYLABS_PASSWORD", "")).strip()

        if not user or not pw:
            return AdapterStatus(
                name=self.name,
                status="not_configured",
                message=(
                    "Oxylabs credentials (OXYLABS_USERNAME, OXYLABS_PASSWORD) not configured. "
                    "Set environment variables or configure credentials to enable Oxylabs collection."
                ),
                capabilities=["oxylabs_realtime_api", "walmart_source", "proxy_managed"],
                supports_live=True,
            )

        masked_user = user[:2] + "***" if len(user) > 2 else "***"
        return AdapterStatus(
            name=self.name,
            status="ready",
            message=f"Oxylabs Realtime API configured for user '{masked_user}'. Ready for authorized requests.",
            capabilities=["oxylabs_realtime_api", "walmart_source", "geo_targeting"],
            supports_live=True,
        )

    def build_payload(
        self,
        url: str,
        zipcode: str = "10001",
        store_id: Optional[str] = None,
    ) -> dict:
        """Construct the Oxylabs realtime query payload for Walmart."""
        context = [{"key": "zip", "value": str(zipcode).strip()}]
        if store_id and str(store_id).strip():
            context.append({"key": "store_id", "value": str(store_id).strip()})

        return {
            "source": "walmart",
            "url": url,
            "user_agent_type": "desktop",
            "geo_location": "United States",
            "context": context,
        }

    def execute_query_sync(self, payload: dict) -> dict:
        """Execute HTTP POST to Oxylabs Realtime API synchronously."""
        user = self._username or os.environ.get("OXYLABS_USERNAME", "")
        pw = self._password or os.environ.get("OXYLABS_PASSWORD", "")

        if not user or not pw:
            raise ValueError("Oxylabs credentials (OXYLABS_USERNAME, OXYLABS_PASSWORD) not configured.")

        body_bytes = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            self.api_url,
            data=body_bytes,
            headers={
                "Content-Type": "application/json",
                "User-Agent": "WalmartScraper/2.0",
            },
            method="POST",
        )

        creds = f"{user}:{pw}".encode("utf-8")
        basic_header = f"Basic {base64.b64encode(creds).decode('utf-8')}"
        req.add_header("Authorization", basic_header)

        timestamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%d_%H%M%S_%f")
        query_id = uuid.uuid4().hex[:8]

        try:
            with urllib.request.urlopen(req, timeout=45) as response:
                status_code = response.getcode()
                raw_data = response.read().decode("utf-8", errors="replace")
                parsed_json = json.loads(raw_data)
                self._log_raw_response(timestamp, query_id, status_code, parsed_json, user, pw)
                return parsed_json
        except urllib.error.HTTPError as e:
            err_body = ""
            try:
                err_body = e.read().decode("utf-8", errors="replace")
            except Exception:
                pass
            sanitized_err = sanitize_credentials(err_body, user, pw)
            self._log_raw_response(timestamp, query_id, e.code, {"error": sanitized_err}, user, pw)

            if e.code == 401:
                raise PermissionError("Oxylabs Authentication Failed: Invalid OXYLABS_USERNAME or OXYLABS_PASSWORD (HTTP 401)")
            elif e.code == 429:
                raise RuntimeError("Oxylabs Rate Limited: Request quota exceeded or rate limit hit (HTTP 429)")
            else:
                raise RuntimeError(f"Oxylabs HTTP Error {e.code}: {sanitized_err}")
        except urllib.error.URLError as e:
            sanitized_reason = sanitize_credentials(str(e.reason), user, pw)
            raise ConnectionError(f"Oxylabs Network/Connection Error: {sanitized_reason}")

    def _log_raw_response(
        self,
        timestamp: str,
        query_id: str,
        status_code: int,
        data: Any,
        username: str,
        password: str,
    ) -> None:
        """Persist sanitized raw API response to logs/raw_responses/."""
        try:
            filename = f"oxylabs_{timestamp}_{query_id}.json"
            filepath = os.path.join(RAW_RESPONSE_DIR, filename)
            sanitized_str = sanitize_credentials(json.dumps(data, indent=2), username, password)
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(sanitized_str)
        except Exception as e:
            logger.warning(f"Could not write raw response log: {e}")

    def parse_product_from_html(
        self,
        html_content: str,
        url: str,
        zipcode: str = "10001",
        category: str = "Grocery",
        sub_category: str = "General",
        store_name: str = "",
        store_location: str = "",
    ) -> Optional[ProductRecord]:
        """Extract a 22-field ProductRecord from Walmart HTML response content."""
        if not html_content or not isinstance(html_content, str):
            return None

        # 1. Look for application/ld+json
        ld_match = re.findall(r'<script[^>]*type=[\'"]application/ld\+json[\'"][^>]*>(.*?)</script>', html_content, re.DOTALL | re.IGNORECASE)
        ld_data = {}
        for block in ld_match:
            try:
                candidate = json.loads(block.strip())
                if isinstance(candidate, list):
                    for item in candidate:
                        if isinstance(item, dict) and item.get("@type") in ("Product", "IndividualProduct"):
                            ld_data = item
                            break
                elif isinstance(candidate, dict):
                    if candidate.get("@type") in ("Product", "IndividualProduct"):
                        ld_data = candidate
                        break
                    elif "@graph" in candidate and isinstance(candidate["@graph"], list):
                        for item in candidate["@graph"]:
                            if isinstance(item, dict) and item.get("@type") in ("Product", "IndividualProduct"):
                                ld_data = item
                                break
            except (json.JSONDecodeError, TypeError):
                continue

        # 2. Extract title
        title = ""
        if ld_data.get("name"):
            title = str(ld_data["name"]).strip()
        else:
            h1_match = re.search(r'<h1[^>]*>(.*?)</h1>', html_content, re.DOTALL | re.IGNORECASE)
            if h1_match:
                title = re.sub(r'<[^>]+>', '', h1_match.group(1)).strip()

        if not title:
            return None

        # 3. Extract UPC using strict extractor
        upc, _ = extract_upc_from_data(ld_data) if ld_data else ("", "")

        # 4. Extract Brand
        brand = ""
        brand_val = ld_data.get("brand")
        if isinstance(brand_val, dict):
            brand = brand_val.get("name", "")
        elif isinstance(brand_val, str):
            brand = brand_val

        # 5. Extract Prices
        reg_price = ""
        sale_price = ""
        offers = ld_data.get("offers", {})
        if isinstance(offers, list) and offers:
            offers = offers[0]
        if isinstance(offers, dict):
            raw_p = str(offers.get("price", "")).strip()
            if raw_p:
                reg_price = f"${float(raw_p):.2f}" if raw_p.replace(".", "", 1).isdigit() else raw_p

        # Check for rollback / sale text in HTML
        deal_desc = ""
        deal_price = ""
        vol_desc = ""
        vol_price = ""
        dig_desc = ""
        dig_price = ""

        sale_match = re.search(r'(Rollback|Reduced price|Clearance)\s*(?:Now\s*)?\$?([0-9]+\.?[0-9]*)', html_content, re.IGNORECASE)
        if sale_match:
            kind_txt = sale_match.group(1).title()
            p_val = sale_match.group(2)
            if p_val:
                sale_price = f"${float(p_val):.2f}"
            deal = classify_deal(f"{kind_txt} {sale_price}".strip())
        else:
            deal = None

        coupon_match = re.search(r'(Save\s+\$[0-9]+(?:\.[0-9]+)?|Clip\s+coupon)', html_content, re.IGNORECASE)
        if coupon_match:
            c_deal = classify_deal(coupon_match.group(0))
            if c_deal and c_deal.kind == DealKind.DIGITAL:
                dig_desc = c_deal.description
                dig_price = c_deal.price

        # 6. Extract Weight / Unit Measure
        weight = extract_pack_and_weight(title)

        # PPM extraction
        ppm_match = re.search(r'\(\$([0-9]+\.?[0-9]*)\s*/\s*([a-zA-Z\s]+)\)', html_content)
        if ppm_match:
            ppm = f"${ppm_match.group(1)}/{ppm_match.group(2).strip()}"

        # 7. Extract Image URL
        image_url = ""
        img_val = ld_data.get("image")
        if isinstance(img_val, list) and img_val:
            image_url = img_val[0]
        elif isinstance(img_val, str):
            image_url = img_val

        crawl_date = datetime.date.today().isoformat()

        return ProductRecord(
            zipcode=str(zipcode).strip(),
            store_name=store_name,
            store_location=store_location,
            store_logo="",
            store_brand=brand,
            category=category,
            sub_category=sub_category,
            product_title=title,
            weight=weight,
            regular_price=reg_price,
            sale_price=sale_price,
            volume_deals_description=vol_desc,
            volume_deals_price=vol_price,
            digital_deals_description=dig_desc,
            digital_deals_price=dig_price,
            image_url=image_url,
            url=url,
            upc=upc,
            gupc="",
            ppm=ppm,
            unit_price="",
            crawl_date=crawl_date,
        )

    def parse_category_product_urls(self, html_content: str) -> list[str]:
        """Extract individual product URLs from a category page HTML."""
        if not html_content or not isinstance(html_content, str):
            return []

        # Find /ip/ links
        matches = re.findall(r'href=[\'"](/ip/[^"\']+)[\'"]', html_content)
        seen = set()
        urls = []
        for raw_path in matches:
            path = raw_path.split('?')[0]
            full_url = f"https://www.walmart.com{path}"
            if full_url not in seen:
                seen.add(full_url)
                urls.append(full_url)
        return urls

    async def collect(
        self,
        config: dict,
        callback: Optional[Callable[[str, int, int], None]] = None,
        cancel_token: Optional[dict] = None,
    ) -> list[ProductRecord]:
        """Collect product data using Oxylabs Realtime API."""
        if not self.is_configured():
            raise ValueError(
                "Oxylabs credentials not configured. Provide OXYLABS_USERNAME and OXYLABS_PASSWORD."
            )

        category_url = config.get("category_url", "https://www.walmart.com/browse/food/snacks-cookies-chips/976759_976779")
        target_count = int(config.get("target_count", 50))
        zipcode = str(config.get("zipcode", "10001")).strip()
        store_id = config.get("store_id")

        if callback:
            callback(f"Querying Oxylabs for category page...", 0, target_count)

        cat_payload = self.build_payload(category_url, zipcode=zipcode, store_id=store_id)
        cat_resp = self.execute_query_sync(cat_payload)

        results = cat_resp.get("results", [])
        if not results:
            logger.warning("Oxylabs returned 0 results for category query.")
            return []

        cat_html = results[0].get("content", "")
        product_urls = self.parse_category_product_urls(cat_html)

        records: list[ProductRecord] = []
        for i, p_url in enumerate(product_urls):
            if cancel_token and cancel_token.get("cancelled"):
                break
            if len(records) >= target_count:
                break

            if callback:
                callback(f"Oxylabs fetching product {i + 1}/{min(len(product_urls), target_count)}...", len(records), target_count)

            p_payload = self.build_payload(p_url, zipcode=zipcode, store_id=store_id)
            p_resp = self.execute_query_sync(p_payload)
            p_results = p_resp.get("results", [])
            if p_results:
                content = p_results[0].get("content", "")
                rec = self.parse_product_from_html(
                    content,
                    url=p_url,
                    zipcode=zipcode,
                    category=config.get("category", "Grocery"),
                    sub_category=config.get("sub_category", "Products"),
                )
                if rec:
                    records.append(rec)

        return records
