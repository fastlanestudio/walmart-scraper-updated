import sqlite3
import json
import csv
import io
import datetime
from pathlib import Path
from dataclasses import dataclass
from typing import Optional

FIELD_NAMES = [
    "zipcode",
    "store_name",
    "store_location",
    "store_logo",
    "store_brand",
    "category",
    "sub_category",
    "product_title",
    "weight",
    "regular_price",
    "sale_price",
    "volume_deals_description",
    "volume_deals_price",
    "digital_deals_description",
    "digital_deals_price",
    "image_url",
    "url",
    "upc",
    "gupc",
    "ppm",
    "unit_price",
    "crawl_date",
]

DB_SCHEMA = """
CREATE TABLE IF NOT EXISTS runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT UNIQUE NOT NULL,
    mode TEXT NOT NULL,          -- 'live' or 'simulated'
    store_zipcode TEXT,
    store_name TEXT,
    started_at TEXT,
    finished_at TEXT,
    status TEXT DEFAULT 'running',  -- 'running', 'done', 'failed'
    error_message TEXT
);

CREATE TABLE IF NOT EXISTS products (
    product_key TEXT PRIMARY KEY,
    run_id TEXT NOT NULL,
    data_json TEXT NOT NULL,      -- full 22-field JSON
    seen_in_last_run INTEGER DEFAULT 1,  -- 1=verified this run, 0=carried-forward
    last_seen_run_id TEXT,
    updated_at TEXT,
    is_test INTEGER DEFAULT 0,
    data_source TEXT DEFAULT 'live'
);

CREATE TABLE IF NOT EXISTS staged_products (
    product_key TEXT NOT NULL,
    run_id TEXT NOT NULL,
    data_json TEXT NOT NULL,
    is_test INTEGER DEFAULT 0,
    data_source TEXT DEFAULT 'live',
    updated_at TEXT,
    PRIMARY KEY (product_key, run_id)
);
"""


class StoreDB:
    """SQLite-backed availability-retention store.

    Products are NEVER deleted — unseen products are marked with seen_in_last_run=0
    and carried forward in export_json() and export_csv() with their last-known data.
    """

    def __init__(self, db_path: str | Path):
        self._db_path = Path(db_path)
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self._db_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(DB_SCHEMA)
        self._migrate()
        self._conn.commit()

    def _migrate(self) -> None:
        """Add any missing columns for backward-compatible schema evolutions."""
        for col, col_def in [
            ("is_test", "INTEGER DEFAULT 0"),
            ("data_source", "TEXT DEFAULT 'live'"),
        ]:
            try:
                self._conn.execute(f"ALTER TABLE products ADD COLUMN {col} {col_def}")
            except sqlite3.OperationalError:
                pass  # already exists

    # ── Run lifecycle ──────────────────────────────────────────────────────────

    def begin_run(
        self,
        run_id: str,
        mode: str = "live",
        store_zipcode: str = "",
        store_name: str = "",
    ) -> None:
        """Register a new run (or re-open an existing one if run_id already exists)."""
        now = datetime.datetime.now(datetime.timezone.utc).isoformat()
        self._conn.execute(
            """
            INSERT INTO runs (run_id, mode, store_zipcode, store_name, started_at, status)
            VALUES (?, ?, ?, ?, ?, 'running')
            ON CONFLICT(run_id) DO UPDATE SET status='running', started_at=excluded.started_at
            """,
            (run_id, mode, store_zipcode, store_name, now),
        )
        self._conn.commit()

    def finish_run(self, run_id: str, status: str = "done", error_message: str = "") -> None:
        """Mark a run as finished with the given status ('done' or 'failed')."""
        now = datetime.datetime.now(datetime.timezone.utc).isoformat()
        try:
            self._conn.execute(
                "UPDATE runs SET status=?, finished_at=?, error_message=? WHERE run_id=?",
                (status, now, error_message, run_id),
            )
        except sqlite3.OperationalError:
            self._conn.execute(
                "UPDATE runs SET status=?, finished_at=? WHERE run_id=?",
                (status, now, run_id),
            )
        self._conn.commit()

    # ── Staging & Atomic Publish ────────────────────────────────────────────────

    def stage_product(
        self,
        product_key: str,
        run_id: str,
        record_dict: dict,
        is_test: int = 0,
        data_source: str = "live",
    ) -> None:
        """Stage a product record for a run without modifying accepted products."""
        now = datetime.datetime.now(datetime.timezone.utc).isoformat()
        data_json = json.dumps(record_dict, ensure_ascii=False)
        self._conn.execute(
            """
            INSERT INTO staged_products (product_key, run_id, data_json, is_test, data_source, updated_at)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(product_key, run_id) DO UPDATE SET
                data_json=excluded.data_json,
                is_test=excluded.is_test,
                data_source=excluded.data_source,
                updated_at=excluded.updated_at
            """,
            (product_key, run_id, data_json, is_test, data_source, now),
        )
        self._conn.commit()

    def publish_run(self, run_id: str) -> int:
        """
        Atomically publish staged products for run_id into accepted products.
        Marks accepted products not seen in this run as carried-forward (seen_in_last_run=0).
        Cleans up staged products for run_id.
        """
        staged_rows = self._conn.execute(
            "SELECT product_key, data_json, is_test, data_source, updated_at FROM staged_products WHERE run_id = ?",
            (run_id,),
        ).fetchall()

        if not staged_rows:
            return 0

        # 1. Mark existing products as not seen in last run
        self._conn.execute("UPDATE products SET seen_in_last_run=0")

        # 2. Upsert each staged item as seen_in_last_run=1
        for row in staged_rows:
            self._conn.execute(
                """
                INSERT INTO products (product_key, run_id, data_json, seen_in_last_run, last_seen_run_id, updated_at, is_test, data_source)
                VALUES (?, ?, ?, 1, ?, ?, ?, ?)
                ON CONFLICT(product_key) DO UPDATE SET
                    run_id=excluded.run_id,
                    data_json=excluded.data_json,
                    seen_in_last_run=1,
                    last_seen_run_id=excluded.last_seen_run_id,
                    updated_at=excluded.updated_at,
                    is_test=excluded.is_test,
                    data_source=excluded.data_source
                """,
                (row["product_key"], run_id, row["data_json"], run_id, row["updated_at"], row["is_test"], row["data_source"]),
            )

        # 3. Clean staged table for this run
        self._conn.execute("DELETE FROM staged_products WHERE run_id = ?", (run_id,))
        self._conn.commit()
        return len(staged_rows)

    def discard_staged_run(self, run_id: str) -> None:
        """Discard any staged products for a failed or cancelled run."""
        self._conn.execute("DELETE FROM staged_products WHERE run_id = ?", (run_id,))
        self._conn.commit()

    def get_product(self, product_key: str) -> Optional[dict]:
        """Fetch a single accepted product record by its product_key."""
        row = self._conn.execute(
            "SELECT data_json, seen_in_last_run, last_seen_run_id, updated_at FROM products WHERE product_key = ?",
            (product_key,),
        ).fetchone()
        if not row:
            return None
        try:
            data = json.loads(row["data_json"])
            data["seen_in_last_run"] = row["seen_in_last_run"]
            data["last_seen_run_id"] = row["last_seen_run_id"]
            data["updated_at"] = row["updated_at"]
            return data
        except (json.JSONDecodeError, TypeError):
            return None

    # ── Product operations ─────────────────────────────────────────────────────

    def upsert_product(
        self,
        product_key: str,
        run_id: str,
        record_dict: dict,
        is_test: int = 0,
        data_source: str = "live",
    ) -> None:
        """Insert or update a product record. Sets seen_in_last_run=1."""
        now = datetime.datetime.now(datetime.timezone.utc).isoformat()
        data_json = json.dumps(record_dict, ensure_ascii=False)
        self._conn.execute(
            """
            INSERT INTO products (product_key, run_id, data_json, seen_in_last_run, last_seen_run_id, updated_at, is_test, data_source)
            VALUES (?, ?, ?, 1, ?, ?, ?, ?)
            ON CONFLICT(product_key) DO UPDATE SET
                run_id=excluded.run_id,
                data_json=excluded.data_json,
                seen_in_last_run=1,
                last_seen_run_id=excluded.last_seen_run_id,
                updated_at=excluded.updated_at,
                is_test=excluded.is_test,
                data_source=excluded.data_source
            """,
            (product_key, run_id, data_json, run_id, now, is_test, data_source),
        )
        self._conn.commit()

    def mark_unseen(self, run_id: str) -> None:
        """After a run completes, mark all products NOT seen in this run as seen_in_last_run=0.
        Called AFTER all upserts are done. Products are NEVER deleted."""
        self._conn.execute(
            "UPDATE products SET seen_in_last_run=0 WHERE last_seen_run_id != ?",
            (run_id,),
        )
        self._conn.commit()

    # ── Export ─────────────────────────────────────────────────────────────────

    def export_json(self, run_id: Optional[str] = None, is_test: Optional[int] = None) -> list[dict]:
        """Return all products (seen + carried-forward) as a list of 22-field dicts.
        Carried-forward products keep their last-known data. No bookkeeping fields leak."""
        query = "SELECT data_json FROM products WHERE 1=1"
        params = []
        if is_test is not None:
            query += " AND is_test = ?"
            params.append(is_test)

        rows = self._conn.execute(query, params).fetchall()
        result = []
        for row in rows:
            try:
                record = json.loads(row["data_json"])
                # Ensure only the 22 required fields are returned in order
                clean = {f: record.get(f, "") for f in FIELD_NAMES}
                result.append(clean)
            except (json.JSONDecodeError, KeyError):
                pass
        return result

    def export_csv(
        self,
        run_id: Optional[str] = None,
        delimiter: str = ";",
        is_test: Optional[int] = None,
    ) -> str:
        """Export all products as a strictly-formatted CSV string using exact 22 fields.
        
        Header:
            zipcode;store_name;store_location;store_logo;store_brand;category;sub_category;product_title;weight;regular_price;sale_price;volume_deals_description;volume_deals_price;digital_deals_description;digital_deals_price;image_url;url;upc;gupc;ppm;unit_price;crawl_date
            
        Semicolon-delimited by default (configurable). Properly escapes quotes, newlines, and delimiter characters.
        """
        products = self.export_json(run_id=run_id, is_test=is_test)
        output = io.StringIO()
        writer = csv.writer(
            output,
            delimiter=delimiter,
            lineterminator="\r\n",
            quoting=csv.QUOTE_MINIMAL,
        )
        writer.writerow(FIELD_NAMES)
        for p in products:
            row = [str(p.get(field, "") or "") for field in FIELD_NAMES]
            writer.writerow(row)
        return output.getvalue()

    def export_audit_log(self, run_id: Optional[str] = None) -> list[dict]:
        """Return audit records: product_key, seen_in_last_run, last_seen_run_id, updated_at."""
        query = "SELECT product_key, seen_in_last_run, last_seen_run_id, updated_at, is_test, data_source FROM products"
        params = []
        if run_id:
            query += " WHERE run_id = ? OR last_seen_run_id = ?"
            params.extend([run_id, run_id])
        rows = self._conn.execute(query, params).fetchall()
        return [
            {
                "product_key": row["product_key"],
                "seen_in_last_run": row["seen_in_last_run"],
                "last_seen_run_id": row["last_seen_run_id"],
                "updated_at": row["updated_at"],
                "is_test": row["is_test"] if "is_test" in row.keys() else 0,
                "data_source": row["data_source"] if "data_source" in row.keys() else "live",
            }
            for row in rows
        ]

    # ── Key derivation & Deduplication ─────────────────────────────────────────

    def _product_key(self, record_dict: dict) -> str:
        """Derive a stable product identity key from URL (primary) or UPC as fallback.
        Preserves store context (zipcode) when present so different stores' prices are not erased."""
        zipcode = (record_dict.get("zipcode") or "").strip()
        url = (record_dict.get("url") or "").strip()
        base_key = ""
        if url:
            from urllib.parse import urlparse, urlunparse
            parsed = urlparse(url)
            base_key = urlunparse((parsed.scheme, parsed.netloc, parsed.path, "", "", "")) or url
        elif (record_dict.get("upc") or "").strip():
            base_key = f"upc:{record_dict['upc'].strip()}"
        else:
            base_key = url

        if zipcode and base_key:
            return f"{zipcode}:{base_key}"
        return base_key

    # ── Localhost UI Query Helpers ─────────────────────────────────────────────

    def get_records(
        self,
        search: str = "",
        is_test: Optional[int] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict:
        """Query products for the UI table with search, pagination, and provenance flags."""
        query = "SELECT product_key, run_id, data_json, seen_in_last_run, last_seen_run_id, updated_at, is_test, data_source FROM products WHERE 1=1"
        params = []
        if is_test is not None:
            query += " AND is_test = ?"
            params.append(is_test)

        rows = self._conn.execute(query, params).fetchall()
        all_records = []
        search_lower = search.strip().lower()

        for row in rows:
            try:
                rec = json.loads(row["data_json"])
                # Add metadata for UI display
                rec["_key"] = row["product_key"]
                rec["_seen"] = bool(row["seen_in_last_run"])
                rec["_is_test"] = bool(row["is_test"])
                rec["_data_source"] = row["data_source"]
                rec["_updated_at"] = row["updated_at"]

                # Filter by search string across title, upc, category, zipcode
                if search_lower:
                    searchable = (
                        f"{rec.get('product_title', '')} {rec.get('upc', '')} "
                        f"{rec.get('category', '')} {rec.get('sub_category', '')} "
                        f"{rec.get('zipcode', '')}"
                    ).lower()
                    if search_lower not in searchable:
                        continue

                all_records.append(rec)
            except (json.JSONDecodeError, KeyError):
                continue

        total = len(all_records)
        paged = all_records[offset : offset + limit]
        return {
            "records": paged,
            "total": total,
            "limit": limit,
            "offset": offset,
        }

    def get_stats(self) -> dict:
        """Return collection metrics for UI dashboard cards."""
        total = self._conn.execute("SELECT COUNT(*) AS c FROM products").fetchone()["c"]
        live = self._conn.execute("SELECT COUNT(*) AS c FROM products WHERE is_test = 0").fetchone()["c"]
        test = self._conn.execute("SELECT COUNT(*) AS c FROM products WHERE is_test = 1").fetchone()["c"]
        carried_forward = self._conn.execute("SELECT COUNT(*) AS c FROM products WHERE seen_in_last_run = 0").fetchone()["c"]
        runs_count = self._conn.execute("SELECT COUNT(*) AS c FROM runs").fetchone()["c"]
        return {
            "total_records": total,
            "live_records": live,
            "test_records": test,
            "carried_forward": carried_forward,
            "total_runs": runs_count,
        }

    def clear_all(self) -> None:
        """Safely reset all products and runs in local database."""
        self._conn.execute("DELETE FROM products")
        self._conn.execute("DELETE FROM runs")
        self._conn.commit()
