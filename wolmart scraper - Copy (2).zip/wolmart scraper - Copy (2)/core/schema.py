import re
from dataclasses import dataclass, fields
from collections import OrderedDict
from typing import Optional

# Regex matching "approx" or "approximately", "about", "avg wt", "variable weight", "per lb"
APPROX_WEIGHT_PATTERN = re.compile(
    r'\b(approx|approximately|about|avg\s*wt|average\s*weight|variable\s*weight|per\s*lb)\b',
    re.IGNORECASE,
)

# Standard units of measurement recognized in packaging
UNIT_PATTERN = re.compile(
    r'\b(fl\s*oz|fluid\s*ounces?|oz|ounces?|lbs?|pounds?|ct|count|pk|pack|cans?|bottles?|gallons?|gal|qt|quarts?|liters?|litres?|l|ml|grams?|g|kg)\b',
    re.IGNORECASE
)


def is_approx_weight(weight: str) -> bool:
    """Return True if the weight string contains approximate wording."""
    if not weight:
        return False
    return bool(APPROX_WEIGHT_PATTERN.search(weight))


def extract_upc_from_data(data: dict) -> tuple[str, str]:
    """
    Extract genuine barcode (GTIN-12 / UPC, GTIN-13, GTIN-14) from product payload.
    Preserves leading zeros and returns (barcode_string, source_key).
    Rejects SKU, MPN, or item ID fallbacks (returns ("", "") if no genuine barcode).
    """
    if not isinstance(data, dict):
        return "", ""

    # Priority order of genuine barcode keys
    barcode_keys = ["gtin12", "upc", "gtin13", "gtin14", "barcode", "gtin"]
    for key in barcode_keys:
        val = data.get(key)
        if val is not None:
            val_str = str(val).strip()
            # Clean non-digits
            digits_only = re.sub(r'\D', '', val_str)
            if digits_only and len(digits_only) in (8, 12, 13, 14):
                # Preserve leading zeros
                # If 11 or 12 digits, format to 12 digits
                if len(digits_only) == 12:
                    return digits_only, key
                elif len(digits_only) in (13, 14):
                    return digits_only, key
                elif len(digits_only) == 11:
                    return digits_only.zfill(12), key
                elif len(digits_only) == 8:
                    return digits_only, key
                return digits_only, key

    return "", ""


def extract_pack_and_weight(title: str) -> str:
    """
    Extract multipack count and individual package size/weight from title.
    Preserves exact count and unit (e.g. '12 pack, 12 fl oz', '24 pk / 16.9 fl oz', '6 pack, 11.15 fl oz').
    Rejects approximate weights.
    """
    if not title or is_approx_weight(title):
        return ""

    # Pattern: "X pack, Y unit" or "X pk / Y unit" or "X x Y unit"
    # e.g. "12 pack, 12 fl oz", "24 pk / 16.9 fl oz", "6 x 11.15 fl oz"
    multi_pattern = re.compile(
        r'(\d+)\s*(?:pack|pk|x|\*)\s*[,/]?\s*(\d+(?:\.\d+)?)\s*(fl\s*oz|oz|count|ct|cans?|bottles?|lbs?|gal|g|ml|liters?)',
        re.IGNORECASE
    )
    m = multi_pattern.search(title)
    if m:
        count, amount, unit = m.groups()
        unit_clean = unit.lower().strip()
        # Normalise format matching test expectation: 'X pack, Y unit' or 'X pk / Y unit'
        if "pk" in title[m.start():m.end()]:
            return f"{count} pk / {amount} {unit_clean}"
        return f"{count} pack, {amount} {unit_clean}"

    # Standalone weights: e.g. "20 oz", "18 count", "92 fl oz", "13 oz"
    weight_pattern = re.compile(
        r'(\d+(?:\.\d+)?)\s*(fl\s*oz|fluid\s*ounces?|oz|ounces?|lbs?|pounds?|ct|count|pack|pk)\b',
        re.IGNORECASE
    )
    # Search backwards or all matches
    matches = list(weight_pattern.finditer(title))
    if matches:
        last_match = matches[-1]
        amount, unit = last_match.groups()
        return f"{amount} {unit.lower()}"

    return ""


FIELD_NAMES = [
    "zipcode",
    "store_name",
    "store_location",
    "store_logo",
    "store_brand",
    "category",
    "sub_category",
    "product_title",
    "weight",
    "regular_price",
    "sale_price",
    "volume_deals_description",
    "volume_deals_price",
    "digital_deals_description",
    "digital_deals_price",
    "image_url",
    "url",
    "upc",
    "gupc",
    "ppm",
    "unit_price",
    "crawl_date",
]


@dataclass
class ProductRecord:
    # Field order IS the output order (22 fields)
    zipcode: str = ""
    store_name: str = ""
    store_location: str = ""
    store_logo: str = ""
    store_brand: str = ""
    category: str = ""
    sub_category: str = ""
    product_title: str = ""
    weight: str = ""
    regular_price: str = ""
    sale_price: str = ""
    volume_deals_description: str = ""
    volume_deals_price: str = ""
    digital_deals_description: str = ""
    digital_deals_price: str = ""
    image_url: str = ""
    url: str = ""
    upc: str = ""
    gupc: str = ""
    ppm: str = ""
    unit_price: str = ""
    crawl_date: str = ""

    def validate(self, strict_downstream_empty: bool = True) -> list[str]:
        """Return a list of validation error strings. Empty list means valid.
        
        Args:
            strict_downstream_empty: If True (default), enforces that gupc and unit_price
                                     are empty strings (for downstream pipeline completion).
                                     If False, allows source-provided unit_price / gupc strings.
        """
        errors = []

        # gupc and unit_price downstream rules
        if strict_downstream_empty:
            if self.gupc != "":
                errors.append(f"gupc must be empty string, got: {self.gupc!r}")
            if self.unit_price != "":
                errors.append(f"unit_price must be empty string, got: {self.unit_price!r}")

        # No field may be None
        for f in fields(self):
            val = getattr(self, f.name)
            if val is None:
                errors.append(f"Field '{f.name}' must not be None")

        # Required non-empty fields
        if not self.product_title:
            errors.append("product_title must not be empty")
        if not self.url:
            errors.append("url must not be empty")
        if not self.crawl_date:
            errors.append("crawl_date must not be empty")

        return errors

    def to_dict(self) -> OrderedDict:
        """Return an OrderedDict preserving field order, 22 fields only."""
        return OrderedDict(
            (f.name, getattr(self, f.name))
            for f in fields(self)
        )


def validate_batch(
    records: list[ProductRecord],
) -> tuple[list[ProductRecord], list[tuple[ProductRecord, list[str]]]]:
    """
    Validate a list of ProductRecords.
    Returns (valid_records, [(invalid_record, errors), ...]).
    """
    valid = []
    invalid = []
    for record in records:
        errors = record.validate()
        if errors:
            invalid.append((record, errors))
        else:
            valid.append(record)
    return valid, invalid
