"""core/walmart_direct.py
Direct Walmart live catalog extractor using browser-emulated HTTP sessions.

Extracts 100% genuine Walmart products with real UPCs, live prices,
and full 22-field schema compliance directly from Walmart.com.
Zero test fixtures, zero dummy data.
"""
import ssl
import urllib.request
import urllib.error
import json
import re
import time
import random
import datetime
import logging
from typing import Optional, Callable, List

from core.schema import ProductRecord, extract_pack_and_weight, is_approx_weight
from core.deal_classifier import classify_deal, DealKind
from core.location import build_walmart_cookie_header, resolve_walmart_store

logger = logging.getLogger(__name__)

DEFAULT_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Sec-Ch-Ua": '"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"',
    "Sec-Ch-Ua-Mobile": "?0",
    "Sec-Ch-Ua-Platform": '"Windows"',
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
    "Upgrade-Insecure-Requests": "1",
}


def fetch_walmart_html(
    url: str,
    store_info: Optional[dict] = None,
    timeout: int = 25,
    max_retries: int = 3,
) -> str:
    """Fetch raw HTML from Walmart with verified SSL certificates, Chrome desktop headers, and store cookies.
    
    Implements exponential backoff on HTTP 429 (Rate Limit) or transient 5xx errors.
    Uses system / certifi validated CA bundle; never falls back to unverified SSL.
    """
    import certifi
    try:
        ctx = ssl.create_default_context(cafile=certifi.where())
    except Exception as e:
        logger.error(f"Cannot initialize validated SSL context: {e}")
        raise RuntimeError(f"SSL certificate configuration failure: {e}") from e

    headers = dict(DEFAULT_HEADERS)

    if store_info:
        headers["Cookie"] = build_walmart_cookie_header(store_info)

    for attempt in range(max_retries):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, context=ctx, timeout=timeout) as resp:
                return resp.read().decode("utf-8", errors="replace")
        except urllib.error.HTTPError as he:
            if he.code == 429 and attempt < max_retries - 1:
                backoff = (2.0 ** attempt) + random.uniform(0.5, 1.5)
                logger.warning(f"HTTP 429 Rate limited on {url}. Backing off for {backoff:.1f}s (attempt {attempt + 1}/{max_retries})")
                time.sleep(backoff)
                continue
            elif he.code in (500, 502, 503, 504) and attempt < max_retries - 1:
                backoff = (1.5 ** attempt) + random.uniform(0.2, 0.8)
                logger.warning(f"HTTP {he.code} on {url}. Retrying in {backoff:.1f}s")
                time.sleep(backoff)
                continue
            logger.warning(f"HTTP error {he.code} fetching {url}: {he}")
            raise
        except Exception as e:
            if attempt < max_retries - 1:
                backoff = 1.0 + attempt
                logger.warning(f"Network error on {url}: {e}. Retrying in {backoff}s")
                time.sleep(backoff)
                continue
            logger.warning(f"Failed to fetch {url}: {e}")
            raise

    return ""


def extract_product_record_from_html(
    html: str,
    product_url: str,
    store_info: Optional[dict] = None,
    zipcode: str = "10001",
    category: str = "Grocery",
    sub_category: str = "Products",
) -> Optional[ProductRecord]:
    """Parse real Walmart product page HTML into a validated 22-field ProductRecord.
    
    Targets Walmart's Next.js hydration payload (`__NEXT_DATA__`) with resilient
    DOM and JSON-LD fallback parsers.
    """
    if not html:
        return None

    # Resolve store attributes
    if store_info and store_info.get("is_store_verified"):
        store_name = store_info.get("store_name", "")
        store_location = store_info.get("store_location", "")
        store_logo = store_info.get("store_logo", "")
        zip_str = str(store_info.get("zipcode", zipcode)).strip()
    else:
        # Client regression requirement: do NOT fabricate fallback store names for unverified stores
        store_name = ""
        store_location = ""
        store_logo = ""
        zip_str = str(zipcode or "10001").strip()

    # ── Attempt 1: Next.js Hydration Payload ────────────────────────────────
    next_match = re.search(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>', html, re.DOTALL)
    if next_match:
        try:
            data = json.loads(next_match.group(1))
            props = data.get("props", {}).get("pageProps", {})
            initial_data = props.get("initialData", {})
            product = initial_data.get("data", {}).get("product", {})
            if product:
                return _parse_next_data_product(
                    product=product,
                    product_url=product_url,
                    zipcode=zip_str,
                    store_name=store_name,
                    store_location=store_location,
                    store_logo=store_logo,
                    category=category,
                    sub_category=sub_category,
                )
        except Exception as e:
            logger.debug(f"Next.js JSON parsing failed for {product_url}: {e}")

    # ── Attempt 2: Structured Data (JSON-LD) & DOM Fallback ──────────────────
    return _parse_dom_fallback(
        html=html,
        product_url=product_url,
        zipcode=zip_str,
        store_name=store_name,
        store_location=store_location,
        store_logo=store_logo,
        category=category,
        sub_category=sub_category,
    )


def _parse_next_data_product(
    product: dict,
    product_url: str,
    zipcode: str,
    store_name: str,
    store_location: str,
    store_logo: str,
    category: str,
    sub_category: str,
) -> Optional[ProductRecord]:
    """Parse product dictionary from __NEXT_DATA__ payload."""
    title = product.get("name", "").strip()
    if not title:
        return None

    # Exclude approximate weights
    weight = extract_pack_and_weight(title)
    if is_approx_weight(weight) or is_approx_weight(title):
        logger.info(f"Excluding approx-weight item: {title}")
        return None

    brand = product.get("brand", "").strip()
    upc = product.get("upc", "").strip()
    if upc and not upc.isdigit():
        upc = ""

    # Price extraction
    price_info = product.get("priceInfo", {}) or {}
    cur_price_dict = price_info.get("currentPrice") or {}
    cur_price = cur_price_dict.get("priceString") or (
        f"${cur_price_dict.get('price'):.2f}" if cur_price_dict.get("price") is not None else ""
    )

    was_price_dict = price_info.get("wasPrice") or {}
    was_price = was_price_dict.get("priceString") or (
        f"${was_price_dict.get('price'):.2f}" if was_price_dict.get("price") is not None else ""
    )

    if was_price and was_price != cur_price:
        regular_price = was_price
        sale_price = cur_price
    else:
        regular_price = cur_price
        sale_price = ""

    # Unit price / PPM
    unit_price_info = price_info.get("unitPrice") or {}
    ppm = unit_price_info.get("priceString", "") if unit_price_info else ""

    # Images
    images = product.get("imageInfo") or {}
    img_url = images.get("thumbnailUrl", "")
    if not img_url and images.get("allImages"):
        img_url = images["allImages"][0].get("url", "")

    # Canonical Category Hierarchy
    cat_info = product.get("category") or {}
    cat_path = cat_info.get("path") or []
    if len(cat_path) >= 2:
        category = cat_path[0].get("name", category)
        sub_category = cat_path[1].get("name", sub_category)
    elif len(cat_path) == 1:
        category = cat_path[0].get("name", category)

    # Promotional deals & badges
    vol_desc = ""
    vol_price = ""
    dig_desc = ""
    dig_price = ""

    badges = product.get("badges") or {}
    flags = badges.get("flags") or []
    for f in flags:
        f_text = f.get("text", "")
        deal = classify_deal(f_text)
        if deal:
            if deal.kind == DealKind.VOLUME and not vol_desc:
                vol_desc = deal.description
                vol_price = deal.price
            elif deal.kind == DealKind.DIGITAL and not dig_desc:
                dig_desc = deal.description
                dig_price = deal.price
            elif deal.kind == DealKind.SALE and deal.price and not sale_price:
                sale_price = deal.price

    rec = ProductRecord(
        zipcode=zipcode,
        store_name=store_name,
        store_location=store_location,
        store_logo=store_logo,
        store_brand=brand,
        category=category,
        sub_category=sub_category,
        product_title=title,
        weight=weight,
        regular_price=regular_price,
        sale_price=sale_price,
        volume_deals_description=vol_desc,
        volume_deals_price=vol_price,
        digital_deals_description=dig_desc,
        digital_deals_price=dig_price,
        image_url=img_url,
        url=product_url,
        upc=upc,
        gupc="",
        ppm=ppm,
        unit_price="",
        crawl_date=datetime.date.today().isoformat(),
    )

    errors = rec.validate()
    if errors:
        logger.warning(f"ProductRecord validation failed on {product_url}: {errors}")
        return None

    return rec


def _parse_dom_fallback(
    html: str,
    product_url: str,
    zipcode: str,
    store_name: str,
    store_location: str,
    store_logo: str,
    category: str,
    sub_category: str,
) -> Optional[ProductRecord]:
    """Parse product record from HTML DOM and JSON-LD when Next.js payload is missing."""
    # JSON-LD structured data
    ld_matches = re.findall(r'<script type="application/ld\+json"[^>]*>(.*?)</script>', html, re.DOTALL)
    ld_data = {}
    for m in ld_matches:
        try:
            d = json.loads(m.strip())
            if isinstance(d, list):
                d = d[0] if d else {}
            if d.get("@type") == "Product" or "name" in d:
                ld_data = d
                break
        except Exception:
            continue

    # Title
    title = ld_data.get("name", "")
    if not title:
        t_match = re.search(r'<h1[^>]*>(.*?)</h1>', html, re.DOTALL)
        if t_match:
            title = re.sub(r'<[^>]+>', '', t_match.group(1)).strip()

    if not title:
        return None

    weight = extract_pack_and_weight(title)
    if is_approx_weight(weight) or is_approx_weight(title):
        return None

    # Brand
    brand = ""
    if isinstance(ld_data.get("brand"), dict):
        brand = ld_data["brand"].get("name", "")
    elif isinstance(ld_data.get("brand"), str):
        brand = ld_data["brand"]

    # UPC
    upc = ""
    for k in ("gtin12", "upc", "gtin13", "gtin14", "gtin8"):
        v = str(ld_data.get(k) or "").strip()
        if v.isdigit() and len(v) in (8, 12, 13, 14):
            upc = v
            break

    # Price
    offers = ld_data.get("offers", {})
    if isinstance(offers, list):
        offers = offers[0] if offers else {}
    reg_price = ""
    if isinstance(offers, dict) and offers.get("price"):
        p_val = str(offers["price"])
        reg_price = f"${p_val}" if not p_val.startswith("$") else p_val

    # Image
    img_url = ""
    if ld_data.get("image"):
        img = ld_data["image"]
        img_url = img[0] if isinstance(img, list) else str(img)

    rec = ProductRecord(
        zipcode=zipcode,
        store_name=store_name,
        store_location=store_location,
        store_logo=store_logo,
        store_brand=brand,
        category=category,
        sub_category=sub_category,
        product_title=title,
        weight=weight,
        regular_price=reg_price,
        sale_price="",
        volume_deals_description="",
        volume_deals_price="",
        digital_deals_description="",
        digital_deals_price="",
        image_url=img_url,
        url=product_url,
        upc=upc,
        gupc="",
        ppm="",
        unit_price="",
        crawl_date=datetime.date.today().isoformat(),
    )

    errors = rec.validate()
    if errors:
        return None

    return rec


def discover_category_product_urls(
    category_url: str,
    target_count: int = 50,
    max_pages: int = 5,
    store_info: Optional[dict] = None,
) -> List[str]:
    """Crawl category or search listing and discover individual product canonical URLs.
    
    Handles pagination across pages (?page=1, 2, 3...) until target_count is reached.
    """
    discovered: List[str] = []
    seen = set()

    for page_num in range(1, max_pages + 1):
        if len(discovered) >= target_count:
            break

        delim = "&" if "?" in category_url else "?"
        p_url = f"{category_url}{delim}page={page_num}" if page_num > 1 else category_url

        try:
            html = fetch_walmart_html(p_url, store_info=store_info)
            next_match = re.search(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>', html, re.DOTALL)
            page_found = 0

            if next_match:
                try:
                    data = json.loads(next_match.group(1))
                    search_result = (
                        data.get("props", {})
                        .get("pageProps", {})
                        .get("initialData", {})
                        .get("searchResult", {})
                    )
                    item_stacks = search_result.get("itemStacks", [])
                    for stack in item_stacks:
                        for item in stack.get("items", []):
                            can_url = item.get("canonicalUrl")
                            if can_url and "/ip/" in can_url:
                                full_url = (
                                    f"https://www.walmart.com{can_url}"
                                    if can_url.startswith("/")
                                    else can_url
                                )
                                base_url = full_url.split("?")[0]
                                if base_url not in seen:
                                    seen.add(base_url)
                                    discovered.append(full_url)
                                    page_found += 1
                                    if len(discovered) >= target_count:
                                        break
                        if len(discovered) >= target_count:
                            break
                except Exception as e:
                    logger.debug(f"JSON itemStacks parsing failed on {p_url}: {e}")

            # HTML fallback link discovery if JSON was absent
            if page_found == 0:
                raw_links = re.findall(r'href="(/ip/[^"?]+|\bhttps://www\.walmart\.com/ip/[^"?]+)', html)
                for l in raw_links:
                    full_url = f"https://www.walmart.com{l}" if l.startswith("/") else l
                    base_url = full_url.split("?")[0]
                    if base_url not in seen:
                        seen.add(base_url)
                        discovered.append(full_url)
                        page_found += 1
                        if len(discovered) >= target_count:
                            break

            if page_found == 0:
                logger.info(f"No new products found on page {page_num}; stopping discovery")
                break

        except Exception as e:
            logger.warning(f"Error discovering URLs on {p_url}: {e}")
            break

    return discovered
