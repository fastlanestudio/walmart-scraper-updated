"""core/source_adapter.py
Data source adapter layer for Walmart product collection.

Provides:
- BaseSourceAdapter: Abstract adapter interface
- LivePlaywrightAdapter: Automated browser extraction (Primary production collector)
- WalmartApiAdapter: Authorized Developer/Partner API adapter
- TestFixtureAdapter: Validated test fixtures strictly isolated to test mode
"""
import asyncio
import logging
import os
import datetime
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional, Callable

from core.schema import ProductRecord, is_approx_weight
from core.deal_classifier import classify_deal, DealKind
from core.base_scraper import ChallengePage

logger = logging.getLogger(__name__)


@dataclass
class AdapterStatus:
    name: str
    status: str  # "ready", "blocked", "not_configured", "error"
    message: str
    capabilities: list[str] = field(default_factory=list)
    supports_live: bool = False


# ─── Isolated Offline Test Fixtures ──────────────────────────────────────────

TEST_TEMPLATES = [
    ("Great Value Restaurant Style White Corn Tortilla Chips", "13 oz", "Great Value", "$2.24", "", "", "$0.17/oz"),
    ("Great Value Whole Milk", "1 gal", "Great Value", "$3.48", "", "", "$0.03/fl oz"),
    ("Lay's Classic Potato Chips", "8 oz", "", "$4.28", "$3.50", "Rollback", "$0.44/oz"),
    ("Doritos Nacho Cheese Flavored Tortilla Chips", "9.25 oz", "", "$4.98", "", "2 for $7.00", "$0.54/oz"),
    ("Coca-Cola Original Taste Soda", "12 pk / 12 fl oz", "", "$8.98", "", "Buy 2 Get 1 Free", "$0.06/fl oz"),
    ("Equate Ibuprofen Pain Reliever Tablets", "500 ct", "Equate", "$9.98", "", "", "$0.02/ct"),
    ("Mainstays 100% Cotton Bath Towel", "30 x 54 in", "Mainstays", "$4.97", "", "", ""),
    ("Tide Liquid Laundry Detergent", "92 fl oz", "", "$12.97", "", "Digital coupon save $2.00", "$0.14/fl oz"),
    ("Oreo Chocolate Sandwich Cookies", "14.3 oz", "", "$4.48", "$3.98", "Save $0.50", "$0.28/oz"),
    ("Parent's Choice Advantage Infant Formula", "23.2 oz", "Parent's Choice", "$19.98", "", "", "$0.86/oz"),
]


class BaseSourceAdapter(ABC):
    """Abstract adapter representing an authorized or configured data source."""

    @property
    @abstractmethod
    def name(self) -> str:
        pass

    @abstractmethod
    async def check_readiness(self, config: dict) -> AdapterStatus:
        """Check if this data source is operational and ready."""
        pass

    @abstractmethod
    async def collect(
        self,
        config: dict,
        callback: Optional[Callable[[str, int, int], None]] = None,
        cancel_token: Optional[dict] = None,
    ) -> list[ProductRecord]:
        """Collect records according to configuration."""
        pass


class LivePlaywrightAdapter(BaseSourceAdapter):
    """Primary production collector: live browser-based extraction via Playwright."""

    @property
    def name(self) -> str:
        return "live_playwright"

    async def check_readiness(self, config: dict) -> AdapterStatus:
        proxy_host = config.get("proxy_host") or os.environ.get("PROXY_HOST")
        if not proxy_host:
            return AdapterStatus(
                name=self.name,
                status="blocked",
                message=(
                    "Walmart PerimeterX bot challenge active on direct connection. "
                    "An active residential rotating proxy (PROXY_HOST / PROXY_PORT) is required "
                    "for unattended live crawling."
                ),
                capabilities=["playwright_browser", "real_dom_inspection"],
                supports_live=True,
            )
        return AdapterStatus(
            name=self.name,
            status="ready",
            message=f"Residential proxy configured ({proxy_host}). Ready for genuine live extraction.",
            capabilities=["playwright_browser", "residential_proxy", "real_dom_inspection"],
            supports_live=True,
        )

    async def collect(
        self,
        config: dict,
        callback: Optional[Callable[[str, int, int], None]] = None,
        cancel_token: Optional[dict] = None,
    ) -> list[ProductRecord]:
        from walmart.scraper import WalmartScraper
        from walmart.config import ProxyConfig

        proxy_host = config.get("proxy_host") or os.environ.get("PROXY_HOST")
        proxy_cfg = None
        if proxy_host:
            proxy_cfg = ProxyConfig(
                host=proxy_host,
                port=int(config.get("proxy_port") or os.environ.get("PROXY_PORT", 8080)),
                username=config.get("proxy_user") or os.environ.get("PROXY_USER", ""),
                password=config.get("proxy_pass") or os.environ.get("PROXY_PASS", ""),
            ).to_playwright_proxy()

        records: list[ProductRecord] = []
        target_count = int(config.get("target_count", 50))
        category_url = config.get("category_url", "https://www.walmart.com/browse/food/snacks-cookies-chips/976759_976779")
        zipcode = str(config.get("zipcode", "10001")).strip()

        async with WalmartScraper(proxy_config=proxy_cfg, mode="live") as scraper:
            try:
                store_info = await scraper.select_store(zipcode)
            except ChallengePage as cp:
                raise RuntimeError(
                    f"Live extraction blocked by Walmart anti-bot security: {cp}. "
                    f"A valid residential rotating proxy must be configured."
                )

            count = 0
            try:
                async for url in scraper.iter_category_product_urls(category_url):
                    if cancel_token and cancel_token.get("cancelled"):
                        logger.info("Live collection cancelled by user")
                        break

                    rec = await scraper.scrape_product(
                        url=url,
                        store_info=store_info,
                        category=config.get("category", "Grocery"),
                        sub_category=config.get("sub_category", "Products"),
                        zipcode=zipcode,
                    )
                    if rec:
                        records.append(rec)
                        count += 1
                        if callback:
                            callback(f"Live product scraped: {rec.product_title[:32]}...", count, target_count)

                    if count >= target_count:
                        break
            except ChallengePage as cp:
                raise RuntimeError(
                    f"Live extraction interrupted by Walmart anti-bot security: {cp}. "
                    f"Check proxy health and rate limits."
                )

        if not records:
            logger.warning("Live scraper completed but found 0 products.")

        return records


class WalmartApiAdapter(BaseSourceAdapter):
    """Integration for authorized Walmart Developer / Partner APIs."""

    @property
    def name(self) -> str:
        return "walmart_api"

    async def check_readiness(self, config: dict) -> AdapterStatus:
        from core.walmart_api import walmart_api_manager, WalmartApiStatus
        api_cfg = walmart_api_manager.config
        if not api_cfg.is_configured():
            return AdapterStatus(
                name=self.name,
                status="not_configured",
                message="Walmart API credentials (WALMART_API_KEY / Client Secret, Consumer ID) not configured. Configure credentials in the 'Walmart API Configuration' panel.",
                capabilities=["official_api", "high_rate_limits"],
                supports_live=True,
            )

        status_map = {
            WalmartApiStatus.CONNECTED: "ready",
            WalmartApiStatus.CONFIGURATION_SAVED: "ready",
            WalmartApiStatus.TESTING_CONNECTION: "ready",
            WalmartApiStatus.INVALID_CREDENTIALS: "blocked",
            WalmartApiStatus.ACCESS_DENIED: "blocked",
            WalmartApiStatus.RATE_LIMITED: "blocked",
            WalmartApiStatus.NETWORK_ERROR: "blocked",
            WalmartApiStatus.API_ERROR: "blocked",
            WalmartApiStatus.NOT_CONFIGURED: "not_configured",
        }
        st = status_map.get(api_cfg.status, "ready")
        return AdapterStatus(
            name=self.name,
            status=st,
            message=api_cfg.last_test_message,
            capabilities=["official_api", f"type_{api_cfg.integration_type}", f"env_{api_cfg.environment}"],
            supports_live=True,
        )

    async def collect(
        self,
        config: dict,
        callback: Optional[Callable[[str, int, int], None]] = None,
        cancel_token: Optional[dict] = None,
    ) -> list[ProductRecord]:
        from core.walmart_api import walmart_api_manager
        zipcode = str(config.get("zipcode", "10001")).strip()
        category_url = str(config.get("category_url", "")).strip()
        target_count = int(config.get("target_count", 50))

        return await walmart_api_manager.collect_products(
            zipcode=zipcode,
            category_url=category_url,
            target_count=target_count,
            callback=callback,
            cancel_token=cancel_token,
        )


class TestFixtureAdapter(BaseSourceAdapter):
    """Isolated offline test fixtures. Clearly labeled as TEST DATA to prevent masquerading as live."""

    @property
    def name(self) -> str:
        return "test_fixtures"

    async def check_readiness(self, config: dict) -> AdapterStatus:
        return AdapterStatus(
            name=self.name,
            status="ready",
            message="Offline Test Mode. Generates explicitly labeled test fixtures for pipeline testing.",
            capabilities=["synthetic_fixtures", "offline_validation"],
            supports_live=False,
        )

    async def collect(
        self,
        config: dict,
        callback: Optional[Callable[[str, int, int], None]] = None,
        cancel_token: Optional[dict] = None,
    ) -> list[ProductRecord]:
        target_count = int(config.get("target_count", 113))
        zipcode = str(config.get("zipcode", "10001")).strip()
        crawl_date = datetime.date.today().isoformat()

        records: list[ProductRecord] = []
        templates_count = len(TEST_TEMPLATES)

        for i in range(target_count):
            if cancel_token and cancel_token.get("cancelled"):
                break

            title, weight, brand, reg_price, sale_price, deal_text, ppm = TEST_TEMPLATES[i % templates_count]
            item_num = 1000000 + i

            deal = classify_deal(deal_text) if deal_text else None
            vol_desc = deal.description if deal and deal.kind == DealKind.VOLUME else ""
            vol_price = deal.price if deal and deal.kind == DealKind.VOLUME else ""
            dig_desc = deal.description if deal and deal.kind == DealKind.DIGITAL else ""
            dig_price = deal.price if deal and deal.kind == DealKind.DIGITAL else ""

            # Explicitly mark title and store as TEST FIXTURE so it can never be mistaken for live data
            rec = ProductRecord(
                zipcode=zipcode,
                store_name="[TEST FIXTURE] Walmart Store",
                store_location=f"Test Location serving ZIP {zipcode}",
                store_logo="",
                store_brand=brand,
                category="Grocery",
                sub_category="Test Fixtures",
                product_title=f"[TEST FIXTURE] {title} #{i + 1}",
                weight=weight,
                regular_price=reg_price,
                sale_price=sale_price,
                volume_deals_description=vol_desc,
                volume_deals_price=vol_price,
                digital_deals_description=dig_desc,
                digital_deals_price=dig_price,
                image_url=f"https://test.fixtures.local/img/{i}.jpg",
                url=f"https://www.walmart.com/ip/test-item/{item_num}",
                upc=f"0{item_num}12345"[:12],
                gupc="",
                ppm=ppm,
                unit_price="",
                crawl_date=crawl_date,
            )
            records.append(rec)
            if callback and (i % 10 == 0 or i == target_count - 1):
                callback(f"Loaded test fixture {i + 1}/{target_count}", i + 1, target_count)
            await asyncio.sleep(0.005)

        return records
