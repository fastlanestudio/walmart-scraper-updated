import asyncio
import random
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional, AsyncIterator

from playwright.async_api import async_playwright, Browser, BrowserContext, Page

logger = logging.getLogger(__name__)


@dataclass
class CanaryConfig:
    category_url: str
    min_expected_items: int  # fire alert if below this
    category_name: str = "canary"


@dataclass
class ScraperStats:
    categories_done: int = 0
    categories_failed: int = 0
    products_scraped: int = 0
    products_excluded_approx_weight: int = 0
    products_failed_validation: int = 0
    errors: list[tuple[str, str]] = None  # [(category_url, error_msg), ...]

    def __post_init__(self):
        if self.errors is None:
            self.errors = []


class SilentBlockDetected(Exception):
    """Raised when canary category returns suspiciously few results."""
    pass


class ChallengePage(Exception):
    """Raised when a CAPTCHA / bot-challenge page is detected."""
    pass


class BaseSiteScraper(ABC):
    """Abstract base class for all site-specific scrapers.

    Subclasses must implement:
    - select_store(zipcode)
    - iter_category_product_urls(category_url)
    - scrape_product(url, store_info, category, sub_category, zipcode)
    - _count_category_items(category_url)
    """

    def __init__(self, proxy_config: Optional[dict] = None, mode: str = "live"):
        self.proxy_config = proxy_config  # Playwright proxy dict or None
        self.mode = mode                  # "live" or "simulated"
        self.stats = ScraperStats()
        self.canary: Optional[CanaryConfig] = None
        self._browser: Optional[Browser] = None
        self._context: Optional[BrowserContext] = None
        self._pw = None

    async def __aenter__(self):
        await self._launch_browser()
        return self

    async def __aexit__(self, *args):
        await self._close_browser()

    async def _launch_browser(self):
        """Launch Playwright Chromium browser with proxy and a realistic fingerprint."""
        self._pw = await async_playwright().start()

        launch_kwargs = {
            "headless": True,
            "args": [
                "--disable-blink-features=AutomationControlled",
                "--no-sandbox",
                "--disable-dev-shm-usage",
                "--disable-gpu",
                "--window-size=1280,800",
            ],
        }
        if self.proxy_config:
            launch_kwargs["proxy"] = self.proxy_config

        self._browser = await self._pw.chromium.launch(**launch_kwargs)

        context_kwargs = {
            "viewport": {"width": 1280, "height": 800},
            "locale": "en-US",
            "timezone_id": "America/Chicago",
            "user_agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/124.0.0.0 Safari/537.36"
            ),
            "extra_http_headers": {
                "Accept-Language": "en-US,en;q=0.9",
                "Accept": (
                    "text/html,application/xhtml+xml,application/xml;"
                    "q=0.9,image/webp,*/*;q=0.8"
                ),
            },
        }
        self._context = await self._browser.new_context(**context_kwargs)

        # Mask the webdriver property to reduce bot-detection fingerprint
        await self._context.add_init_script(
            "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
        )
        logger.debug("Browser launched successfully")

    async def _close_browser(self):
        """Cleanly close browser context, browser, and Playwright."""
        try:
            if self._context:
                await self._context.close()
        except Exception as e:
            logger.debug(f"Error closing context: {e}")
        try:
            if self._browser:
                await self._browser.close()
        except Exception as e:
            logger.debug(f"Error closing browser: {e}")
        try:
            if self._pw:
                await self._pw.stop()
        except Exception as e:
            logger.debug(f"Error stopping playwright: {e}")

    async def new_page(self) -> Page:
        """Return a new page from the current browser context."""
        return await self._context.new_page()

    def polite_delay(self, base_seconds: float = 2.0, jitter: float = 1.5) -> float:
        """Return a random delay between base_seconds and base_seconds+jitter.
        Caller is responsible for: await asyncio.sleep(self.polite_delay())"""
        return base_seconds + random.uniform(0, jitter)

    async def _retry_with_backoff(
        self,
        coro_factory,
        max_retries: int = 3,
        base_delay: float = 5.0,
    ):
        """Retry an async coroutine with exponential backoff.

        Args:
            coro_factory: A callable that returns a new coroutine each time it is called.
            max_retries: Maximum number of attempts.
            base_delay: Initial delay in seconds (doubles each attempt, with jitter).

        Raises:
            ChallengePage: Immediately re-raised without retrying.
            Exception: The last exception if all retries are exhausted.
        """
        last_exc = None
        for attempt in range(max_retries):
            try:
                return await coro_factory()
            except ChallengePage:
                raise  # don't retry challenge pages — they need proxy rotation
            except Exception as e:
                last_exc = e
                if attempt < max_retries - 1:
                    delay = base_delay * (2 ** attempt) + random.uniform(0, 2)
                    logger.warning(
                        f"Attempt {attempt + 1} failed: {e}. Retrying in {delay:.1f}s"
                    )
                    await asyncio.sleep(delay)
        raise last_exc

    async def check_canary(self) -> bool:
        """Run the canary category check.

        Returns True if healthy.
        Raises SilentBlockDetected if the canary category returns fewer items
        than self.canary.min_expected_items.
        Does nothing if self.canary is not set.
        """
        if not self.canary:
            return True

        logger.info(
            f"Running canary check on category: {self.canary.category_url} "
            f"(min expected: {self.canary.min_expected_items})"
        )
        count = await self._count_category_items(self.canary.category_url)
        logger.info(f"Canary returned {count} items")

        if count < self.canary.min_expected_items:
            raise SilentBlockDetected(
                f"Canary category '{self.canary.category_name}' returned {count} items, "
                f"expected at least {self.canary.min_expected_items}. "
                f"Possible silent block or scraper is broken."
            )
        return True

    @abstractmethod
    async def select_store(self, zipcode: str) -> dict:
        """Set store location by zip code.

        Returns:
            dict with keys: store_name, store_location, store_id

        Must verify the store from the rendered DOM — never trust a cookie/URL
        parameter alone. Raises ValueError if store confirmation cannot be read.
        Raises ChallengePage if a bot-challenge is detected.
        """
        ...

    @abstractmethod
    async def iter_category_product_urls(self, category_url: str) -> AsyncIterator[str]:
        """Yield every product URL in the category.

        Handles pagination and lazy-load. De-duplicates within the category.
        Must terminate cleanly at the last page.
        Yields absolute product URLs as strings.
        """
        ...

    @abstractmethod
    async def scrape_product(
        self,
        url: str,
        store_info: dict,
        category: str,
        sub_category: str,
        zipcode: str,
    ) -> Optional[object]:
        """Scrape a single product page.

        Returns:
            A ProductRecord instance, or None if the product should be
            excluded (approx weight, broken page, validation failure, etc.).

        MUST NOT raise on a bad page — log the reason and return None instead.
        Raises ChallengePage if a bot-challenge is detected (caller handles this).
        """
        ...

    @abstractmethod
    async def _count_category_items(self, category_url: str) -> int:
        """Return the number of product URLs a category yields. Used for canary checks."""
        ...
