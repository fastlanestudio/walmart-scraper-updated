import json
import os
import tempfile
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional
from enum import Enum


class CategoryStatus(Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    DONE = "done"
    FAILED = "failed"


@dataclass
class CategoryCheckpoint:
    category: str
    sub_category: str
    url: str
    status: CategoryStatus = CategoryStatus.PENDING
    products_scraped: int = 0
    error_message: str = ""
    retry_count: int = 0
    max_retries: int = 3

    def to_dict(self) -> dict:
        return {
            "category": self.category,
            "sub_category": self.sub_category,
            "url": self.url,
            "status": self.status.value,
            "products_scraped": self.products_scraped,
            "error_message": self.error_message,
            "retry_count": self.retry_count,
            "max_retries": self.max_retries,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "CategoryCheckpoint":
        return cls(
            category=d["category"],
            sub_category=d["sub_category"],
            url=d["url"],
            status=CategoryStatus(d.get("status", "pending")),
            products_scraped=d.get("products_scraped", 0),
            error_message=d.get("error_message", ""),
            retry_count=d.get("retry_count", 0),
            max_retries=d.get("max_retries", 3),
        )


@dataclass
class RunCheckpoint:
    run_id: str
    store_zipcode: str
    categories: list[CategoryCheckpoint] = field(default_factory=list)

    def save(self, path: str | Path) -> None:
        """Atomically write checkpoint to disk (write-then-rename)."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "run_id": self.run_id,
            "store_zipcode": self.store_zipcode,
            "categories": [c.to_dict() for c in self.categories],
        }
        # Write to a temp file in the same directory, then rename atomically
        dir_ = path.parent
        fd, tmp_path = tempfile.mkstemp(dir=str(dir_), suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            os.replace(tmp_path, str(path))
        except Exception:
            # Clean up temp file if rename failed
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            raise

    @classmethod
    def load(cls, path: str | Path) -> "RunCheckpoint":
        """Load checkpoint from disk."""
        path = Path(path)
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        categories = [CategoryCheckpoint.from_dict(c) for c in data.get("categories", [])]
        return cls(
            run_id=data["run_id"],
            store_zipcode=data["store_zipcode"],
            categories=categories,
        )

    @classmethod
    def load_or_create(
        cls,
        path: str | Path,
        run_id: str,
        store_zipcode: str,
        categories: list,
        resume: bool = True,
    ) -> "RunCheckpoint":
        """Load existing checkpoint if it exists and matches run_id+store_zipcode, else create new."""
        path = Path(path)
        if path.exists():
            try:
                cp = cls.load(path)
                if cp.run_id == run_id and cp.store_zipcode == store_zipcode:
                    return cp
            except (json.JSONDecodeError, KeyError, OSError):
                pass
        # Create fresh checkpoint with all categories in PENDING state
        fresh_categories = [
            CategoryCheckpoint(
                category=getattr(c, "category", c.get("category", "") if isinstance(c, dict) else ""),
                sub_category=getattr(c, "sub_category", c.get("sub_category", "") if isinstance(c, dict) else ""),
                url=getattr(c, "url", c.get("url", "") if isinstance(c, dict) else ""),
                status=CategoryStatus.PENDING,
                products_scraped=0,
                error_message="",
            )
            for c in categories
        ]
        return cls(run_id=run_id, store_zipcode=store_zipcode, categories=fresh_categories)

    def pending_categories(self) -> list[CategoryCheckpoint]:
        return [
            c for c in self.categories
            if c.status in (CategoryStatus.PENDING, CategoryStatus.IN_PROGRESS)
        ]

    def _find_category(self, category: str, sub_category: str) -> Optional[CategoryCheckpoint]:
        for c in self.categories:
            if c.category == category and c.sub_category == sub_category:
                return c
        return None

    def mark_in_progress(self, category: str, sub_category: str) -> None:
        cat = self._find_category(category, sub_category)
        if cat:
            cat.status = CategoryStatus.IN_PROGRESS

    def mark_done(self, category: str, sub_category: str, products_scraped: int) -> None:
        cat = self._find_category(category, sub_category)
        if cat:
            cat.status = CategoryStatus.DONE
            cat.products_scraped = products_scraped
            cat.error_message = ""

    def mark_failed(self, category: str, sub_category: str, error: str, allow_retry: bool = False) -> None:
        cat = self._find_category(category, sub_category)
        if cat:
            cat.error_message = error
            if allow_retry:
                cat.retry_count += 1
                if cat.retry_count < cat.max_retries:
                    cat.status = CategoryStatus.PENDING
                else:
                    cat.status = CategoryStatus.FAILED
            else:
                cat.status = CategoryStatus.FAILED
