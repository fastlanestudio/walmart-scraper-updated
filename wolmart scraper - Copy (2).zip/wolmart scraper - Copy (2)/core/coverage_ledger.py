"""core/coverage_ledger.py
Comprehensive crawl coverage ledger and run manifest tracker.

Tracks:
  - Run metadata: run_id, timestamp, source, zipcode, store_id, is_store_verified
  - Category breakdown: attempted, completed, failed, count per category
  - Request accounting: requested URLs, discovered URLs, failed requests, retries
  - Product accounting: observed, distinct, accepted, excluded (approx weight, unverified)
  - Schema quality metrics: coverage % for upc, regular_price, sale_price, image_url, etc.
  - Error ledger: specific errors encountered during run
  - Persistence: data/coverage_ledger_{run_id}.json and data/run_manifest.json
"""
import os
import json
import datetime
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field, asdict


@dataclass
class CategoryCoverage:
    category: str
    sub_category: str
    url: str
    status: str = "pending"  # "pending", "in_progress", "done", "failed"
    products_scraped: int = 0
    pages_crawled: int = 0
    error_message: str = ""


@dataclass
class CoverageLedger:
    run_id: str
    data_source: str
    zipcode: str
    store_id: str = ""
    is_store_verified: bool = False
    start_time: str = field(default_factory=lambda: datetime.datetime.now(datetime.timezone.utc).isoformat())
    end_time: str = ""
    status: str = "in_progress"  # "in_progress", "completed", "failed", "cancelled"

    # Category tracking
    categories: Dict[str, CategoryCoverage] = field(default_factory=dict)

    # Request accounting
    requested_urls_count: int = 0
    discovered_product_urls_count: int = 0
    failed_requests_count: int = 0
    retries_count: int = 0

    # Product accounting
    total_observations: int = 0
    distinct_products: int = 0
    accepted_products: int = 0
    excluded_approx_weight: int = 0
    excluded_missing_key_fields: int = 0

    # Quality metrics
    products_with_upc: int = 0
    products_with_regular_price: int = 0
    products_with_sale_price: int = 0
    products_with_image: int = 0
    products_with_weight: int = 0
    products_with_ppm: int = 0

    # Errors
    errors: List[Dict[str, Any]] = field(default_factory=list)

    def add_category(self, category: str, sub_category: str, url: str) -> None:
        key = f"{category}::{sub_category}"
        if key not in self.categories:
            self.categories[key] = CategoryCoverage(
                category=category,
                sub_category=sub_category,
                url=url,
            )

    def start_category(self, category: str, sub_category: str) -> None:
        key = f"{category}::{sub_category}"
        if key in self.categories:
            self.categories[key].status = "in_progress"

    def complete_category(self, category: str, sub_category: str, count: int, pages: int = 1) -> None:
        key = f"{category}::{sub_category}"
        if key in self.categories:
            cat = self.categories[key]
            cat.status = "done"
            cat.products_scraped = count
            cat.pages_crawled = pages

    def fail_category(self, category: str, sub_category: str, error: str) -> None:
        key = f"{category}::{sub_category}"
        if key in self.categories:
            cat = self.categories[key]
            cat.status = "failed"
            cat.error_message = error
        self.errors.append({
            "scope": "category",
            "category": category,
            "sub_category": sub_category,
            "error": error,
            "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        })

    def record_observation(
        self,
        product: dict,
        is_distinct: bool = True,
        is_approx_weight_excluded: bool = False,
    ) -> None:
        """Record product-level metrics and quality statistics."""
        self.total_observations += 1
        if is_distinct:
            self.distinct_products += 1

        if is_approx_weight_excluded:
            self.excluded_approx_weight += 1
            return

        if not product.get("product_title") or not product.get("url"):
            self.excluded_missing_key_fields += 1
            return

        self.accepted_products += 1

        if product.get("upc"):
            self.products_with_upc += 1
        if product.get("regular_price"):
            self.products_with_regular_price += 1
        if product.get("sale_price"):
            self.products_with_sale_price += 1
        if product.get("image_url"):
            self.products_with_image += 1
        if product.get("weight"):
            self.products_with_weight += 1
        if product.get("ppm"):
            self.products_with_ppm += 1

    def record_error(self, scope: str, message: str, details: Optional[dict] = None) -> None:
        self.errors.append({
            "scope": scope,
            "message": message,
            "details": details or {},
            "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        })

    def finish(self, status: str = "completed") -> None:
        self.status = status
        self.end_time = datetime.datetime.now(datetime.timezone.utc).isoformat()

    def to_dict(self) -> dict:
        d = asdict(self)
        # Convert category dict keys to list for clean JSON representation
        d["categories"] = [asdict(c) for c in self.categories.values()]
        # Compute percentages
        accepted = max(self.accepted_products, 1)
        d["quality_percentages"] = {
            "upc_pct": round(self.products_with_upc / accepted * 100, 1),
            "regular_price_pct": round(self.products_with_regular_price / accepted * 100, 1),
            "sale_price_pct": round(self.products_with_sale_price / accepted * 100, 1),
            "image_pct": round(self.products_with_image / accepted * 100, 1),
            "weight_pct": round(self.products_with_weight / accepted * 100, 1),
            "ppm_pct": round(self.products_with_ppm / accepted * 100, 1),
        }
        return d

    def save(self, data_dir: str = "data") -> str:
        """Persist coverage ledger to disk and update run manifest."""
        os.makedirs(data_dir, exist_ok=True)
        ledger_path = os.path.join(data_dir, f"coverage_ledger_{self.run_id}.json")
        ledger_data = self.to_dict()

        with open(ledger_path, "w", encoding="utf-8") as f:
            json.dump(ledger_data, f, indent=2)

        # Update run_manifest.json
        manifest_path = os.path.join(data_dir, "run_manifest.json")
        manifest = {}
        if os.path.exists(manifest_path):
            try:
                with open(manifest_path, "r", encoding="utf-8") as mf:
                    manifest = json.load(mf)
            except Exception:
                manifest = {}

        manifest[self.run_id] = {
            "run_id": self.run_id,
            "data_source": self.data_source,
            "zipcode": self.zipcode,
            "store_id": self.store_id,
            "is_store_verified": self.is_store_verified,
            "status": self.status,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "accepted_products": self.accepted_products,
            "distinct_products": self.distinct_products,
            "ledger_path": ledger_path,
        }

        with open(manifest_path, "w", encoding="utf-8") as mf:
            json.dump(manifest, mf, indent=2)

        return ledger_path
