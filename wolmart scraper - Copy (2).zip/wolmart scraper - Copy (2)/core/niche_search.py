"""core/niche_search.py
Dynamic Niche & Keyword Search Engine for Walmart Scraper.

Resolves search queries, niche keywords (e.g. "organic protein bars",
"wireless gaming mice"), and browse URLs to verified Walmart catalog
endpoints with category and sub-category metadata.
"""
import urllib.parse
import re
from typing import Optional, Tuple

# Pre-indexed niche taxonomy mapped directly to verified Walmart catalog URLs
NICHE_TAXONOMY = [
    # Snacks, Cookies, Chips, Protein & Energy Bars
    (
        r"\b(snacks?|chips?|cookies?|crackers?|popcorn|pretzels?|nuts?|bars?|protein\s*bars?|energy\s*bars?|granola\s*bars?)\b",
        "https://www.walmart.com/browse/food/snacks-cookies-chips/976759_976779",
        "Grocery",
        "Snacks",
    ),
    # Beverages & Drinks, Coffee, Tea
    (
        r"\b(beverages?|drinks?|coffee|tea|soda|water|juice|energy\s*drinks?|cold\s*brew|espresso)\b",
        "https://www.walmart.com/browse/food/drinks/976759_976782",
        "Grocery",
        "Beverages",
    ),
    # Breakfast & Cereal
    (
        r"\b(breakfast|cereal|oatmeal|granola|pancake|waffles?|syrup|toaster\s*pastr\w*)\b",
        "https://www.walmart.com/browse/food/breakfast-foods/976759_976780",
        "Grocery",
        "Breakfast & Cereal",
    ),
    # Bread & Bakery
    (
        r"\b(bread|bakery|bagels?|muffins?|tortillas?|buns?|rolls?|croissants?)\b",
        "https://www.walmart.com/browse/food/bread-bakery/976759_976781",
        "Grocery",
        "Bread & Bakery",
    ),
    # Dairy & Eggs
    (
        r"\b(dairy|milk|cheese|yogurt|butter|eggs?|cream|creamer)\b",
        "https://www.walmart.com/browse/food/dairy-eggs/976759_976784",
        "Grocery",
        "Dairy & Eggs",
    ),
    # Pantry Staples & Dry Goods
    (
        r"\b(pantry|pasta|rice|grains?|flour|sugar|oil|olive\s*oil|baking|spices?)\b",
        "https://www.walmart.com/browse/food/pantry-staples/976759_976787",
        "Grocery",
        "Pantry & Dry Goods",
    ),
    # Canned Goods & Soups
    (
        r"\b(canned|soups?|beans?|broth|canned\s*vegetables?|canned\s*fruit|tuna)\b",
        "https://www.walmart.com/browse/food/canned-goods-soups/976759_976783",
        "Grocery",
        "Canned Goods & Soups",
    ),
    # Condiments & Sauces
    (
        r"\b(condiments?|sauces?|ketchup|mustard|mayo|mayonnaise|bbq|salad\s*dressing|marinade)\b",
        "https://www.walmart.com/browse/food/condiments-sauces/976759_976786",
        "Grocery",
        "Condiments & Sauces",
    ),
    # Frozen Foods
    (
        r"\b(frozen|frozen\s*meals?|frozen\s*pizza|ice\s*cream|frozen\s*vegetables?)\b",
        "https://www.walmart.com/browse/food/frozen-foods/976759_976785",
        "Grocery",
        "Frozen Foods",
    ),
    # Meat & Seafood
    (
        r"\b(meat|seafood|beef|chicken|pork|bacon|turkey|salmon|shrimp)\b",
        "https://www.walmart.com/browse/food/meat-seafood/976759_976788",
        "Grocery",
        "Meat & Seafood",
    ),
    # Baby Food & Formula
    (
        r"\b(baby|baby\s*food|formula|infant|toddler|baby\s*wipes?|diapers?)\b",
        "https://www.walmart.com/browse/baby/baby-food-formula/5427_133260",
        "Baby",
        "Baby Food",
    ),
    # Vitamins & Supplements
    (
        r"\b(vitamins?|supplements?|protein\s*powder|creatine|multivitamins?|wellness|gummies)\b",
        "https://www.walmart.com/browse/health/vitamins-supplements/976760_1005862",
        "Personal Care",
        "Vitamins & Supplements",
    ),
    # Cleaning Supplies
    (
        r"\b(cleaning|detergent|dish\s*soap|disinfectant|bleach|sponges?|mop|cleaner)\b",
        "https://www.walmart.com/browse/household-essentials/cleaning-supplies/4044_133032",
        "Household",
        "Cleaning Supplies",
    ),
    # Paper & Plastics
    (
        r"\b(paper\s*towels?|toilet\s*paper|tissues?|trash\s*bags?|napkins?|plates?)\b",
        "https://www.walmart.com/browse/household-essentials/paper-plastics/4044_133030",
        "Household",
        "Paper & Plastics",
    ),
    # Dog Food
    (
        r"\b(dogs?|dog\s*food|puppy|dog\s*treats?|kibble)\b",
        "https://www.walmart.com/browse/pets/dog-food/5440_573092",
        "Pet Care",
        "Dog Food",
    ),
    # Cat Food
    (
        r"\b(cats?|cat\s*food|kitten|cat\s*treats?|litter)\b",
        "https://www.walmart.com/browse/pets/cat-food/5440_573095",
        "Pet Care",
        "Cat Food",
    ),
    # Computer Accessories & Gaming Mice
    (
        r"\b(gaming\s*m\w+|wireless\s*m\w+|mouse|keyboards?|webcams?|monitors?|headsets?)\b",
        "https://www.walmart.com/browse/electronics/computer-accessories/3944_3951_132959",
        "Electronics",
        "Computer Accessories",
    ),
]

DEFAULT_CATEGORY_URL = "https://www.walmart.com/browse/food/snacks-cookies-chips/976759_976779"


def parse_url_categories(url: str) -> Tuple[str, str]:
    """Infer human-readable category and sub-category from Walmart URL path."""
    parsed = urllib.parse.urlparse(url)
    parts = [p for p in parsed.path.split("/") if p and p not in ("browse", "shop", "ip", "search")]
    if len(parts) >= 2:
        cat = parts[0].replace("-", " ").title()
        subcat = parts[1].replace("-", " ").title()
        return cat, subcat
    elif len(parts) == 1:
        cat = parts[0].replace("-", " ").title()
        return cat, "Products"
    return "Grocery", "Products"


def resolve_search_target(
    query_or_url: str,
    default_url: Optional[str] = None,
) -> dict:
    """Resolve a user input (keyword phrase, niche, or URL) to a scraping target.
    
    Returns:
        dict: {
            "target_type": "url" | "niche_keyword" | "search_query",
            "url": str,
            "category": str,
            "sub_category": str,
            "search_term": str,
        }
    """
    input_str = (query_or_url or "").strip()
    fallback = default_url or DEFAULT_CATEGORY_URL

    if not input_str:
        cat, subcat = parse_url_categories(fallback)
        return {
            "target_type": "url",
            "url": fallback,
            "category": cat,
            "sub_category": subcat,
            "search_term": "",
        }

    # If input is already an absolute URL
    if input_str.startswith("http://") or input_str.startswith("https://"):
        cat, subcat = parse_url_categories(input_str)
        if "/search" in input_str:
            parsed = urllib.parse.urlparse(input_str)
            qs = urllib.parse.parse_qs(parsed.query)
            q_val = qs.get("q", [""])[0]
            return {
                "target_type": "search_query",
                "url": input_str,
                "category": cat or "Search",
                "sub_category": q_val.title() if q_val else "Results",
                "search_term": q_val,
            }
        return {
            "target_type": "url",
            "url": input_str,
            "category": cat,
            "sub_category": subcat,
            "search_term": "",
        }

    # Match input against verified niche taxonomy
    lower_query = input_str.lower()
    for pattern, cat_url, cat_name, subcat_name in NICHE_TAXONOMY:
        if re.search(pattern, lower_query, re.IGNORECASE):
            return {
                "target_type": "niche_keyword",
                "url": cat_url,
                "category": cat_name,
                "sub_category": subcat_name,
                "search_term": input_str,
            }

    # Direct keyword search fallback
    search_url = f"https://www.walmart.com/search?q={urllib.parse.quote_plus(input_str)}"
    return {
        "target_type": "search_query",
        "url": search_url,
        "category": "Retail",
        "sub_category": input_str.title(),
        "search_term": input_str,
    }
