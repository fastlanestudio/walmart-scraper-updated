#!/usr/bin/env python3
"""
walmart_crawler.py — ScrapeOps-aligned Product URL Discovery Crawler for Walmart.com.

Follows the ScrapeOps decoupled crawler+scraper architecture:
- Discovers product URLs from category URLs or keyword searches.
- Paginates up to --max-pages.
- Integrates with ScrapeOps Proxy Aggregator (https://proxy.scrapeops.io/v1/)
  or ScrapeOps Residential Proxy (residential-proxy.scrapeops.io:8181).
- Outputs discovered URLs to a JSONL handoff file for walmart_product_scraper.py.

Usage:
    python walmart_crawler.py --category-url "https://www.walmart.com/browse/food/976759" --max-pages 2 --output urls.jsonl
    python walmart_crawler.py --keywords "chips, cookies" --max-pages 1 --output urls.jsonl
"""
import argparse
import json
import logging
import os
import sys
from urllib.parse import urlencode, quote_plus
from typing import Optional

from curl_cffi import requests
from selectolax.lexbor import LexborHTMLParser as HTMLParser

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("walmart_crawler")

SEARCH_URL_BASE = "https://www.walmart.com/search"
SCRAPEOPS_PROXY_API = "https://proxy.scrapeops.io/v1/"
SCRAPEOPS_RESIDENTIAL_HOST = "residential-proxy.scrapeops.io:8181"


def get_scrapeops_api_key(cli_key: Optional[str] = None) -> str:
    """Read ScrapeOps API key from CLI argument, environment, or Claude config."""
    if cli_key:
        return cli_key.strip()
    env_key = os.environ.get("SCRAPEOPS_API_KEY")
    if env_key:
        return env_key.strip()

    # Check ~/.claude/settings.json if present
    claude_settings = os.path.expanduser("~/.claude/settings.json")
    if os.path.exists(claude_settings):
        try:
            with open(claude_settings, "r", encoding="utf-8") as f:
                settings = json.load(f)
                key = settings.get("env", {}).get("SCRAPEOPS_API_KEY")
                if key:
                    return key.strip()
        except Exception:
            pass
    return ""


def build_search_url(keyword: str, page: int = 1) -> str:
    """Build Walmart search listing URL from keyword and page number."""
    params = {"q": keyword}
    if page > 1:
        params["page"] = str(page)
    return f"{SEARCH_URL_BASE}?{urlencode(params)}"


def build_category_url(base_category_url: str, page: int = 1) -> str:
    """Build paginated category URL."""
    clean_base = base_category_url.split("?")[0]
    if page > 1:
        return f"{clean_base}?page={page}"
    return clean_base


def fetch_listing_html(
    target_url: str,
    api_key: str = "",
    use_residential_proxy: bool = False,
    timeout: int = 45,
) -> str:
    """
    Fetch listing page HTML using ScrapeOps proxy or direct fallback.
    """
    # 1. ScrapeOps Proxy API Mode
    if api_key and not use_residential_proxy:
        proxy_params = {
            "api_key": api_key,
            "url": target_url,
            "residential": "true",
            "country": "us",
        }
        api_url = f"{SCRAPEOPS_PROXY_API}?{urlencode(proxy_params)}"
        logger.info("Fetching via ScrapeOps Proxy API: %s", target_url)
        resp = requests.get(api_url, timeout=timeout)
        if resp.status_code == 200:
            return resp.text
        logger.warning("ScrapeOps Proxy API returned HTTP %s for %s", resp.status_code, target_url)

    # 2. ScrapeOps Residential Proxy / Direct curl_cffi Mode
    proxy_url = None
    if api_key and use_residential_proxy:
        proxy_url = f"http://scrapeops:{api_key}@{SCRAPEOPS_RESIDENTIAL_HOST}"
    elif os.environ.get("PROXY_HOST") and os.environ.get("PROXY_PORT"):
        host = os.environ.get("PROXY_HOST")
        port = os.environ.get("PROXY_PORT")
        user = os.environ.get("PROXY_USER", "")
        pw = os.environ.get("PROXY_PASS", "")
        proxy_url = f"http://{user}:{pw}@{host}:{port}" if user else f"http://{host}:{port}"

    logger.info("Fetching via curl_cffi (impersonate=chrome124): %s", target_url)
    resp = requests.get(
        target_url,
        impersonate="chrome124",
        proxy=proxy_url,
        timeout=timeout,
    )
    if resp.status_code == 200:
        return resp.text
    logger.warning("Listing fetch returned HTTP %s for %s", resp.status_code, target_url)
    return ""


def extract_product_urls_from_html(html: str) -> list[str]:
    """
    Extract product URLs from Walmart listing HTML.
    Tries __NEXT_DATA__ first, then falls back to selectolax DOM parsing.
    """
    if not html:
        return []

    urls = []
    seen = set()

    # 1. Fast Embedded JSON
    idx = html.find('id="__NEXT_DATA__"')
    if idx != -1:
        tag_start = html.rfind('<script', 0, idx)
        if tag_start != -1:
            tag_end = html.find('>', idx)
            if tag_end != -1:
                end = html.find('</script>', tag_end)
                if end != -1:
                    try:
                        data = json.loads(html[tag_end + 1:end].strip())
                        item_stacks = (
                            data.get("props", {})
                            .get("pageProps", {})
                            .get("initialData", {})
                            .get("searchResult", {})
                            .get("itemStacks", [])
                        )
                        for stack in item_stacks:
                            for item in stack.get("items", []):
                                u = item.get("canonicalUrl") or item.get("productUrl")
                                if u and "/ip/" in u and not str(u).startswith("/sp/"):
                                    if u.startswith("/"):
                                        u = f"https://www.walmart.com{u}"
                                    clean_u = u.split("?")[0]
                                    if "/ip/" in clean_u and not clean_u.startswith("https://www.walmart.com/sp/"):
                                        if clean_u not in seen:
                                            seen.add(clean_u)
                                            urls.append(clean_u)
                    except Exception as e:
                        logger.debug("Failed parsing embedded category JSON: %s", e)

    # 2. selectolax DOM fallback
    if not urls:
        tree = HTMLParser(html)
        for a in tree.css('a[href*="/ip/"]'):
            href = a.attributes.get("href", "")
            if href and "/ip/" in href and not href.startswith("/sp/") and not href.startswith("https://www.walmart.com/sp/"):
                if href.startswith("/"):
                    href = f"https://www.walmart.com{href}"
                clean_u = href.split("?")[0]
                if clean_u not in seen:
                    seen.add(clean_u)
                    urls.append(clean_u)

    return urls


def crawl_walmart(
    targets: list[str],
    max_pages: int = 1,
    api_key: str = "",
    use_residential_proxy: bool = False,
    output_file: str = "walmart_product_urls.jsonl",
) -> int:
    """
    Crawl listing URLs, extract product URLs, and write to JSONL handoff file.
    """
    total_discovered = 0
    all_seen = set()

    # Ensure parent output directory exists
    out_dir = os.path.dirname(output_file)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)

    with open(output_file, "w", encoding="utf-8") as f_out:
        for target_base in targets:
            logger.info("Starting crawl for base: %s (max_pages=%d)", target_base, max_pages)
            for page in range(1, max_pages + 1):
                listing_url = (
                    build_category_url(target_base, page)
                    if "/browse/" in target_base
                    else (f"{target_base}&page={page}" if page > 1 and "?" in target_base else target_base)
                )

                html = fetch_listing_html(
                    listing_url,
                    api_key=api_key,
                    use_residential_proxy=use_residential_proxy,
                )
                if not html:
                    logger.warning("No HTML returned for page %d (%s), terminating branch", page, listing_url)
                    break

                page_urls = extract_product_urls_from_html(html)
                new_in_page = 0
                for u in page_urls:
                    if u not in all_seen:
                        all_seen.add(u)
                        f_out.write(json.dumps({
                            "url": u,
                            "source_listing": listing_url,
                            "page": page,
                        }) + "\n")
                        f_out.flush()
                        new_in_page += 1
                        total_discovered += 1

                logger.info("Page %d yielded %d new product URLs (running total: %d)", page, new_in_page, total_discovered)
                if new_in_page == 0:
                    break

    logger.info("Crawl complete. Discovered %d total unique product URLs -> %s", total_discovered, output_file)
    return total_discovered


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="ScrapeOps Walmart URL Discovery Crawler")
    parser.add_argument("--category-url", help="Walmart category URL to crawl")
    parser.add_argument("--keywords", help="Comma-separated search keywords (e.g. 'cookies, chips')")
    parser.add_argument("--max-pages", type=int, default=1, help="Max pagination depth per target (default: 1)")
    parser.add_argument("--output", default="walmart_product_urls.jsonl", help="Output JSONL path for discovered URLs")
    parser.add_argument("--api-key", help="ScrapeOps API key (overrides SCRAPEOPS_API_KEY env)")
    parser.add_argument("--residential", action="store_true", help="Use ScrapeOps Residential Proxy tunnel instead of Proxy API")
    args = parser.parse_args()

    scrapeops_key = get_scrapeops_api_key(args.api_key)
    if scrapeops_key:
        logger.info("ScrapeOps proxy enabled (Key: %s••••••••)", scrapeops_key[:6])
    else:
        logger.info("No ScrapeOps API key found — running in direct/curl_cffi mode")

    target_urls = []
    if args.category_url:
        target_urls.append(args.category_url)
    elif args.keywords:
        for kw in args.keywords.split(","):
            kw_clean = kw.strip()
            if kw_clean:
                target_urls.append(build_search_url(kw_clean))
    else:
        # Default category if none specified
        default_cat = "https://www.walmart.com/browse/food/snacks-cookies-chips/976759_976779"
        logger.info("No target specified. Using default category: %s", default_cat)
        target_urls.append(default_cat)

    crawl_walmart(
        targets=target_urls,
        max_pages=args.max_pages,
        api_key=scrapeops_key,
        use_residential_proxy=args.residential,
        output_file=args.output,
    )
