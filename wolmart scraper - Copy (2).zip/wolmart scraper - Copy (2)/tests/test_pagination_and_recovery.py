"""tests/test_pagination_and_recovery.py
Regression tests for pagination beyond 5 pages, checkpoint resume, bounded retries, and repeat-run idempotency.
"""
import pytest
import asyncio
from unittest.mock import AsyncMock, patch, MagicMock

from core.checkpoint import RunCheckpoint, CategoryCheckpoint, CategoryStatus
from core.store import StoreDB
from walmart.scraper import WalmartScraper


def test_checkpoint_resume_across_restarts(tmp_path):
    cp_file = tmp_path / "checkpoint.json"
    categories = [
        CategoryCheckpoint("Grocery", f"Subcat_{i}", f"https://walmart.com/{i}")
        for i in range(10)
    ]
    cp = RunCheckpoint("run_001", "10001", categories)

    # Complete first 4 categories
    for i in range(4):
        cp.mark_done("Grocery", f"Subcat_{i}", products_scraped=10)
    cp.save(cp_file)

    # Simulate restart: load from disk with resume=True
    resumed_cp = RunCheckpoint.load_or_create(
        cp_file, "run_001", "10001", categories, resume=True
    )
    pending = resumed_cp.pending_categories()
    assert len(pending) == 6
    assert pending[0].sub_category == "Subcat_4"
    assert pending[-1].sub_category == "Subcat_9"


def test_bounded_retry_for_failed_categories():
    cat = CategoryCheckpoint("Grocery", "Snacks", "https://walmart.com/snacks", max_retries=3)
    cp = RunCheckpoint("run_001", "10001", [cat])

    # 1st failure: retry allowed -> remains PENDING
    cp.mark_failed("Grocery", "Snacks", "Network timeout 1", allow_retry=True)
    assert cat.retry_count == 1
    assert cat.status == CategoryStatus.PENDING

    # 2nd failure: retry allowed -> remains PENDING
    cp.mark_failed("Grocery", "Snacks", "Network timeout 2", allow_retry=True)
    assert cat.retry_count == 2
    assert cat.status == CategoryStatus.PENDING

    # 3rd failure: reaches max_retries -> transitions to FAILED
    cp.mark_failed("Grocery", "Snacks", "Network timeout 3", allow_retry=True)
    assert cat.retry_count == 3
    assert cat.status == CategoryStatus.FAILED


def test_repeat_run_idempotency(tmp_path):
    db_file = tmp_path / "walmart_idempotent.db"
    db = StoreDB(str(db_file))

    item = {
        "zipcode": "10001", "store_name": "Walmart", "store_location": "Secaucus",
        "store_logo": "", "store_brand": "Brand", "category": "Food", "sub_category": "Snacks",
        "product_title": "Idempotent Chips", "weight": "10 oz", "regular_price": "$2.99",
        "sale_price": "", "volume_deals_description": "", "volume_deals_price": "",
        "digital_deals_description": "", "digital_deals_price": "",
        "image_url": "https://img.jpg", "url": "https://walmart.com/ip/chips/9999",
        "upc": "012345678999", "gupc": "", "ppm": "", "unit_price": "", "crawl_date": "2026-10-25"
    }
    p_key = db._product_key(item)

    # Run 1
    db.begin_run("run_1", "10001")
    db.stage_product(p_key, "run_1", item, is_test=0)
    db.publish_run("run_1")

    stats1 = db.get_stats()
    assert stats1["total_records"] == 1
    assert stats1["live_records"] == 1

    # Run 2 on exact same item
    db.begin_run("run_2", "10001")
    db.stage_product(p_key, "run_2", item, is_test=0)
    db.publish_run("run_2")

    stats2 = db.get_stats()
    # Total count must NOT increase (no duplicates)
    assert stats2["total_records"] == 1
    assert stats2["live_records"] == 1
    assert stats2["carried_forward"] == 0


def test_pagination_beyond_five_pages():
    async def _run():
        scraper = WalmartScraper(mode="simulated")

        page_counter = [0]
        async def mock_evaluate(script):
            page_counter[0] += 1
            p = page_counter[0]
            return [f"https://walmart.com/ip/item-page-{p}-{i}" for i in range(3)]

        mock_page = AsyncMock()
        mock_page.goto = AsyncMock()
        mock_page.close = AsyncMock()
        mock_page.evaluate = AsyncMock(side_effect=mock_evaluate)
        mock_page.query_selector = AsyncMock(return_value=None)

        scraper.new_page = AsyncMock(return_value=mock_page)
        scraper._detect_challenge = AsyncMock()
        scraper.polite_delay = MagicMock(return_value=0.001)

        urls = []
        # Request up to 8 pages (default was hardcoded 5)
        async for u in scraper.iter_category_product_urls("https://walmart.com/browse/test", max_pages=8):
            urls.append(u)

        # 8 pages * 3 items = 24 items
        assert len(urls) == 24
        assert "https://walmart.com/ip/item-page-8-0" in urls

    asyncio.run(_run())
