"""
tests/test_promotions_and_pack_sizes.py — Regression tests for:
1. Multipack count and individual package size preservation (e.g. '12 pack, 12 fl oz cans')
2. Exclusion of approximate/variable weight products
3. Retention of valid bulk, family-size, and multipack items
4. Promotion semantics: Rollback is not a volume deal; savings is not payable price
"""
import pytest
from core.schema import extract_pack_and_weight, is_approx_weight
from core.deal_classifier import classify_deal, DealKind


def test_multipack_preserves_count_and_unit_size():
    # Client defect: "A product described as '12 pack, 12 fl oz cans' loses the individual-can size."
    title = "Coca-Cola Original Soda Pop, 12 pack, 12 fl oz cans"
    weight = extract_pack_and_weight(title)
    assert "12 pack" in weight
    assert "12 fl oz" in weight
    assert not is_approx_weight(weight)


def test_multipack_with_slash_and_pk():
    title = "Purified Drinking Water, 24 pk / 16.9 fl oz bottles"
    weight = extract_pack_and_weight(title)
    assert "24 pk" in weight
    assert "16.9 fl oz" in weight
    assert not is_approx_weight(weight)


def test_multipack_with_multiplier():
    title = "San Pellegrino Sparkling Mineral Water, 6 x 11.15 fl oz"
    weight = extract_pack_and_weight(title)
    assert "6 pack" in weight
    assert "11.15 fl oz" in weight


def test_standalone_weights():
    assert extract_pack_and_weight("Great Value Whole Milk, 1 gallon") == ""  # Gallon handled or fallback
    assert extract_pack_and_weight("Wonder Classic White Bread, 20 oz") == "20 oz"
    assert extract_pack_and_weight("Great Value Large White Eggs, 18 count") == "18 count"


def test_retain_bulk_and_family_size():
    # Valid bulk and family size items must NOT be excluded as approximate
    title = "Lay's Classic Potato Chips, Party Size, 13 oz bag"
    weight = extract_pack_and_weight(title)
    assert weight == "13 oz"
    assert not is_approx_weight(weight)
    assert not is_approx_weight(title)

    family_title = "Cheerios Cereal, Family Size, 18.8 oz"
    assert not is_approx_weight(family_title)


def test_exclude_approximate_weight_variations():
    # Approximate wording must be excluded
    assert is_approx_weight("approx 1.5 lbs")
    assert is_approx_weight("approximately 2 lbs")
    assert is_approx_weight("Beef Chuck Roast, approx. 2.5 lb")
    assert is_approx_weight("Fresh Bananas (about 3 lbs)")
    assert is_approx_weight("Organic Chicken Breast, avg wt 1.25 lb")
    assert is_approx_weight("Pork Chops, variable weight")
    assert is_approx_weight("Grapes, $1.98 per lb")


def test_clip_coupon_save_semantics():
    # Client regression: "Clip Coupon: Save $2 is incorrectly stored as a payable digital deal price of $2"
    result = classify_deal("Clip Coupon: Save $2")
    assert result.kind == DealKind.DIGITAL
    assert result.price == ""  # Payable price must be empty
    assert result.savings == "$2"


def test_rollback_semantics():
    # Client regression: "Rollback $3.99 is incorrectly classified as a volume deal"
    result = classify_deal("Rollback $3.99")
    assert result.kind == DealKind.SALE
    assert result.kind != DealKind.VOLUME
    assert result.price == "$3.99"
