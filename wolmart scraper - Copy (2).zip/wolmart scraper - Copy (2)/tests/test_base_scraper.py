"""tests/test_base_scraper.py — Tests for core/base_scraper.py"""
import asyncio
import pytest
from dataclasses import dataclass
from typing import Optional, AsyncIterator

from core.base_scraper import (
    BaseSiteScraper,
    CanaryConfig,
    ScraperStats,
    SilentBlockDetected,
    ChallengePage,
)


# ─── Concrete stub of BaseSiteScraper for testing ─────────────────────────────

class StubScraper(BaseSiteScraper):
    """Minimal concrete implementation for unit testing BaseSiteScraper."""

    def __init__(self, canary_count: int = 100, **kwargs):
        super().__init__(**kwargs)
        self._canary_count = canary_count
        self._browser_launched = False
        self._browser_closed = False

    async def _launch_browser(self):
        self._browser_launched = True

    async def _close_browser(self):
        self._browser_closed = True

    async def new_page(self):
        raise NotImplementedError("Not needed in unit tests")

    async def select_store(self, zipcode: str) -> dict:
        return {"store_name": "Test Store", "store_location": "Test City", "store_id": "999"}

    async def iter_category_product_urls(self, category_url: str) -> AsyncIterator[str]:
        for i in range(5):
            yield f"https://example.com/ip/product/{i}"

    async def scrape_product(self, url, store_info, category, sub_category, zipcode):
        return None

    async def _count_category_items(self, category_url: str) -> int:
        return self._canary_count


class FailingScraper(StubScraper):
    """Scraper that fails on every operation for retry tests."""

    def __init__(self, fail_count: int = 2, **kwargs):
        super().__init__(**kwargs)
        self._call_count = 0
        self._fail_count = fail_count

    async def _unreliable_operation(self):
        self._call_count += 1
        if self._call_count <= self._fail_count:
            raise ConnectionError(f"Simulated failure #{self._call_count}")
        return "success"


# ─── Tests ────────────────────────────────────────────────────────────────────

class TestScraperStats:
    def test_default_values(self):
        stats = ScraperStats()
        assert stats.categories_done == 0
        assert stats.categories_failed == 0
        assert stats.products_scraped == 0
        assert stats.products_excluded_approx_weight == 0
        assert stats.products_failed_validation == 0
        assert stats.errors == []

    def test_errors_list_is_not_shared(self):
        s1 = ScraperStats()
        s2 = ScraperStats()
        s1.errors.append(("url", "err"))
        assert len(s2.errors) == 0


class TestCanaryConfig:
    def test_canary_config_fields(self):
        cfg = CanaryConfig(
            category_url="https://walmart.com/browse/snacks",
            min_expected_items=50,
            category_name="snacks",
        )
        assert cfg.category_url == "https://walmart.com/browse/snacks"
        assert cfg.min_expected_items == 50
        assert cfg.category_name == "snacks"

    def test_default_category_name(self):
        cfg = CanaryConfig(
            category_url="https://walmart.com/browse/snacks",
            min_expected_items=50,
        )
        assert cfg.category_name == "canary"


class TestPoliteDelay:
    def test_delay_within_bounds(self):
        scraper = StubScraper()
        for _ in range(100):
            delay = scraper.polite_delay(base_seconds=2.0, jitter=1.5)
            assert 2.0 <= delay <= 3.5, f"Delay {delay} out of bounds"

    def test_default_delay_within_bounds(self):
        scraper = StubScraper()
        delay = scraper.polite_delay()
        assert 2.0 <= delay <= 3.5


class TestContextManager:
    def test_async_context_manager_launches_and_closes(self):
        async def run():
            scraper = StubScraper()
            async with scraper as s:
                assert s._browser_launched is True
            assert scraper._browser_closed is True

        asyncio.run(run())


class TestCheckCanary:
    def test_canary_passes_when_count_above_threshold(self):
        async def run():
            scraper = StubScraper(canary_count=100)
            scraper.canary = CanaryConfig(
                category_url="https://example.com/snacks",
                min_expected_items=50,
            )
            result = await scraper.check_canary()
            assert result is True

        asyncio.run(run())

    def test_canary_raises_silent_block_when_below_threshold(self):
        async def run():
            scraper = StubScraper(canary_count=10)
            scraper.canary = CanaryConfig(
                category_url="https://example.com/snacks",
                min_expected_items=50,
            )
            with pytest.raises(SilentBlockDetected):
                await scraper.check_canary()

        asyncio.run(run())

    def test_canary_skipped_when_not_set(self):
        async def run():
            scraper = StubScraper(canary_count=0)  # Zero items, but canary not set
            result = await scraper.check_canary()
            assert result is True  # No canary configured → always True

        asyncio.run(run())

    def test_canary_at_exact_threshold_passes(self):
        async def run():
            scraper = StubScraper(canary_count=50)
            scraper.canary = CanaryConfig(
                category_url="https://example.com/snacks",
                min_expected_items=50,
            )
            result = await scraper.check_canary()
            assert result is True

        asyncio.run(run())

    def test_canary_one_below_threshold_fails(self):
        async def run():
            scraper = StubScraper(canary_count=49)
            scraper.canary = CanaryConfig(
                category_url="https://example.com/snacks",
                min_expected_items=50,
            )
            with pytest.raises(SilentBlockDetected):
                await scraper.check_canary()

        asyncio.run(run())


class TestRetryWithBackoff:
    def test_succeeds_on_first_attempt(self):
        async def run():
            scraper = StubScraper()
            call_count = [0]

            async def op():
                call_count[0] += 1
                return "ok"

            result = await scraper._retry_with_backoff(op, max_retries=3, base_delay=0.01)
            assert result == "ok"
            assert call_count[0] == 1

        asyncio.run(run())

    def test_retries_on_failure_then_succeeds(self):
        async def run():
            scraper = StubScraper()
            call_count = [0]

            async def op():
                call_count[0] += 1
                if call_count[0] < 3:
                    raise ValueError("transient error")
                return "ok"

            result = await scraper._retry_with_backoff(op, max_retries=3, base_delay=0.01)
            assert result == "ok"
            assert call_count[0] == 3

        asyncio.run(run())

    def test_raises_after_max_retries(self):
        async def run():
            scraper = StubScraper()
            call_count = [0]

            async def op():
                call_count[0] += 1
                raise RuntimeError("always fails")

            with pytest.raises(RuntimeError, match="always fails"):
                await scraper._retry_with_backoff(op, max_retries=3, base_delay=0.01)

            assert call_count[0] == 3

        asyncio.run(run())

    def test_challenge_page_not_retried(self):
        async def run():
            scraper = StubScraper()
            call_count = [0]

            async def op():
                call_count[0] += 1
                raise ChallengePage("CAPTCHA!")

            with pytest.raises(ChallengePage):
                await scraper._retry_with_backoff(op, max_retries=3, base_delay=0.01)

            # Should only be called once — no retry on ChallengePage
            assert call_count[0] == 1

        asyncio.run(run())


class TestIterCategoryProductUrls:
    def test_stub_yields_product_urls(self):
        async def run():
            scraper = StubScraper()
            urls = []
            async for url in scraper.iter_category_product_urls("https://example.com"):
                urls.append(url)
            return urls

        urls = asyncio.run(run())
        assert len(urls) == 5
        assert all("product" in u for u in urls)


class TestSelectStore:
    def test_select_store_returns_dict(self):
        async def run():
            scraper = StubScraper()
            info = await scraper.select_store("10001")
            return info

        info = asyncio.run(run())
        assert isinstance(info, dict)
        assert "store_name" in info
        assert "store_location" in info
