"""tests/test_oxylabs_adapter.py
Unit and regression tests for Oxylabs Realtime API adapter.
"""
import os
import json
import asyncio
import pytest
from unittest.mock import patch, MagicMock
import urllib.error

from core.oxylabs_adapter import (
    OxylabsWalmartAdapter,
    sanitize_credentials,
    OXYLABS_REALTIME_URL,
)
from core.schema import ProductRecord


def test_sanitize_credentials():
    secret_pass = "SuperSecretPassword123"
    secret_user = "oxylabs_user_xyz"
    raw = f"Error connecting with Basic b3h5bGFic191c2VyX3h5ejpTdXBlclNlY3JldFBhc3N3b3JkMTIz and https://{secret_user}:{secret_pass}@proxy.com"

    sanitized = sanitize_credentials(raw, username=secret_user, password=secret_pass)
    assert secret_pass not in sanitized
    assert "Basic ***REDACTED***" in sanitized or "***REDACTED***" in sanitized
    assert "://***:***@" in sanitized


def test_readiness_not_configured(monkeypatch):
    monkeypatch.delenv("OXYLABS_USERNAME", raising=False)
    monkeypatch.delenv("OXYLABS_PASSWORD", raising=False)

    async def _run():
        adapter = OxylabsWalmartAdapter(username="", password="")
        status = await adapter.check_readiness({})
        assert status.status == "not_configured"
        assert "not configured" in status.message

    asyncio.run(_run())


def test_readiness_configured(monkeypatch):
    async def _run():
        adapter = OxylabsWalmartAdapter(username="test_user", password="secret_password")
        status = await adapter.check_readiness({})
        assert status.status == "ready"
        assert status.supports_live is True
        assert "te***" in status.message

    asyncio.run(_run())


def test_build_payload():
    adapter = OxylabsWalmartAdapter(username="user", password="pw")
    payload = adapter.build_payload(
        url="https://www.walmart.com/ip/12345",
        zipcode="90210",
        store_id="3245",
    )
    assert payload["source"] == "walmart"
    assert payload["url"] == "https://www.walmart.com/ip/12345"
    assert payload["user_agent_type"] == "desktop"
    assert payload["geo_location"] == "United States"
    assert {"key": "zip", "value": "90210"} in payload["context"]
    assert {"key": "store_id", "value": "3245"} in payload["context"]


def test_parse_product_from_html_json_ld():
    adapter = OxylabsWalmartAdapter(username="user", password="pw")
    sample_html = """
    <html>
      <head>
        <script type="application/ld+json">
        {
          "@context": "https://schema.org",
          "@type": "Product",
          "name": "Great Value Whole Milk, 1 Gallon",
          "gtin12": "078742351866",
          "brand": {
            "@type": "Brand",
            "name": "Great Value"
          },
          "image": ["https://i5.walmartimages.com/milk.jpg"],
          "offers": {
            "@type": "Offer",
            "price": 3.48,
            "priceCurrency": "USD"
          }
        }
        </script>
      </head>
      <body>
        <h1>Great Value Whole Milk, 1 Gallon</h1>
        <div class="ppm">($0.03/fl oz)</div>
      </body>
    </html>
    """
    rec = adapter.parse_product_from_html(
        sample_html,
        url="https://www.walmart.com/ip/great-value-milk/10450114",
        zipcode="72712",
        category="Dairy",
        sub_category="Milk",
        store_name="Walmart Supercenter Bentonville",
    )

    assert rec is not None
    assert isinstance(rec, ProductRecord)
    assert rec.product_title == "Great Value Whole Milk, 1 Gallon"
    assert rec.upc == "078742351866"
    assert rec.regular_price == "$3.48"
    assert rec.store_brand == "Great Value"
    assert rec.store_name == "Walmart Supercenter Bentonville"
    assert rec.ppm == "$0.03/fl oz"
    assert rec.gupc == ""
    assert rec.unit_price == ""
    assert rec.zipcode == "72712"


def test_parse_category_product_urls():
    adapter = OxylabsWalmartAdapter(username="user", password="pw")
    sample_html = """
    <div>
      <a href="/ip/Great-Value-Chips/1001">Chips</a>
      <a href="/ip/Doritos-Nacho/1002?variant=1">Doritos</a>
      <a href="/ip/Great-Value-Chips/1001">Duplicate Chips</a>
      <a href="/browse/snacks">Category Link</a>
    </div>
    """
    urls = adapter.parse_category_product_urls(sample_html)
    assert len(urls) == 2
    assert "https://www.walmart.com/ip/Great-Value-Chips/1001" in urls
    assert "https://www.walmart.com/ip/Doritos-Nacho/1002" in urls


def test_execute_query_401_unauthorized():
    adapter = OxylabsWalmartAdapter(username="bad_user", password="bad_password")
    mock_err = urllib.error.HTTPError(
        url=OXYLABS_REALTIME_URL,
        code=401,
        msg="Unauthorized",
        hdrs={},
        fp=None,
    )
    with patch("urllib.request.urlopen", side_effect=mock_err):
        with pytest.raises(PermissionError) as exc_info:
            adapter.execute_query_sync({"source": "walmart", "url": "https://walmart.com"})
        assert "401" in str(exc_info.value)
        assert "bad_password" not in str(exc_info.value)


def test_execute_query_429_rate_limit():
    adapter = OxylabsWalmartAdapter(username="user", password="password")
    mock_err = urllib.error.HTTPError(
        url=OXYLABS_REALTIME_URL,
        code=429,
        msg="Too Many Requests",
        hdrs={},
        fp=None,
    )
    with patch("urllib.request.urlopen", side_effect=mock_err):
        with pytest.raises(RuntimeError) as exc_info:
            adapter.execute_query_sync({"source": "walmart", "url": "https://walmart.com"})
        assert "429" in str(exc_info.value)
