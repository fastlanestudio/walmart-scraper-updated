"""
tests/test_walmart_api.py — Unit tests for Walmart API configuration, secure credential management,
OAuth 2.0 token flow, endpoint verification, and masked diagnostics.
"""

import os
import json
import tempfile
import asyncio
from pathlib import Path
import pytest
from unittest.mock import AsyncMock, patch, MagicMock

import aiohttp

from core.walmart_api import (
    WalmartApiManager,
    WalmartApiConfig,
    WalmartApiStatus,
    mask_identifier,
    mask_secret,
)


def test_masking_utilities():
    assert mask_identifier("") == ""
    assert mask_identifier("short") == "••••••••"
    assert mask_identifier("1234567890abcdef") == "1234••••••••cdef"

    assert mask_secret("") == ""
    assert mask_secret("my_super_secret_key_12345") == "••••••••••••"


def test_config_save_and_persistence():
    with tempfile.TemporaryDirectory() as tmpdir:
        secrets_file = Path(tmpdir) / "walmart_api.json"
        mgr = WalmartApiManager(secrets_path=secrets_file)

        assert not mgr.config.is_configured()
        assert mgr.config.status == WalmartApiStatus.NOT_CONFIGURED

        # Save valid OPD config
        saved = mgr.save_config({
            "integration_type": "opd_retail",
            "environment": "production",
            "consumer_id": "c001-org-uuid",
            "client_id": "client-abc-123",
            "client_secret": "secret-xyz-789",
        })

        assert saved.is_configured()
        assert saved.status == WalmartApiStatus.CONFIGURATION_SAVED
        assert saved.consumer_id == "c001-org-uuid"
        assert saved.client_id == "client-abc-123"
        assert saved.client_secret == "secret-xyz-789"

        # Check file was written to disk
        assert secrets_file.exists()
        with open(secrets_file, "r", encoding="utf-8") as f:
            disk_data = json.load(f)
            assert disk_data["consumer_id"] == "c001-org-uuid"
            assert disk_data["client_id"] == "client-abc-123"

        # Check masked dict
        masked = mgr.config.to_masked_dict()
        assert masked["is_configured"] is True
        assert masked["client_secret_masked"] == "••••••••••••"
        assert "secret-xyz-789" not in str(masked)

        # Reloading fresh manager from disk preserves config
        mgr2 = WalmartApiManager(secrets_path=secrets_file)
        assert mgr2.config.is_configured()
        assert mgr2.config.client_id == "client-abc-123"


def test_config_validation_rules():
    with tempfile.TemporaryDirectory() as tmpdir:
        secrets_file = Path(tmpdir) / "walmart_api.json"
        mgr = WalmartApiManager(secrets_path=secrets_file)

        # OPD requires consumer_id, client_id, client_secret
        with pytest.raises(ValueError, match="Consumer ID"):
            mgr.save_config({
                "integration_type": "opd_retail",
                "client_id": "abc",
                "client_secret": "xyz",
            })

        with pytest.raises(ValueError, match="Client ID"):
            mgr.save_config({
                "integration_type": "opd_retail",
                "consumer_id": "cid",
                "client_secret": "xyz",
            })

        # Marketplace requires client_id, client_secret (consumer_id optional)
        m_cfg = mgr.save_config({
            "integration_type": "marketplace",
            "environment": "sandbox",
            "client_id": "m_client",
            "client_secret": "m_secret",
        })
        assert m_cfg.is_configured()
        assert m_cfg.integration_type == "marketplace"
        assert m_cfg.environment == "sandbox"


def test_clear_credentials():
    with tempfile.TemporaryDirectory() as tmpdir:
        secrets_file = Path(tmpdir) / "walmart_api.json"
        mgr = WalmartApiManager(secrets_path=secrets_file)

        mgr.save_config({
            "integration_type": "opd_retail",
            "consumer_id": "cid",
            "client_id": "cid2",
            "client_secret": "sec",
        })
        assert secrets_file.exists()
        assert mgr.config.is_configured()

        mgr.clear_config()
        assert not secrets_file.exists()
        assert not mgr.config.is_configured()
        assert mgr.config.status == WalmartApiStatus.NOT_CONFIGURED


def test_token_caching():
    async def _run():
        with tempfile.TemporaryDirectory() as tmpdir:
            secrets_file = Path(tmpdir) / "walmart_api.json"
            mgr = WalmartApiManager(secrets_path=secrets_file)
            mgr.save_config({
                "integration_type": "marketplace",
                "client_id": "m_id",
                "client_secret": "m_sec",
            })

            mock_resp = AsyncMock()
            mock_resp.status = 200
            mock_resp.text.return_value = json.dumps({"access_token": "token_12345", "expires_in": 900})

            session_mock = MagicMock()
            session_mock.post.return_value.__aenter__.return_value = mock_resp

            token1 = await mgr.get_access_token(session_mock)
            assert token1 == "token_12345"
            assert session_mock.post.call_count == 1

            # Second call should use in-memory cached token without hitting post again
            token2 = await mgr.get_access_token(session_mock)
            assert token2 == "token_12345"
            assert session_mock.post.call_count == 1

    asyncio.run(_run())


def test_connection_test_invalid_credentials_401():
    async def _run():
        with tempfile.TemporaryDirectory() as tmpdir:
            secrets_file = Path(tmpdir) / "walmart_api.json"
            mgr = WalmartApiManager(secrets_path=secrets_file)
            mgr.save_config({
                "integration_type": "opd_retail",
                "consumer_id": "cid",
                "client_id": "invalid_id",
                "client_secret": "invalid_secret",
            })

            mock_resp = AsyncMock()
            mock_resp.status = 401
            mock_resp.text.return_value = json.dumps({"error": "unauthorized"})
            mock_resp.request_info = MagicMock()
            mock_resp.history = ()

            with patch("aiohttp.ClientSession.post") as mock_post:
                mock_post.return_value.__aenter__.return_value = mock_resp
                res = await mgr.test_connection(zipcode="10001")

                assert res["status"] == WalmartApiStatus.INVALID_CREDENTIALS.value
                assert "HTTP 401" in res["last_test_message"]
                assert not res["is_connected"]

    asyncio.run(_run())


def test_connection_test_access_denied_token_succeeds_but_endpoint_403():
    """Verify that token success alone does NOT mark connection ready if store endpoint is 403."""
    async def _run():
        with tempfile.TemporaryDirectory() as tmpdir:
            secrets_file = Path(tmpdir) / "walmart_api.json"
            mgr = WalmartApiManager(secrets_path=secrets_file)
            mgr.save_config({
                "integration_type": "opd_retail",
                "consumer_id": "cid",
                "client_id": "valid_id",
                "client_secret": "valid_secret",
            })

            # Mock token response (200 OK)
            token_resp = AsyncMock()
            token_resp.status = 200
            token_resp.text.return_value = json.dumps({"access_token": "bearer_token", "expires_in": 900})

            # Mock store response (403 Forbidden - no catalog permission)
            store_resp = AsyncMock()
            store_resp.status = 403
            store_resp.text.return_value = json.dumps({"error": "Forbidden: account lacks retail catalog entitlement"})

            with patch("aiohttp.ClientSession.post") as mock_post, patch("aiohttp.ClientSession.get") as mock_get:
                mock_post.return_value.__aenter__.return_value = token_resp
                mock_get.return_value.__aenter__.return_value = store_resp

                res = await mgr.test_connection(zipcode="10001")

                # Must distinguish token success from endpoint 403
                assert res["status"] == WalmartApiStatus.ACCESS_DENIED.value
                assert "HTTP 403 Forbidden" in res["last_test_message"]
                assert "oauth2_token_exchange" in res["verified_endpoints"]
                assert "store_locator_v1" not in res["verified_endpoints"]
                assert not res["is_connected"]

    asyncio.run(_run())


def test_connection_test_full_success():
    async def _run():
        with tempfile.TemporaryDirectory() as tmpdir:
            secrets_file = Path(tmpdir) / "walmart_api.json"
            mgr = WalmartApiManager(secrets_path=secrets_file)
            mgr.save_config({
                "integration_type": "opd_retail",
                "consumer_id": "cid",
                "client_id": "valid_id",
                "client_secret": "valid_secret",
            })

            token_resp = AsyncMock()
            token_resp.status = 200
            token_resp.text.return_value = json.dumps({"access_token": "token_ok", "expires_in": 900})

            store_resp = AsyncMock()
            store_resp.status = 200
            store_resp.text.return_value = json.dumps([{"name": "Walmart Supercenter #1234", "streetAddress": "100 Main St"}])

            with patch("aiohttp.ClientSession.post") as mock_post, patch("aiohttp.ClientSession.get") as mock_get:
                mock_post.return_value.__aenter__.return_value = token_resp
                mock_get.return_value.__aenter__.return_value = store_resp

                res = await mgr.test_connection(zipcode="10001")

                assert res["status"] == WalmartApiStatus.CONNECTED.value
                assert "Connected!" in res["last_test_message"]
                assert "oauth2_token_exchange" in res["verified_endpoints"]
                assert "store_locator_v1" in res["verified_endpoints"]
                assert res["is_connected"] is True

    asyncio.run(_run())
