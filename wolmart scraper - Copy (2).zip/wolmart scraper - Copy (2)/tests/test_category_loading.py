"""
tests/test_category_loading.py — Regression tests for category URL loading in walmart/config.py
"""
import pytest
from pathlib import Path
from walmart.config import load_category_urls, CategoryEntry


def test_load_valid_csv_comma(tmp_path):
    csv_file = tmp_path / "valid.csv"
    csv_file.write_text(
        "category,sub_category,url\n"
        "Grocery,Snacks,https://www.walmart.com/browse/snacks\n"
        "Grocery,Beverages,https://www.walmart.com/browse/beverages\n",
        encoding="utf-8"
    )
    entries = load_category_urls(csv_file)
    assert len(entries) == 2
    assert entries[0] == CategoryEntry("Grocery", "Snacks", "https://www.walmart.com/browse/snacks")
    assert entries[1] == CategoryEntry("Grocery", "Beverages", "https://www.walmart.com/browse/beverages")


def test_load_valid_csv_semicolon(tmp_path):
    csv_file = tmp_path / "valid_semi.csv"
    csv_file.write_text(
        "category;sub_category;url\n"
        "Grocery;Dairy & Eggs;https://www.walmart.com/browse/dairy\n",
        encoding="utf-8"
    )
    entries = load_category_urls(csv_file)
    assert len(entries) == 1
    assert entries[0].sub_category == "Dairy & Eggs"


def test_missing_file_raises_error():
    with pytest.raises(FileNotFoundError):
        load_category_urls("non_existent_category_file_12345.csv")


def test_empty_file_raises_value_error(tmp_path):
    empty_file = tmp_path / "empty.csv"
    empty_file.write_text("", encoding="utf-8")
    with pytest.raises(ValueError, match="CSV file is empty"):
        load_category_urls(empty_file)


def test_header_only_raises_value_error(tmp_path):
    header_file = tmp_path / "header_only.csv"
    header_file.write_text("category,sub_category,url\n", encoding="utf-8")
    with pytest.raises(ValueError, match="No valid category entries"):
        load_category_urls(header_file)


def test_missing_required_column_raises_value_error(tmp_path):
    bad_file = tmp_path / "bad_columns.csv"
    bad_file.write_text("cat,sub_cat,link\nGrocery,Snacks,https://example.com\n", encoding="utf-8")
    with pytest.raises(ValueError, match="missing required columns"):
        load_category_urls(bad_file)


def test_malformed_and_blank_rows_skipped(tmp_path):
    mixed_file = tmp_path / "mixed.csv"
    mixed_file.write_text(
        "category,sub_category,url\n"
        "Grocery,Snacks,https://www.walmart.com/browse/snacks\n"
        ",,,\n"
        "Grocery,NoUrl,\n"
        ",NoCategory,https://www.walmart.com/browse/missing-cat\n"
        "Grocery,,https://www.walmart.com/browse/missing-subcat\n"
        "Grocery,Beverages,https://www.walmart.com/browse/beverages\n",
        encoding="utf-8"
    )
    entries = load_category_urls(mixed_file)
    assert len(entries) == 2
    assert entries[0].sub_category == "Snacks"
    assert entries[1].sub_category == "Beverages"
