"""tests/test_store.py — Tests for core/store.py"""
import json
import pytest
import tempfile
import os
from pathlib import Path

from core.store import StoreDB


@pytest.fixture
def db(tmp_path):
    """Return a fresh StoreDB backed by a temp file."""
    return StoreDB(tmp_path / "test.db")


def _sample_record(**overrides) -> dict:
    base = {
        "zipcode": "10001",
        "store_name": "Walmart Supercenter",
        "store_location": "123 Main St",
        "store_logo": "",
        "store_brand": "",
        "category": "Grocery",
        "sub_category": "Snacks",
        "product_title": "Great Value Chips 8oz",
        "weight": "8 oz",
        "regular_price": "$2.98",
        "sale_price": "",
        "volume_deals_description": "",
        "volume_deals_price": "",
        "digital_deals_description": "",
        "digital_deals_price": "",
        "image_url": "https://example.com/img.jpg",
        "url": "https://www.walmart.com/ip/chips/111111",
        "upc": "012345678901",
        "gupc": "",
        "ppm": "$0.37/oz",
        "unit_price": "",
        "crawl_date": "2024-01-01",
    }
    base.update(overrides)
    return base


class TestBeginAndFinishRun:
    def test_begin_run_creates_record(self, db):
        db.begin_run("run001", "live", "10001", "Walmart")
        row = db._conn.execute(
            "SELECT * FROM runs WHERE run_id=?", ("run001",)
        ).fetchone()
        assert row is not None
        assert row["status"] == "running"
        assert row["mode"] == "live"

    def test_finish_run_updates_status(self, db):
        db.begin_run("run001", "live")
        db.finish_run("run001", status="done")
        row = db._conn.execute(
            "SELECT status FROM runs WHERE run_id=?", ("run001",)
        ).fetchone()
        assert row["status"] == "done"

    def test_finish_run_failed(self, db):
        db.begin_run("run002", "live")
        db.finish_run("run002", status="failed")
        row = db._conn.execute(
            "SELECT status FROM runs WHERE run_id=?", ("run002",)
        ).fetchone()
        assert row["status"] == "failed"

    def test_begin_run_idempotent(self, db):
        db.begin_run("run001", "live")
        db.begin_run("run001", "live")  # Second call should not error
        rows = db._conn.execute("SELECT COUNT(*) as n FROM runs").fetchone()
        assert rows["n"] == 1


class TestUpsertProduct:
    def test_insert_new_product(self, db):
        db.begin_run("run001", "live")
        record = _sample_record()
        key = db._product_key(record)
        db.upsert_product(key, "run001", record)

        row = db._conn.execute(
            "SELECT * FROM products WHERE product_key=?", (key,)
        ).fetchone()
        assert row is not None
        assert row["seen_in_last_run"] == 1
        assert row["last_seen_run_id"] == "run001"

    def test_upsert_updates_existing(self, db):
        db.begin_run("run001", "live")
        record = _sample_record()
        key = db._product_key(record)
        db.upsert_product(key, "run001", record)

        # Update with new price
        record2 = _sample_record(regular_price="$3.48")
        db.upsert_product(key, "run001", record2)

        row = db._conn.execute(
            "SELECT data_json FROM products WHERE product_key=?", (key,)
        ).fetchone()
        data = json.loads(row["data_json"])
        assert data["regular_price"] == "$3.48"

    def test_seen_in_last_run_set_to_1_on_upsert(self, db):
        db.begin_run("run001", "live")
        record = _sample_record()
        key = db._product_key(record)
        db.upsert_product(key, "run001", record)

        row = db._conn.execute(
            "SELECT seen_in_last_run FROM products WHERE product_key=?", (key,)
        ).fetchone()
        assert row["seen_in_last_run"] == 1


class TestMarkUnseen:
    def test_products_from_prior_run_marked_unseen(self, db):
        db.begin_run("run001", "live")
        rec1 = _sample_record(url="https://www.walmart.com/ip/a/1")
        rec2 = _sample_record(url="https://www.walmart.com/ip/b/2")
        k1 = db._product_key(rec1)
        k2 = db._product_key(rec2)
        db.upsert_product(k1, "run001", rec1)
        db.upsert_product(k2, "run001", rec2)

        # Start run002, only upsert rec1
        db.begin_run("run002", "live")
        db.upsert_product(k1, "run002", rec1)
        db.mark_unseen("run002")

        row1 = db._conn.execute(
            "SELECT seen_in_last_run FROM products WHERE product_key=?", (k1,)
        ).fetchone()
        row2 = db._conn.execute(
            "SELECT seen_in_last_run FROM products WHERE product_key=?", (k2,)
        ).fetchone()
        assert row1["seen_in_last_run"] == 1
        assert row2["seen_in_last_run"] == 0

    def test_products_never_deleted(self, db):
        db.begin_run("run001", "live")
        record = _sample_record()
        key = db._product_key(record)
        db.upsert_product(key, "run001", record)

        db.begin_run("run002", "live")
        # Don't upsert anything in run002
        db.mark_unseen("run002")

        # Product still exists
        count = db._conn.execute(
            "SELECT COUNT(*) as n FROM products WHERE product_key=?", (key,)
        ).fetchone()["n"]
        assert count == 1


class TestExportJson:
    def test_export_returns_22_field_dicts(self, db):
        db.begin_run("run001", "live")
        record = _sample_record()
        key = db._product_key(record)
        db.upsert_product(key, "run001", record)

        results = db.export_json("run001")
        assert len(results) == 1
        assert len(results[0]) == 22

    def test_export_includes_carried_forward(self, db):
        db.begin_run("run001", "live")
        rec1 = _sample_record(url="https://www.walmart.com/ip/a/1")
        rec2 = _sample_record(url="https://www.walmart.com/ip/b/2")
        k1 = db._product_key(rec1)
        k2 = db._product_key(rec2)
        db.upsert_product(k1, "run001", rec1)
        db.upsert_product(k2, "run001", rec2)

        # Run002 only sees rec1
        db.begin_run("run002", "live")
        db.upsert_product(k1, "run002", rec1)
        db.mark_unseen("run002")

        results = db.export_json("run002")
        assert len(results) == 2  # Both products returned


class TestExportAuditLog:
    def test_audit_log_fields(self, db):
        db.begin_run("run001", "live")
        record = _sample_record()
        key = db._product_key(record)
        db.upsert_product(key, "run001", record)

        audit = db.export_audit_log("run001")
        assert len(audit) == 1
        entry = audit[0]
        assert "product_key" in entry
        assert "seen_in_last_run" in entry
        assert "last_seen_run_id" in entry
        assert "updated_at" in entry


class TestProductKey:
    def test_key_derived_from_url(self, db):
        record = _sample_record(url="https://www.walmart.com/ip/chips/111111")
        key = db._product_key(record)
        assert "walmart.com" in key or "111111" in key

    def test_key_derived_from_upc_when_no_url(self, db):
        record = _sample_record(url="", upc="012345678901")
        key = db._product_key(record)
        assert "012345678901" in key

    def test_stable_key_strips_query_params(self, db):
        rec1 = _sample_record(url="https://www.walmart.com/ip/chips/111?ref=foo")
        rec2 = _sample_record(url="https://www.walmart.com/ip/chips/111?ref=bar")
        k1 = db._product_key(rec1)
        k2 = db._product_key(rec2)
        assert k1 == k2
