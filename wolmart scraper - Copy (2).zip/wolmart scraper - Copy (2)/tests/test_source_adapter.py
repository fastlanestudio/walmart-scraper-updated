"""tests/test_source_adapter.py — Tests for data source adapters."""
import asyncio
import pytest
from core.source_adapter import (
    TestFixtureAdapter,
    LivePlaywrightAdapter,
    WalmartApiAdapter,
)


def test_fixture_adapter_generates_valid_records():
    async def _run():
        adapter = TestFixtureAdapter()
        status = await adapter.check_readiness({})
        assert status.status == "ready"
        assert not status.supports_live

        records = await adapter.collect({"target_count": 20, "zipcode": "10001"})
        assert len(records) == 20
        for r in records:
            assert r.validate() == []
            assert r.zipcode == "10001"
            assert r.product_title
            assert r.url

    asyncio.run(_run())


def test_fixture_adapter_respects_cancellation():
    async def _run():
        adapter = TestFixtureAdapter()
        token = {"cancelled": True}
        records = await adapter.collect({"target_count": 50}, cancel_token=token)
        assert len(records) == 0

    asyncio.run(_run())


def test_live_adapter_reports_blocked_without_proxy():
    async def _run():
        adapter = LivePlaywrightAdapter()
        status = await adapter.check_readiness({})
        assert status.status == "blocked"
        assert "PerimeterX" in status.message or "proxy" in status.message.lower()

    asyncio.run(_run())


def test_api_adapter_reports_missing_credentials(monkeypatch):
    async def _run():
        monkeypatch.delenv("WALMART_API_KEY", raising=False)
        monkeypatch.delenv("WALMART_CONSUMER_ID", raising=False)
        adapter = WalmartApiAdapter()
        status = await adapter.check_readiness({})
        assert status.status == "not_configured"
        assert "WALMART_API_KEY" in status.message

    asyncio.run(_run())
