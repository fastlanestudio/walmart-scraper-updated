"""tests/test_location_and_niche.py
Unit tests for geolocation store resolution and dynamic niche search engine.
"""
import pytest
from core.location import (
    resolve_walmart_store,
    build_walmart_location_cookies,
    build_walmart_cookie_header,
)
from core.niche_search import (
    resolve_search_target,
    parse_url_categories,
    NICHE_TAXONOMY,
)


def test_resolve_known_zipcode_secaucus():
    store = resolve_walmart_store("10001")
    assert store["is_store_verified"] is True
    assert store["store_id"] == "2570"
    assert "Secaucus" in store["store_name"]
    assert store["zipcode"] == "10001"
    assert store["fulfillment_type"] == "in_store"


def test_resolve_invalid_zipcode_leaves_store_empty():
    store = resolve_walmart_store("99999")
    assert store["is_store_verified"] is False
    assert store["store_name"] == ""
    assert store["store_location"] == ""
    assert store["store_id"] == ""
    assert store["fulfillment_type"] == "unverified"

    # Non-digit ZIP
    store_bad = resolve_walmart_store("abcde")
    assert store_bad["is_store_verified"] is False
    assert store_bad["store_name"] == ""


def test_location_cookies_and_header_generation():
    store = resolve_walmart_store("10001")
    cookies = build_walmart_location_cookies(store)
    assert len(cookies) == 3
    names = {c["name"] for c in cookies}
    assert "hasLocData" in names
    assert "wm_postal_code" in names
    assert "locationData" in names

    header_str = build_walmart_cookie_header(store)
    assert "hasLocData=1" in header_str
    assert "wm_postal_code=10001" in header_str
    assert "locationData=" in header_str


def test_niche_search_keyword_resolution():
    res = resolve_search_target("organic protein bars")
    assert res["target_type"] == "niche_keyword"
    assert "snacks-cookies-chips" in res["url"]
    assert res["category"] == "Grocery"
    assert res["sub_category"] == "Snacks"

    res_mouse = resolve_search_target("wireless gaming mice")
    assert res_mouse["target_type"] == "niche_keyword"
    assert res_mouse["category"] == "Electronics"
    assert "computer-accessories" in res_mouse["url"]

    res_chips = resolve_search_target("tortilla chips and snacks")
    assert res_chips["target_type"] == "niche_keyword"
    assert res_chips["category"] == "Grocery"
    assert "snacks-cookies-chips" in res_chips["url"]


def test_niche_search_url_resolution():
    url = "https://www.walmart.com/browse/food/beverages/976759_976782"
    res = resolve_search_target(url)
    assert res["target_type"] == "url"
    assert res["url"] == url
    assert res["category"] == "Food"
    assert res["sub_category"] == "Beverages"


def test_niche_search_arbitrary_query():
    res = resolve_search_target("quantum thermodynamics textbook volume 3")
    assert res["target_type"] == "search_query"
    assert "/search?q=" in res["url"]
