"""tests/test_schema_parity.py
Regression tests for client 22-field schema order, delimiter compliance, and JSON/CSV parity.
"""
import io
import csv
import json
import pytest

from core.schema import ProductRecord, FIELD_NAMES
from core.store import StoreDB

EXPECTED_22_FIELDS = [
    "zipcode",
    "store_name",
    "store_location",
    "store_logo",
    "store_brand",
    "category",
    "sub_category",
    "product_title",
    "weight",
    "regular_price",
    "sale_price",
    "volume_deals_description",
    "volume_deals_price",
    "digital_deals_description",
    "digital_deals_price",
    "image_url",
    "url",
    "upc",
    "gupc",
    "ppm",
    "unit_price",
    "crawl_date",
]


def test_field_names_exact_22_order():
    assert len(FIELD_NAMES) == 22
    assert FIELD_NAMES == EXPECTED_22_FIELDS


def test_product_record_defaults_and_order():
    rec = ProductRecord(
        zipcode="72712",
        store_name="Walmart Store",
        store_location="Bentonville, AR",
        store_logo="",
        store_brand="Great Value",
        category="Grocery",
        sub_category="Pantry",
        product_title="Organic Oats",
        weight="16 oz",
        regular_price="$2.48",
        sale_price="",
        volume_deals_description="",
        volume_deals_price="",
        digital_deals_description="",
        digital_deals_price="",
        image_url="https://img.walmart.com/oats.jpg",
        url="https://walmart.com/ip/oats/101",
        upc="078742123456",
        gupc="",
        ppm="$0.16/oz",
        unit_price="",
        crawl_date="2026-10-27",
    )

    d = rec.to_dict()
    assert list(d.keys()) == EXPECTED_22_FIELDS
    assert d["gupc"] == ""
    assert d["unit_price"] == ""
    assert d["ppm"] == "$0.16/oz"


def test_csv_semicolon_delimiter_and_header_parity(tmp_path):
    db_file = tmp_path / "schema_test.db"
    db = StoreDB(str(db_file))

    p = {
        "zipcode": "10001", "store_name": "Store #1", "store_location": "New York",
        "store_logo": "", "store_brand": "Brand X", "category": "Dairy", "sub_category": "Cheese",
        "product_title": "Cheddar Cheese", "weight": "8 oz", "regular_price": "$3.98",
        "sale_price": "$3.50", "volume_deals_description": "", "volume_deals_price": "",
        "digital_deals_description": "Save $0.50", "digital_deals_price": "",
        "image_url": "https://img.walmart.com/cheese.jpg", "url": "https://walmart.com/ip/cheese/500",
        "upc": "012345678910", "gupc": "", "ppm": "$0.50/oz", "unit_price": "", "crawl_date": "2026-10-27"
    }

    db.begin_run("run_parity_1", "10001")
    db.stage_product(db._product_key(p), "run_parity_1", p, is_test=0)
    db.publish_run("run_parity_1")

    # CSV export
    csv_text = db.export_csv(is_test=0)
    lines = [line.strip() for line in csv_text.strip().splitlines() if line.strip()]
    assert len(lines) == 2  # header + 1 record

    header_cols = lines[0].split(";")
    assert header_cols == EXPECTED_22_FIELDS

    data_cols = lines[1].split(";")
    assert len(data_cols) == 22
    assert data_cols[0] == "10001"
    assert data_cols[7] == "Cheddar Cheese"
    assert data_cols[17] == "012345678910"
    assert data_cols[18] == ""  # gupc
    assert data_cols[19] == "$0.50/oz"  # ppm
    assert data_cols[20] == ""  # unit_price

    # JSON export
    json_records = db.export_json(is_test=0)
    assert len(json_records) == 1
    assert list(json_records[0].keys()) == EXPECTED_22_FIELDS

    # No internal bookkeeping fields leak
    for forbidden in ["product_key", "seen_in_last_run", "last_seen_run_id", "is_test", "data_source", "created_at", "updated_at"]:
        assert forbidden not in header_cols
        assert forbidden not in json_records[0]
