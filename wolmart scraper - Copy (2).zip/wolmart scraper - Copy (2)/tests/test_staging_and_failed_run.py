"""tests/test_staging_and_failed_run.py
Regression tests ensuring failed crawls never corrupt accepted products.
"""
import io
import csv
import pytest
from core.store import StoreDB, FIELD_NAMES


@pytest.fixture
def test_db(tmp_path):
    db_file = tmp_path / "test_walmart.db"
    return StoreDB(str(db_file))


def test_failed_run_does_not_overwrite_accepted_products(test_db):
    # 1. Successful baseline run 1 publishes product at $3.00
    run1 = "run_baseline_001"
    test_db.begin_run(run1, "10001")
    prod_data_good = {
        "zipcode": "10001",
        "store_name": "Walmart Supercenter",
        "store_location": "Secaucus, NJ",
        "store_logo": "",
        "store_brand": "Great Value",
        "category": "Grocery",
        "sub_category": "Snacks",
        "product_title": "Great Value Potato Chips",
        "weight": "8 oz",
        "regular_price": "$3.00",
        "sale_price": "",
        "volume_deals_description": "",
        "volume_deals_price": "",
        "digital_deals_description": "",
        "digital_deals_price": "",
        "image_url": "https://walmart.com/img/chips.jpg",
        "url": "https://walmart.com/ip/chips/12345",
        "upc": "078742123456",
        "gupc": "",
        "ppm": "$0.38/oz",
        "unit_price": "",
        "crawl_date": "2026-10-25",
    }
    p_key = test_db._product_key(prod_data_good)
    test_db.stage_product(p_key, run1, prod_data_good, is_test=0, data_source="live")
    test_db.publish_run(run1)

    # Verify baseline in accepted products
    row = test_db.get_product(p_key)
    assert row is not None
    assert row["regular_price"] == "$3.00"
    assert row["seen_in_last_run"] == 1

    # 2. Corrupt/failed run 2 stages an erroneous price ($99.00)
    run2 = "run_corrupt_002"
    test_db.begin_run(run2, "10001")
    prod_data_bad = dict(prod_data_good)
    prod_data_bad["regular_price"] = "$99.00"
    prod_data_bad["crawl_date"] = "2026-10-26"

    test_db.stage_product(p_key, run2, prod_data_bad, is_test=0, data_source="live")

    # Run 2 fails (e.g. timeout / network block)
    test_db.finish_run(run2, status="failed", error_message="Anti-bot blocked halfway")
    test_db.discard_staged_run(run2)

    # 3. Verify accepted products still has $3.00, NOT $99.00
    row_after = test_db.get_product(p_key)
    assert row_after is not None
    assert row_after["regular_price"] == "$3.00"

    # Verify export retains $3.00
    csv_out = test_db.export_csv(is_test=0)
    reader = csv.DictReader(io.StringIO(csv_out), delimiter=";")
    rows = list(reader)
    assert len(rows) == 1
    assert rows[0]["regular_price"] == "$3.00"


def test_atomic_publish_and_carried_forward(test_db):
    run1 = "run_atomic_001"
    test_db.begin_run(run1, "10001")

    p1 = {
        "zipcode": "10001", "store_name": "Store 1", "store_location": "Loc 1",
        "store_logo": "", "store_brand": "Brand A", "category": "Cat 1", "sub_category": "Sub 1",
        "product_title": "Product One", "weight": "10 oz", "regular_price": "$1.50", "sale_price": "",
        "volume_deals_description": "", "volume_deals_price": "",
        "digital_deals_description": "", "digital_deals_price": "",
        "image_url": "https://img/1.jpg", "url": "https://walmart.com/ip/1",
        "upc": "012345678901", "gupc": "", "ppm": "", "unit_price": "", "crawl_date": "2026-10-25"
    }
    p2 = {
        "zipcode": "10001", "store_name": "Store 1", "store_location": "Loc 1",
        "store_logo": "", "store_brand": "Brand B", "category": "Cat 1", "sub_category": "Sub 1",
        "product_title": "Product Two", "weight": "20 oz", "regular_price": "$2.50", "sale_price": "",
        "volume_deals_description": "", "volume_deals_price": "",
        "digital_deals_description": "", "digital_deals_price": "",
        "image_url": "https://img/2.jpg", "url": "https://walmart.com/ip/2",
        "upc": "012345678902", "gupc": "", "ppm": "", "unit_price": "", "crawl_date": "2026-10-25"
    }

    test_db.stage_product(test_db._product_key(p1), run1, p1, is_test=0)
    test_db.stage_product(test_db._product_key(p2), run1, p2, is_test=0)
    test_db.publish_run(run1)

    counts = test_db.get_stats()
    assert counts["total_records"] == 2
    assert counts["live_records"] == 2
    assert counts["carried_forward"] == 0

    # Run 2 only observes Product One
    run2 = "run_atomic_002"
    test_db.begin_run(run2, "10001")
    p1_update = dict(p1)
    p1_update["regular_price"] = "$1.75"
    test_db.stage_product(test_db._product_key(p1_update), run2, p1_update, is_test=0)
    test_db.publish_run(run2)

    counts2 = test_db.get_stats()
    assert counts2["total_records"] == 2
    assert counts2["carried_forward"] == 1  # p2 was retained as carried-forward

    p1_row = test_db.get_product(test_db._product_key(p1))
    p2_row = test_db.get_product(test_db._product_key(p2))
    assert p1_row["regular_price"] == "$1.75"
    assert p1_row["seen_in_last_run"] == 1
    assert p2_row["regular_price"] == "$2.50"
    assert p2_row["seen_in_last_run"] == 0
