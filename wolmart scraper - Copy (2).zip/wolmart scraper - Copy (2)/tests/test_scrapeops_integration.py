"""
tests/test_scrapeops_integration.py
Tests for ScrapeOps-aligned crawler and product scraper architecture.
"""
import json
import os
import pytest
from unittest.mock import patch, MagicMock, AsyncMock

from walmart_crawler import (
    get_scrapeops_api_key,
    build_search_url,
    build_category_url,
    extract_product_urls_from_html,
    crawl_walmart,
)
from walmart.scraper import WalmartScraper


def test_get_scrapeops_api_key():
    """Verify ScrapeOps API key is extracted from CLI or env."""
    assert get_scrapeops_api_key("cli_test_key_123") == "cli_test_key_123"

    with patch.dict(os.environ, {"SCRAPEOPS_API_KEY": "env_test_key_456"}):
        assert get_scrapeops_api_key() == "env_test_key_456"


def test_build_search_and_category_urls():
    """Verify URL generation matches Walmart routing conventions."""
    search_url = build_search_url("cookies", page=2)
    assert search_url == "https://www.walmart.com/search?q=cookies&page=2"

    cat_url = build_category_url("https://www.walmart.com/browse/food/976759", page=3)
    assert cat_url == "https://www.walmart.com/browse/food/976759?page=3"


def test_extract_product_urls_filters_sponsored_track_urls():
    """Verify /sp/track sponsored ads are rejected and clean /ip/ URLs are preserved."""
    html_fixture = """
    <html><body>
      <a href="https://www.walmart.com/sp/track?rd=https%3A%2F%2Fwww.walmart.com%2Fip%2Fitem-sponsored%2F111">Sponsored</a>
      <a href="/ip/Great-Value-Milk/222">Clean Product 1</a>
      <a href="/ip/Oreo-Cookies/333?variant=12">Clean Product 2</a>
    </body></html>
    """
    urls = extract_product_urls_from_html(html_fixture)
    assert len(urls) == 2
    assert "https://www.walmart.com/ip/Great-Value-Milk/222" in urls
    assert "https://www.walmart.com/ip/Oreo-Cookies/333" in urls
    assert not any("/sp/" in u for u in urls)


def test_walmart_scraper_picks_up_scrapeops_env():
    """Verify WalmartScraper automatically sets ScrapeOps residential proxy when SCRAPEOPS_API_KEY is present."""
    with patch.dict(os.environ, {"SCRAPEOPS_API_KEY": "test_scrapeops_secret"}, clear=True):
        scraper = WalmartScraper(mode="simulated")
        slot = scraper.proxy_pool.slots[0]
        assert slot.proxy_url == "http://scrapeops:test_scrapeops_secret@residential-proxy.scrapeops.io:8181"


def test_crawler_writes_jsonl_output(tmp_path):
    """Verify crawl_walmart writes discovered URLs to a valid JSONL handoff file."""
    output_jsonl = tmp_path / "test_discovered.jsonl"
    mock_html = """
    <html><body>
      <a href="/ip/Item-A/100">Item A</a>
      <a href="/ip/Item-B/200">Item B</a>
    </body></html>
    """
    with patch("walmart_crawler.fetch_listing_html", return_value=mock_html):
        count = crawl_walmart(
            targets=["https://www.walmart.com/browse/food/test"],
            max_pages=1,
            output_file=str(output_jsonl),
        )

    assert count == 2
    assert output_jsonl.exists()

    with open(output_jsonl, "r", encoding="utf-8") as f:
        lines = [json.loads(line) for line in f]
    assert len(lines) == 2
    assert lines[0]["url"] == "https://www.walmart.com/ip/Item-A/100"
    assert lines[1]["url"] == "https://www.walmart.com/ip/Item-B/200"
