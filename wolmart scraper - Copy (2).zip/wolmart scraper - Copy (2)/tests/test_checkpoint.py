"""tests/test_checkpoint.py — Tests for core/checkpoint.py"""
import json
import pytest
from pathlib import Path

from core.checkpoint import (
    CategoryCheckpoint,
    CategoryStatus,
    RunCheckpoint,
)


def _make_categories() -> list[CategoryCheckpoint]:
    return [
        CategoryCheckpoint("Grocery", "Snacks", "https://walmart.com/browse/snacks"),
        CategoryCheckpoint("Grocery", "Beverages", "https://walmart.com/browse/beverages"),
        CategoryCheckpoint("Electronics", "TVs", "https://walmart.com/browse/tvs"),
    ]


class TestCategoryCheckpoint:
    def test_defaults(self):
        cat = CategoryCheckpoint("Grocery", "Snacks", "https://example.com")
        assert cat.status == CategoryStatus.PENDING
        assert cat.products_scraped == 0
        assert cat.error_message == ""

    def test_to_dict_round_trip(self):
        cat = CategoryCheckpoint(
            "Grocery", "Snacks", "https://example.com",
            status=CategoryStatus.DONE,
            products_scraped=42,
            error_message="",
        )
        d = cat.to_dict()
        cat2 = CategoryCheckpoint.from_dict(d)
        assert cat2.category == cat.category
        assert cat2.sub_category == cat.sub_category
        assert cat2.url == cat.url
        assert cat2.status == cat.status
        assert cat2.products_scraped == cat.products_scraped


class TestRunCheckpointSaveLoad:
    def test_save_and_load(self, tmp_path):
        cp = RunCheckpoint(
            run_id="run001",
            store_zipcode="10001",
            categories=_make_categories(),
        )
        path = tmp_path / "checkpoint.json"
        cp.save(path)
        assert path.exists()

        loaded = RunCheckpoint.load(path)
        assert loaded.run_id == "run001"
        assert loaded.store_zipcode == "10001"
        assert len(loaded.categories) == 3

    def test_save_is_valid_json(self, tmp_path):
        cp = RunCheckpoint("run001", "10001", _make_categories())
        path = tmp_path / "cp.json"
        cp.save(path)
        with open(path) as f:
            data = json.load(f)
        assert data["run_id"] == "run001"

    def test_atomic_write_no_partial_file(self, tmp_path):
        """Verify that save uses write-then-rename (temp file disappears after save)."""
        cp = RunCheckpoint("run001", "10001", _make_categories())
        path = tmp_path / "cp.json"
        cp.save(path)
        # After save, only the final file should exist; no .tmp files
        tmp_files = list(tmp_path.glob("*.tmp"))
        assert tmp_files == []


class TestRunCheckpointLoadOrCreate:
    def test_creates_new_if_no_file(self, tmp_path):
        path = tmp_path / "nonexistent.json"
        cats = _make_categories()
        cp = RunCheckpoint.load_or_create(path, "run001", "10001", cats)
        assert cp.run_id == "run001"
        assert len(cp.categories) == 3

    def test_loads_existing_matching_checkpoint(self, tmp_path):
        cats = _make_categories()
        existing = RunCheckpoint("run001", "10001", cats)
        existing.categories[0].status = CategoryStatus.DONE
        path = tmp_path / "cp.json"
        existing.save(path)

        loaded = RunCheckpoint.load_or_create(path, "run001", "10001", cats)
        # Should load existing (with DONE status preserved)
        assert loaded.categories[0].status == CategoryStatus.DONE

    def test_creates_fresh_if_run_id_mismatch(self, tmp_path):
        cats = _make_categories()
        existing = RunCheckpoint("old_run", "10001", cats)
        existing.categories[0].status = CategoryStatus.DONE
        path = tmp_path / "cp.json"
        existing.save(path)

        fresh = RunCheckpoint.load_or_create(path, "new_run", "10001", cats)
        # Different run_id → fresh checkpoint, all PENDING
        assert fresh.run_id == "new_run"
        assert all(c.status == CategoryStatus.PENDING for c in fresh.categories)

    def test_creates_fresh_if_zipcode_mismatch(self, tmp_path):
        cats = _make_categories()
        existing = RunCheckpoint("run001", "99999", cats)
        path = tmp_path / "cp.json"
        existing.save(path)

        fresh = RunCheckpoint.load_or_create(path, "run001", "10001", cats)
        assert fresh.store_zipcode == "10001"

    def test_handles_corrupt_file_gracefully(self, tmp_path):
        path = tmp_path / "cp.json"
        path.write_text("NOT_VALID_JSON")
        cats = _make_categories()
        cp = RunCheckpoint.load_or_create(path, "run001", "10001", cats)
        assert cp.run_id == "run001"
        assert len(cp.categories) == 3


class TestRunCheckpointMutations:
    def test_pending_categories_returns_pending_and_in_progress(self):
        cats = _make_categories()
        cats[0].status = CategoryStatus.DONE
        cats[1].status = CategoryStatus.IN_PROGRESS
        cp = RunCheckpoint("run001", "10001", cats)
        pending = cp.pending_categories()
        assert len(pending) == 2
        assert any(c.sub_category == "Beverages" for c in pending)
        assert any(c.sub_category == "TVs" for c in pending)

    def test_mark_in_progress(self):
        cats = _make_categories()
        cp = RunCheckpoint("run001", "10001", cats)
        cp.mark_in_progress("Grocery", "Snacks")
        assert cats[0].status == CategoryStatus.IN_PROGRESS

    def test_mark_done(self):
        cats = _make_categories()
        cp = RunCheckpoint("run001", "10001", cats)
        cp.mark_done("Grocery", "Snacks", 42)
        assert cats[0].status == CategoryStatus.DONE
        assert cats[0].products_scraped == 42

    def test_mark_failed(self):
        cats = _make_categories()
        cp = RunCheckpoint("run001", "10001", cats)
        cp.mark_failed("Grocery", "Beverages", "TimeoutError")
        assert cats[1].status == CategoryStatus.FAILED
        assert cats[1].error_message == "TimeoutError"

    def test_pending_categories_excludes_done_and_failed(self):
        cats = _make_categories()
        cats[0].status = CategoryStatus.DONE
        cats[1].status = CategoryStatus.FAILED
        cp = RunCheckpoint("run001", "10001", cats)
        pending = cp.pending_categories()
        assert len(pending) == 1
        assert pending[0].sub_category == "TVs"

    def test_save_preserves_mutations(self, tmp_path):
        cats = _make_categories()
        cp = RunCheckpoint("run001", "10001", cats)
        cp.mark_done("Grocery", "Snacks", 15)
        path = tmp_path / "cp.json"
        cp.save(path)

        loaded = RunCheckpoint.load(path)
        done = [c for c in loaded.categories if c.status == CategoryStatus.DONE]
        assert len(done) == 1
        assert done[0].products_scraped == 15
