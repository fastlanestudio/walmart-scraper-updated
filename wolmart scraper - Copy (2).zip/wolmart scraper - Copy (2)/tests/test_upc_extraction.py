"""
tests/test_upc_extraction.py — Regression tests for UPC/GTIN extraction.
Verifies genuine barcode mapping, leading-zero preservation, and rejection of SKU/MPN fallbacks.
"""
import pytest
from core.schema import extract_upc_from_data


def test_extract_gtin12():
    data = {"gtin12": "012345678905"}
    upc, src = extract_upc_from_data(data)
    assert upc == "012345678905"
    assert src == "gtin12"


def test_extract_upc_direct():
    data = {"upc": "041196910759"}
    upc, src = extract_upc_from_data(data)
    assert upc == "041196910759"
    assert src == "upc"


def test_preserve_leading_zeros():
    # Identifiers must remain strings and keep leading zeros
    data = {"gtin12": "001234567890"}
    upc, src = extract_upc_from_data(data)
    assert upc == "001234567890"
    assert isinstance(upc, str)
    assert upc.startswith("00")


def test_extract_gtin13_and_gtin14():
    data13 = {"gtin13": "0012345678905"}
    upc, src = extract_upc_from_data(data13)
    assert upc == "0012345678905"
    assert src == "gtin13"

    data14 = {"gtin14": "10012345678902"}
    upc14, src14 = extract_upc_from_data(data14)
    assert upc14 == "10012345678902"
    assert src14 == "gtin14"


def test_reject_sku_only():
    # Client requirement: SKU must NEVER be used as a UPC fallback
    data = {"sku": "12345678"}
    upc, src = extract_upc_from_data(data)
    assert upc == ""
    assert src == ""


def test_reject_mpn_only():
    # Client requirement: MPN must NEVER be used as a UPC fallback
    data = {"mpn": "PART-998877"}
    upc, src = extract_upc_from_data(data)
    assert upc == ""
    assert src == ""


def test_reject_sku_and_mpn_without_barcode():
    data = {"sku": "987654321", "mpn": "ABC-123", "name": "Item Name"}
    upc, src = extract_upc_from_data(data)
    assert upc == ""


def test_missing_and_empty_barcode():
    assert extract_upc_from_data({}) == ("", "")
    assert extract_upc_from_data({"gtin12": ""}) == ("", "")
    assert extract_upc_from_data({"gtin12": None}) == ("", "")


def test_malformed_identifier_rejected():
    # Non-digit or wrong length strings should be rejected
    assert extract_upc_from_data({"gtin12": "ABC123456789"}) == ("", "")
    assert extract_upc_from_data({"gtin12": "12345"}) == ("", "")
    assert extract_upc_from_data({"gtin12": "12345678901234567890"}) == ("", "")
