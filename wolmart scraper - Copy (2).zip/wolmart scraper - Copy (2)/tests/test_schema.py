"""tests/test_schema.py — Tests for core/schema.py"""
import pytest
import datetime
from collections import OrderedDict

from core.schema import (
    ProductRecord,
    is_approx_weight,
    validate_batch,
    APPROX_WEIGHT_PATTERN,
)

TODAY = datetime.date.today().isoformat()


def _valid_record(**overrides) -> ProductRecord:
    """Return a minimal valid ProductRecord."""
    defaults = dict(
        zipcode="10001",
        store_name="Walmart Supercenter",
        store_location="123 Main St",
        store_logo="",
        store_brand="",
        category="Grocery",
        sub_category="Snacks",
        product_title="Great Value Potato Chips 8oz",
        weight="8 oz",
        regular_price="$2.98",
        sale_price="",
        volume_deals_description="",
        volume_deals_price="",
        digital_deals_description="",
        digital_deals_price="",
        image_url="https://i5.walmartimages.com/image.jpg",
        url="https://www.walmart.com/ip/great-value-chips/123456",
        upc="012345678901",
        gupc="",        # must always be ""
        ppm="$0.37/oz",
        unit_price="",  # must always be ""
        crawl_date=TODAY,
    )
    defaults.update(overrides)
    return ProductRecord(**defaults)


# ─── is_approx_weight ─────────────────────────────────────────────────────────

class TestIsApproxWeight:
    def test_approx_prefix(self):
        assert is_approx_weight("approx 3 oz") is True

    def test_approximately(self):
        assert is_approx_weight("approximately 1 lb") is True

    def test_approx_uppercase(self):
        assert is_approx_weight("APPROX 5 oz") is True

    def test_exact_weight(self):
        assert is_approx_weight("3 oz") is False

    def test_empty_string(self):
        assert is_approx_weight("") is False

    def test_no_match(self):
        assert is_approx_weight("16 fl oz") is False

    def test_word_boundary(self):
        # "approximately" embedded in another word should not match
        # e.g. "reapprox" doesn't exist but let's confirm word boundary works
        assert is_approx_weight("3 oz net wt") is False


# ─── ProductRecord.validate() ─────────────────────────────────────────────────

class TestProductRecordValidate:
    def test_valid_record_passes(self):
        record = _valid_record()
        errors = record.validate()
        assert errors == [], f"Expected no errors, got: {errors}"

    def test_gupc_must_be_empty(self):
        record = _valid_record(gupc="non-empty-gupc")
        errors = record.validate()
        assert any("gupc" in e for e in errors)

    def test_unit_price_must_be_empty(self):
        record = _valid_record(unit_price="$1.23")
        errors = record.validate()
        assert any("unit_price" in e for e in errors)

    def test_none_field_fails(self):
        record = _valid_record()
        record.store_name = None  # type: ignore
        errors = record.validate()
        assert any("None" in e or "store_name" in e for e in errors)

    def test_empty_product_title_fails(self):
        record = _valid_record(product_title="")
        errors = record.validate()
        assert any("product_title" in e for e in errors)

    def test_empty_url_fails(self):
        record = _valid_record(url="")
        errors = record.validate()
        assert any("url" in e for e in errors)

    def test_empty_crawl_date_fails(self):
        record = _valid_record(crawl_date="")
        errors = record.validate()
        assert any("crawl_date" in e for e in errors)

    def test_multiple_errors_returned(self):
        record = _valid_record(product_title="", url="", gupc="xyz")
        errors = record.validate()
        assert len(errors) >= 3


# ─── ProductRecord.to_dict() ──────────────────────────────────────────────────

class TestProductRecordToDict:
    EXPECTED_FIELDS = [
        "zipcode", "store_name", "store_location", "store_logo", "store_brand",
        "category", "sub_category", "product_title", "weight",
        "regular_price", "sale_price",
        "volume_deals_description", "volume_deals_price",
        "digital_deals_description", "digital_deals_price",
        "image_url", "url", "upc", "gupc", "ppm", "unit_price", "crawl_date",
    ]

    def test_returns_exactly_22_keys(self):
        record = _valid_record()
        d = record.to_dict()
        assert len(d) == 22

    def test_field_order_matches_spec(self):
        record = _valid_record()
        d = record.to_dict()
        assert list(d.keys()) == self.EXPECTED_FIELDS

    def test_returns_ordered_dict(self):
        record = _valid_record()
        d = record.to_dict()
        assert isinstance(d, OrderedDict)

    def test_values_are_strings(self):
        record = _valid_record()
        d = record.to_dict()
        for key, val in d.items():
            assert isinstance(val, str), f"Field '{key}' is not a str: {val!r}"


# ─── validate_batch() ─────────────────────────────────────────────────────────

class TestValidateBatch:
    def test_all_valid(self):
        records = [_valid_record(), _valid_record()]
        valid, invalid = validate_batch(records)
        assert len(valid) == 2
        assert invalid == []

    def test_all_invalid(self):
        records = [
            _valid_record(product_title=""),
            _valid_record(url=""),
        ]
        valid, invalid = validate_batch(records)
        assert valid == []
        assert len(invalid) == 2

    def test_mixed(self):
        records = [
            _valid_record(),
            _valid_record(product_title=""),
            _valid_record(),
            _valid_record(gupc="not-empty"),
        ]
        valid, invalid = validate_batch(records)
        assert len(valid) == 2
        assert len(invalid) == 2

    def test_invalid_tuple_structure(self):
        records = [_valid_record(url="")]
        valid, invalid = validate_batch(records)
        assert len(invalid) == 1
        record, errors = invalid[0]
        assert isinstance(record, ProductRecord)
        assert isinstance(errors, list)
        assert len(errors) > 0

    def test_empty_input(self):
        valid, invalid = validate_batch([])
        assert valid == []
        assert invalid == []
