"""tests/test_app.py — Tests for app.py localhost web application endpoints."""
import pytest
from aiohttp.test_utils import AioHTTPTestCase, unittest_run_loop
from app import create_app


class TestAppEndpoints(AioHTTPTestCase):
    async def get_application(self):
        import tempfile
        self.temp_db = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        return create_app(self.temp_db.name)

    async def test_index_dashboard(self):
        resp = await self.client.request("GET", "/")
        assert resp.status == 200
        text = await resp.text()
        assert "Walmart Product Scraper" in text
        assert "Collection Controls" in text

    async def test_health_check(self):
        resp = await self.client.request("GET", "/api/health")
        assert resp.status == 200
        data = await resp.json()
        assert data["status"] == "ok"

    async def test_readiness_endpoint(self):
        resp = await self.client.request("GET", "/api/readiness")
        assert resp.status == 200
        data = await resp.json()
        assert "adapters" in data
        assert len(data["adapters"]) == 3

    async def test_status_endpoint(self):
        resp = await self.client.request("GET", "/api/status")
        assert resp.status == 200
        data = await resp.json()
        assert "is_running" in data
        assert "stats" in data

    async def test_collection_and_csv_export(self):
        # Start collection with 5 test fixtures
        start_resp = await self.client.request(
            "POST",
            "/api/collection/start",
            json={"mode": "test_fixtures", "target_count": 5, "zipcode": "10001"}
        )
        assert start_resp.status == 200
        start_data = await start_resp.json()
        assert start_data["status"] == "started"

        # Wait briefly for background collection to complete
        import asyncio
        for _ in range(20):
            await asyncio.sleep(0.1)
            status_resp = await self.client.request("GET", "/api/status")
            s = await status_resp.json()
            if not s["is_running"]:
                break

        # Check records
        rec_resp = await self.client.request("GET", "/api/records")
        assert rec_resp.status == 200
        rec_data = await rec_resp.json()
        assert rec_data["total"] >= 5

        # Check CSV export
        csv_resp = await self.client.request("GET", "/api/export/csv?delimiter=;")
        assert csv_resp.status == 200
        csv_text = await csv_resp.text()
        first_line = csv_text.splitlines()[0]
        assert "zipcode;store_name;" in first_line

        # Reset
        reset_resp = await self.client.request("POST", "/api/reset")
        assert reset_resp.status == 200
        rec_after = await self.client.request("GET", "/api/records")
        data_after = await rec_after.json()
        assert data_after["total"] == 0

    async def test_walmart_api_config_endpoints(self):
        # 1. Get initial config (should be masked and unconfigured if no secrets exist)
        get_resp = await self.client.request("GET", "/api/config/walmart-api")
        assert get_resp.status == 200
        data = await get_resp.json()
        assert "integration_type" in data
        assert "status" in data
        assert "has_client_secret" in data

        # 2. Validation error on missing required fields for opd_retail
        bad_save = await self.client.request(
            "POST",
            "/api/config/walmart-api",
            json={"integration_type": "opd_retail", "client_id": "abc"}
        )
        assert bad_save.status == 400
        err_data = await bad_save.json()
        assert "Consumer ID" in err_data["error"]

        # 3. Successful save of valid OPD config
        good_save = await self.client.request(
            "POST",
            "/api/config/walmart-api",
            json={
                "integration_type": "opd_retail",
                "environment": "production",
                "consumer_id": "my-consumer-id-12345",
                "client_id": "my-client-id-67890",
                "client_secret": "my-secret-token-abcdef",
            }
        )
        assert good_save.status == 200
        saved_data = await good_save.json()
        assert saved_data["status"] == "saved"
        cfg = saved_data["config"]
        assert cfg["is_configured"] is True
        assert cfg["client_secret_masked"] == "••••••••••••"
        assert "my-secret-token-abcdef" not in str(saved_data)

        # 4. Clear config
        clear_resp = await self.client.request("POST", "/api/config/walmart-api/clear")
        assert clear_resp.status == 200
        cleared_data = await clear_resp.json()
        assert cleared_data["status"] == "cleared"
        assert cleared_data["config"]["is_configured"] is False
