"""tests/test_csv_export.py — Tests for 22-field CSV export, escaping, and store-specific deduplication."""
import io
import csv
import pytest
from core.store import StoreDB, FIELD_NAMES
from core.schema import ProductRecord


CLIENT_EXPECTED_HEADER = (
    "zipcode;store_name;store_location;store_logo;store_brand;category;sub_category;"
    "product_title;weight;regular_price;sale_price;volume_deals_description;"
    "volume_deals_price;digital_deals_description;digital_deals_price;image_url;"
    "url;upc;gupc;ppm;unit_price;crawl_date"
)


@pytest.fixture
def store_db(tmp_path):
    return StoreDB(tmp_path / "test_export.db")


class TestCsvExport:
    def test_exact_22_field_header(self, store_db):
        """Header must exactly match client requirement with semicolons."""
        csv_out = store_db.export_csv(delimiter=";")
        header_line = csv_out.splitlines()[0]
        assert header_line == CLIENT_EXPECTED_HEADER

    def test_delimiter_configurable_comma(self, store_db):
        """Delimiter can be configured to comma when requested."""
        csv_out = store_db.export_csv(delimiter=",")
        header_line = csv_out.splitlines()[0]
        assert header_line == ",".join(FIELD_NAMES)

    def test_preserves_leading_zeros(self, store_db):
        """Leading zeros in ZIP code and UPC must never be truncated or treated as numbers."""
        rec = {
            "zipcode": "07001",
            "store_name": "Walmart Avenel",
            "store_location": "123 Woodbridge Center",
            "store_logo": "",
            "store_brand": "Great Value",
            "category": "Grocery",
            "sub_category": "Snacks",
            "product_title": "Potato Chips",
            "weight": "8 oz",
            "regular_price": "$2.50",
            "sale_price": "",
            "volume_deals_description": "",
            "volume_deals_price": "",
            "digital_deals_description": "",
            "digital_deals_price": "",
            "image_url": "https://walmart.com/img.jpg",
            "url": "https://www.walmart.com/ip/chips/1001",
            "upc": "012345678901",
            "gupc": "",
            "ppm": "$0.31/oz",
            "unit_price": "",
            "crawl_date": "2026-10-25",
        }
        key = store_db._product_key(rec)
        store_db.upsert_product(key, "run_test", rec)

        csv_out = store_db.export_csv(delimiter=";")
        reader = csv.DictReader(io.StringIO(csv_out), delimiter=";")
        rows = list(reader)
        assert len(rows) == 1
        assert rows[0]["zipcode"] == "07001"
        assert rows[0]["upc"] == "012345678901"

    def test_escaping_semicolon_and_quotes(self, store_db):
        """Special characters (semicolons, quotes, newlines) must be properly quoted in CSV."""
        rec = {
            "zipcode": "10001",
            "store_name": "Walmart, Store; Supercenter \"Main\"",
            "store_location": "Suite 100\nBuilding B",
            "store_logo": "",
            "store_brand": "",
            "category": "Food; Beverage",
            "sub_category": "Snacks",
            "product_title": "Cookies; 12-Pack",
            "weight": "12 oz",
            "regular_price": "$3.00",
            "sale_price": "",
            "volume_deals_description": "",
            "volume_deals_price": "",
            "digital_deals_description": "",
            "digital_deals_price": "",
            "image_url": "https://walmart.com/img.jpg",
            "url": "https://www.walmart.com/ip/cookies/2002",
            "upc": "099999999999",
            "gupc": "",
            "ppm": "",
            "unit_price": "",
            "crawl_date": "2026-10-25",
        }
        key = store_db._product_key(rec)
        store_db.upsert_product(key, "run_test", rec)

        csv_out = store_db.export_csv(delimiter=";")
        reader = csv.DictReader(io.StringIO(csv_out), delimiter=";")
        rows = list(reader)
        assert len(rows) == 1
        assert rows[0]["store_name"] == 'Walmart, Store; Supercenter "Main"'
        assert rows[0]["product_title"] == "Cookies; 12-Pack"
        assert "Suite 100\nBuilding B" in rows[0]["store_location"]

    def test_missing_fields_are_empty_strings(self, store_db):
        """Missing fields must be empty string, never null or None."""
        rec = {
            "zipcode": "10001",
            "store_name": "Walmart",
            "product_title": "Minimal Product",
            "url": "https://www.walmart.com/ip/min/3003",
            "crawl_date": "2026-10-25",
        }
        key = store_db._product_key(rec)
        store_db.upsert_product(key, "run_test", rec)

        csv_out = store_db.export_csv(delimiter=";")
        reader = csv.DictReader(io.StringIO(csv_out), delimiter=";")
        rows = list(reader)
        assert len(rows) == 1
        assert rows[0]["sale_price"] == ""
        assert rows[0]["gupc"] == ""
        assert rows[0]["ppm"] == ""
        assert rows[0]["volume_deals_price"] == ""

    def test_store_specific_product_identity(self, store_db):
        """Same product URL at different ZIP codes must NOT overwrite each other."""
        rec_nyc = {
            "zipcode": "10001",
            "store_name": "Walmart Store NYC",
            "product_title": "Organic Milk",
            "regular_price": "$4.50",
            "url": "https://www.walmart.com/ip/milk/4004",
            "crawl_date": "2026-10-25",
        }
        rec_la = {
            "zipcode": "90210",
            "store_name": "Walmart Store LA",
            "product_title": "Organic Milk",
            "regular_price": "$5.25",  # Different price in LA
            "url": "https://www.walmart.com/ip/milk/4004",
            "crawl_date": "2026-10-25",
        }

        key_nyc = store_db._product_key(rec_nyc)
        key_la = store_db._product_key(rec_la)
        assert key_nyc != key_la, "Keys for different store locations must not collide"

        store_db.upsert_product(key_nyc, "run_nyc", rec_nyc)
        store_db.upsert_product(key_la, "run_la", rec_la)

        # Both records must be preserved with their distinct prices
        all_products = store_db.export_json()
        assert len(all_products) == 2
        prices = {p["zipcode"]: p["regular_price"] for p in all_products}
        assert prices["10001"] == "$4.50"
        assert prices["90210"] == "$5.25"

    def test_provenance_isolation(self, store_db):
        """Test records can be filtered from genuine live records."""
        rec_test = {
            "zipcode": "10001",
            "product_title": "Synthetic Test Item",
            "url": "https://www.walmart.com/ip/test/5005",
            "crawl_date": "2026-10-25",
        }
        rec_live = {
            "zipcode": "10001",
            "product_title": "Genuine Live Item",
            "url": "https://www.walmart.com/ip/live/6006",
            "crawl_date": "2026-10-25",
        }
        store_db.upsert_product("test:5005", "run_1", rec_test, is_test=1, data_source="test_fixtures")
        store_db.upsert_product("live:6006", "run_2", rec_live, is_test=0, data_source="live")

        test_only = store_db.export_json(is_test=1)
        live_only = store_db.export_json(is_test=0)
        assert len(test_only) == 1
        assert test_only[0]["product_title"] == "Synthetic Test Item"
        assert len(live_only) == 1
        assert live_only[0]["product_title"] == "Genuine Live Item"
