"""tests/test_store_selection.py
Regression tests for store selection, store verification, and location context.
"""
import asyncio
import pytest
from unittest.mock import AsyncMock, patch, MagicMock

from walmart.scraper import WalmartScraper
from core.walmart_api import WalmartApiManager, WalmartApiConfig


def test_unverified_store_selection_leaves_store_name_empty():
    async def _run():
        scraper = WalmartScraper(mode="simulated")

        mock_page = AsyncMock()
        mock_page.goto = AsyncMock()
        mock_page.close = AsyncMock()
        # Simulate store modal where zip code lookup fails
        mock_page.query_selector = AsyncMock(return_value=None)
        mock_page.wait_for_selector = AsyncMock(side_effect=Exception("Timeout waiting for store list"))

        scraper.new_page = AsyncMock(return_value=mock_page)
        scraper._detect_challenge = AsyncMock()
        scraper.polite_delay = MagicMock(return_value=0.001)

        store_info = await scraper.select_store("99999")

        # Crucial requirements:
        # 1. No fallback "Walmart Supercenter" label
        assert store_info["store_name"] == ""
        assert store_info["store_location"] == ""
        # 2. Marked as unverified
        assert store_info["is_store_verified"] is False
        assert store_info["fulfillment_type"] == "unverified"
        assert store_info["zipcode"] == "99999"

    asyncio.run(_run())


def test_scraped_product_uses_empty_store_name_when_unverified():
    async def _run():
        scraper = WalmartScraper(mode="simulated")

        unverified_store_info = {
            "store_name": "",
            "store_location": "",
            "store_logo": "",
            "zipcode": "10001",
            "is_store_verified": False,
            "fulfillment_type": "unverified",
        }

        mock_page = AsyncMock()
        mock_page.goto = AsyncMock()
        mock_page.close = AsyncMock()
        mock_page.query_selector = AsyncMock(return_value=None)

        ld_text = """{
          "@context": "https://schema.org",
          "@type": "Product",
          "name": "Unverified Store Product",
          "gtin12": "012345678905",
          "offers": {"@type": "Offer", "price": 4.99}
        }"""
        script_elem = AsyncMock()
        script_elem.inner_text = AsyncMock(return_value=ld_text)
        mock_page.query_selector_all = AsyncMock(return_value=[script_elem])

        scraper.new_page = AsyncMock(return_value=mock_page)
        scraper._detect_challenge = AsyncMock()
        scraper.polite_delay = MagicMock(return_value=0.001)

        rec = await scraper.scrape_product(
            url="https://walmart.com/ip/unverified/123",
            store_info=unverified_store_info,
            category="Grocery",
            sub_category="General",
            zipcode="10001",
        )

        assert rec is not None
        # Must not fabricate a store name
        assert rec.store_name == ""
        assert rec.store_location == ""
        assert rec.zipcode == "10001"

    asyncio.run(_run())


def test_walmart_api_never_passes_zip_as_store_id():
    mgr = WalmartApiManager()
    mgr._config = WalmartApiConfig(
        consumer_id="test_consumer",
        client_id="test_client_id",
        client_secret="test_client_secret",
        integration_type="opd_retail",
    )

    # When store lookup returns no resolved store ID, catalog URL must not contain storeId=zipcode
    resolved_store_id = ""
    if resolved_store_id:
        catalog_url = f"https://developer.api.walmart.com/api-service/engine/v1/search?query=grocery&storeId={resolved_store_id}"
    else:
        catalog_url = "https://developer.api.walmart.com/api-service/engine/v1/search?query=grocery"

    assert "storeId=90210" not in catalog_url
    assert "storeId=" not in catalog_url
