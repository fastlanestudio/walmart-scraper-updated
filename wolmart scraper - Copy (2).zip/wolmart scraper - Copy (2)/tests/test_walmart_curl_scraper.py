"""
tests/test_walmart_curl_scraper.py
Unit tests for curl_cffi + selectolax WalmartScraper architecture:
1. Embedded-JSON-first extraction path (__NEXT_DATA__, window.__INITIAL_STATE__, ld+json)
2. selectolax DOM parsing fallback for missing fields
3. Block and challenge detection BEFORE parsing (403, 429, PerimeterX px-captcha, title checks)
4. Proxy pool safe concurrency calculation, per-proxy pacing, and cooldown rotation
5. Approximate weight exclusion and DealKind classification
"""
import asyncio
import json
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from core.base_scraper import ChallengePage
from core.deal_classifier import DealKind
from core.schema import ProductRecord
from walmart.scraper import (
    WalmartScraper,
    ProxyPool,
    ProxySlot,
    check_response_for_challenge,
    _extract_embedded_json,
    _extract_product_from_json,
    _extract_missing_fields_via_selectolax,
    _extract_category_urls,
)

# ─── Fixture HTML Payloads ───────────────────────────────────────────────────

SAMPLE_NEXT_DATA_PRODUCT = {
    "props": {
        "pageProps": {
            "initialData": {
                "data": {
                    "product": {
                        "name": "Great Value Whole Milk, 1 Gallon, 128 fl oz",
                        "upc": "0078742351866",
                        "gtin": "00078742351866",
                        "brand": {"name": "Great Value"},
                        "priceInfo": {
                            "currentPrice": {"price": 3.48, "priceString": "$3.48"},
                            "wasPrice": {"price": 3.98, "priceString": "$3.98"},
                            "unitPrice": {"priceString": "$0.03/fl oz"},
                        },
                        "imageInfo": {
                            "thumbnailUrl": "https://i5.walmartimages.com/asr/milk_thumb.jpeg"
                        },
                        "weightIncrement": "1 gal",
                        "badges": {
                            "flags": [{"text": "Rollback"}]
                        },
                    }
                }
            }
        }
    }
}

NEXT_DATA_HTML_FIXTURE = f"""
<!DOCTYPE html>
<html>
<head><title>Great Value Whole Milk - Walmart.com</title></head>
<body>
<div id="__next">
  <script id="__NEXT_DATA__" type="application/json">
  {json.dumps(SAMPLE_NEXT_DATA_PRODUCT)}
  </script>
</div>
</body>
</html>
"""

SELECTOLAX_DOM_HTML_FIXTURE = """
<!DOCTYPE html>
<html>
<head><title>Equate Pain Reliever - Walmart.com</title></head>
<body>
  <h1 data-testid="product-title">Equate Extra Strength Acetaminophen, 500 mg, 100 Caplets</h1>
  <div data-testid="product-brand">Equate</div>
  <div class="price-section">
    <span data-testid="was-price">$6.48</span>
    <span data-testid="price-wrap">$4.98</span>
    <span data-testid="unit-price">$0.05/ct</span>
  </div>
  <span data-testid="product-weight">100 count</span>
  <div data-testid="product-spec-value" data-spec="wupc">0068113110051</div>
  <div data-testid="hero-image">
    <img src="https://i5.walmartimages.com/asr/equate.jpg" />
  </div>
  <div data-testid="promo-badge">Rollback</div>
</body>
</html>
"""

PERIMETERX_CAPTCHA_HTML_FIXTURE = """
<!DOCTYPE html>
<html>
<head>
  <title>Robot or human?</title>
  <script src="https://client.perimeterx.net/PX12345/main.min.js"></script>
</head>
<body>
  <div id="px-captcha-container">
    <div id="px-captcha"></div>
    <p>Press & Hold to confirm you are not a robot</p>
  </div>
</body>
</html>
"""

CATEGORY_NEXT_DATA_FIXTURE = json.dumps({
    "props": {
        "pageProps": {
            "initialData": {
                "searchResult": {
                    "itemStacks": [
                        {
                            "items": [
                                {"canonicalUrl": "/ip/Item-One/10001", "name": "Item 1"},
                                {"canonicalUrl": "/ip/Item-Two/10002", "name": "Item 2"},
                            ]
                        }
                    ]
                }
            }
        }
    }
})

CATEGORY_PAGE_HTML_FIXTURE = f"""
<!DOCTYPE html>
<html>
<body>
  <script id="__NEXT_DATA__" type="application/json">
  {CATEGORY_NEXT_DATA_FIXTURE}
  </script>
</body>
</html>
"""


# ─── 1. Embedded JSON First Tests ────────────────────────────────────────────

def test_embedded_next_data_extraction():
    """Verify embedded __NEXT_DATA__ is extracted without requiring DOM selector queries."""
    extracted_json = _extract_embedded_json(NEXT_DATA_HTML_FIXTURE)
    assert extracted_json is not None
    assert "props" in extracted_json

    fields = _extract_product_from_json(extracted_json)
    assert fields["product_title"] == "Great Value Whole Milk, 1 Gallon, 128 fl oz"
    assert fields["upc"] == "00078742351866" or fields["upc"] == "0078742351866"
    assert fields["brand"] == "Great Value"
    assert fields["regular_price"] == "$3.98"  # wasPrice
    assert fields["sale_price"] == "$3.48"     # currentPrice
    assert fields["ppm"] == "$0.03/fl oz"
    assert fields["image_url"] == "https://i5.walmartimages.com/asr/milk_thumb.jpeg"
    assert fields["promo_text"] == "Rollback"


def test_scrape_product_with_embedded_json():
    """Verify scrape_product successfully builds a validated ProductRecord from fixture HTML."""
    async def _run():
        scraper = WalmartScraper(mode="live")
        store_info = {
            "store_name": "Walmart Secaucus Supercenter",
            "store_location": "400 Park Pl, Secaucus, NJ",
            "store_logo": "https://walmart.com/logo.png",
        }
        record = await scraper.scrape_product(
            url="https://www.walmart.com/ip/milk/12345",
            store_info=store_info,
            category="Grocery",
            sub_category="Dairy",
            zipcode="10001",
            html=NEXT_DATA_HTML_FIXTURE,
        )

        assert record is not None
        assert isinstance(record, ProductRecord)
        assert record.product_title == "Great Value Whole Milk, 1 Gallon, 128 fl oz"
        assert record.store_brand == "Great Value"
        assert record.regular_price == "$3.98"
        assert record.sale_price == "$3.48"
        assert record.volume_deals_description != "" or record.sale_price != ""
        assert record.gupc == ""
        assert record.unit_price == ""
        # Schema validation
        assert record.validate() == []

    asyncio.run(_run())


# ─── 2. selectolax DOM Fallback Tests ────────────────────────────────────────

def test_selectolax_css_selector_fallback():
    """Verify that when embedded JSON is absent, selectolax C-backed parser extracts all DOM fields."""
    raw_fields = _extract_missing_fields_via_selectolax(SELECTOLAX_DOM_HTML_FIXTURE, {})

    assert raw_fields["product_title"] == "Equate Extra Strength Acetaminophen, 500 mg, 100 Caplets"
    assert raw_fields["brand"] == "Equate"
    assert raw_fields["regular_price"] == "$6.48"
    assert raw_fields["sale_price"] == "$4.98"
    assert raw_fields["ppm"] == "$0.05/ct"
    assert raw_fields["upc"] == "0068113110051"
    assert "equate.jpg" in raw_fields["image_url"]


def test_scrape_product_with_selectolax_fallback():
    """Verify scrape_product works end-to-end on pure DOM HTML via selectolax."""
    async def _run():
        scraper = WalmartScraper(mode="live")
        store_info = {"store_name": "Walmart", "store_location": "Secaucus"}
        record = await scraper.scrape_product(
            url="https://www.walmart.com/ip/equate-pain/54321",
            store_info=store_info,
            category="Health",
            sub_category="Pain Relief",
            zipcode="10001",
            html=SELECTOLAX_DOM_HTML_FIXTURE,
        )

        assert record is not None
        assert record.product_title == "Equate Extra Strength Acetaminophen, 500 mg, 100 Caplets"
        assert record.store_brand == "Equate"
        assert record.regular_price == "$6.48"
        assert record.sale_price == "$4.98"
        assert record.validate() == []

    asyncio.run(_run())


# ─── 3. Block & Challenge Detection BEFORE Parsing ───────────────────────────

def test_block_detection_on_status_codes():
    """HTTP 403 and 429 must immediately raise ChallengePage."""
    with pytest.raises(ChallengePage) as exc_403:
        check_response_for_challenge(403, "<html>Forbidden</html>", "https://walmart.com/ip/test")
    assert "HTTP 403" in str(exc_403.value)

    with pytest.raises(ChallengePage) as exc_429:
        check_response_for_challenge(429, "<html>Too Many Requests</html>", "https://walmart.com/ip/test")
    assert "HTTP 429" in str(exc_429.value)


def test_challenge_detection_on_html_signatures_with_http_200():
    """HTTP 200 with bot challenge HTML must be rejected as a failure and raise ChallengePage."""
    with pytest.raises(ChallengePage) as exc_px:
        check_response_for_challenge(200, PERIMETERX_CAPTCHA_HTML_FIXTURE, "https://walmart.com/ip/test")
    assert "Challenge" in str(exc_px.value)


def test_404_does_not_raise_challenge():
    """A standard 404 Not Found must NOT be flagged as a bot challenge."""
    # check_response_for_challenge should not raise for 404
    check_response_for_challenge(404, "<html>Page Not Found</html>", "https://walmart.com/ip/notfound")


# ─── 4. Safe Concurrency Formula & Proxy Pool ────────────────────────────────

def test_proxy_pool_concurrency_calculation():
    """Verify safe concurrency and safe RPM formulas are strictly derived from proxy count."""
    proxies = [
        "http://u1:p1@proxy1.example.com:8080",
        "http://u2:p2@proxy2.example.com:8080",
        "http://u3:p3@proxy3.example.com:8080",
        "http://u4:p4@proxy4.example.com:8080",
    ]
    pool = ProxyPool(
        proxy_urls=proxies,
        concurrency_per_proxy=1,
        max_rpm_per_proxy=6.0,
    )

    # 4 proxies * 1 in-flight = 4 max concurrent requests
    assert pool.total_safe_concurrency == 4
    # 4 proxies * 6.0 rpm = 24.0 req/min
    assert pool.total_safe_rpm == 24.0
    assert len(pool.slots) == 4

    # Each slot must possess its own dedicated Semaphore
    for slot in pool.slots:
        assert slot.semaphore._value == 1
        assert slot.min_interval == 10.0  # 60s / 6.0 rpm


def test_proxy_cooldown_and_alternate_rotation_on_challenge():
    """When a proxy triggers a challenge, it enters cooldown and retries route to an alternate proxy."""
    async def _run():
        proxies = [
            "http://proxy1.example.com:8080",
            "http://proxy2.example.com:8080",
        ]
        pool = ProxyPool(
            proxy_urls=proxies,
            cooldown_seconds=30.0,
        )

        slot1, slot2 = pool.slots[0], pool.slots[1]

        # Mock sessions on both slots
        mock_sess1 = AsyncMock()
        mock_resp1 = MagicMock(status_code=403, text="<html>Forbidden</html>")
        mock_sess1.get = AsyncMock(return_value=mock_resp1)
        slot1.session = mock_sess1

        mock_sess2 = AsyncMock()
        mock_resp2 = MagicMock(status_code=200, text="<html><title>Product</title>Valid</html>")
        mock_sess2.get = AsyncMock(return_value=mock_resp2)
        slot2.session = mock_sess2

        status, text = await pool.request("https://walmart.com/test", max_retries=2)

        # Slot 1 must be marked as cooling down
        assert slot1.is_cooling_down() is True
        assert slot1.consecutive_blocks == 1

        # Request succeeded through Slot 2
        assert status == 200
        assert "Valid" in text
        assert slot2.consecutive_blocks == 0

    asyncio.run(_run())


# ─── 5. Approximate Weight Exclusion ─────────────────────────────────────────

def test_approx_weight_product_excluded():
    """Products with variable/approximate weights must return None and increment stats."""
    async def _run():
        scraper = WalmartScraper(mode="live")
        store_info = {"store_name": "Walmart"}
        html_approx = """
        <html><body>
          <h1 data-testid="product-title">Fresh Bananas, approx 3 lbs</h1>
          <span data-testid="price-wrap">$1.78</span>
          <span data-testid="product-weight">approx 3 lbs</span>
        </body></html>
        """
        record = await scraper.scrape_product(
            url="https://walmart.com/ip/bananas/99",
            store_info=store_info,
            category="Produce",
            sub_category="Fruit",
            zipcode="10001",
            html=html_approx,
        )

        assert record is None
        assert scraper.stats.products_excluded_approx_weight == 1

    asyncio.run(_run())


# ─── 6. Category URLs Extraction ─────────────────────────────────────────────

def test_category_urls_extraction_from_next_data():
    """Verify category URLs are parsed directly from __NEXT_DATA__."""
    urls = _extract_category_urls(CATEGORY_PAGE_HTML_FIXTURE)
    assert len(urls) == 2
    assert "https://www.walmart.com/ip/Item-One/10001" in urls
    assert "https://www.walmart.com/ip/Item-Two/10002" in urls


def test_category_urls_extraction_from_selectolax():
    """Verify category URLs fall back to selectolax DOM parsing when __NEXT_DATA__ lacks item stacks."""
    html = """
    <html><body>
      <a href="/ip/Apple-iPhone-15/123456?variant=black">iPhone</a>
      <a href="/ip/Samsung-Galaxy/789012">Galaxy</a>
      <a href="/browse/phones">Phones</a>
    </body></html>
    """
    urls = _extract_category_urls(html)
    assert len(urls) == 2
    assert "https://www.walmart.com/ip/Apple-iPhone-15/123456" in urls
    assert "https://www.walmart.com/ip/Samsung-Galaxy/789012" in urls
