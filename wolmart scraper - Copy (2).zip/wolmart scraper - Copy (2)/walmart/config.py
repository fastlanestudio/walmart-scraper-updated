import csv
from pathlib import Path
from dataclasses import dataclass
from typing import Optional
import os


@dataclass
class CategoryEntry:
    category: str
    sub_category: str
    url: str


@dataclass
class ProxyConfig:
    host: str
    port: int
    username: str
    password: str

    def to_playwright_proxy(self) -> dict:
        return {
            "server": f"http://{self.host}:{self.port}",
            "username": self.username,
            "password": self.password,
        }


@dataclass
class WalmartConfig:
    store_zipcode: str
    categories: list[CategoryEntry]
    proxy: Optional[ProxyConfig]
    db_path: str
    checkpoint_path: str
    log_dir: str
    mode: str  # "live" or "simulated"
    canary_category_url: str = ""
    canary_min_items: int = 50


def load_category_urls(csv_path: str | Path) -> list[CategoryEntry]:
    """Load category entries from CSV. Supports comma or semicolon delimiter.

    Expects columns: category, sub_category, url.
    Strips whitespace from all values. Skips blank rows.
    Raises ValueError if required headers are missing.
    """
    entries: list[CategoryEntry] = []
    with open(csv_path, "r", newline="", encoding="utf-8-sig") as f:
        content = f.read()

    if not content.strip():
        raise ValueError("CSV file is empty")

    first_line = content.splitlines()[0]
    delimiter = ";" if ";" in first_line and first_line.count(";") >= first_line.count(",") else ","

    import io
    reader = csv.DictReader(io.StringIO(content), delimiter=delimiter)

    # Normalize headers: strip whitespace, lowercase
    if reader.fieldnames is None:
        raise ValueError("CSV file is empty")

    normalized = [h.strip().lower() for h in reader.fieldnames]
    required = {"category", "sub_category", "url"}
    missing = required - set(normalized)
    if missing:
        raise ValueError(
            f"CSV missing required columns: {missing}. Found: {reader.fieldnames}"
        )

    for row in reader:
        # Normalize keys too
        if not row:
            continue
        norm_row = {k.strip().lower(): v.strip() for k, v in row.items() if k}
        if not norm_row.get("category") or not norm_row.get("sub_category") or not norm_row.get("url"):
            continue  # Skip blank or incomplete rows

        entries.append(
            CategoryEntry(
                category=norm_row.get("category", ""),
                sub_category=norm_row.get("sub_category", ""),
                url=norm_row.get("url", ""),
            )
        )

    if not entries:
        raise ValueError("No valid category entries found in CSV")

    return entries


def load_proxy_from_env() -> Optional[ProxyConfig]:
    """Load proxy config from environment variables: PROXY_HOST, PROXY_PORT, PROXY_USER, PROXY_PASS.

    Returns None if PROXY_HOST is not set or PROXY_PORT is not a valid integer.
    """
    host = os.environ.get("PROXY_HOST", "")
    port_str = os.environ.get("PROXY_PORT", "")
    user = os.environ.get("PROXY_USER", "")
    password = os.environ.get("PROXY_PASS", "")

    if not host:
        return None

    try:
        port = int(port_str)
    except ValueError:
        return None

    return ProxyConfig(host=host, port=port, username=user, password=password)
