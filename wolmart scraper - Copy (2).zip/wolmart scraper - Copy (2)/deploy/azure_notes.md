# Azure Deployment Notes — Walmart Retail Scraper

## Recommended Azure Services

| Component | Azure Service | Notes |
|-----------|---------------|-------|
| Container runtime | Azure Container Instances (ACI) | Simplest for single-container jobs |
| Database | Azure File Share (mounted volume) | SQLite file mounted into container |
| Secrets | Azure Key Vault | Proxy credentials, connection strings |
| Scheduling | Azure Logic Apps or Azure Functions | Trigger scraper on a cron schedule |
| Monitoring | Azure Monitor + Log Analytics | Ingest the JSONL logs |
| Storage (output) | Azure Blob Storage | Upload export JSON after each run |

---

## Container Instances Deployment

### Build and push image

```bash
# Build
docker build -t walmart-scraper:latest -f deploy/Dockerfile .

# Tag for Azure Container Registry (ACR)
docker tag walmart-scraper:latest <acr-name>.azurecr.io/walmart-scraper:latest

# Push
az acr login --name <acr-name>
docker push <acr-name>.azurecr.io/walmart-scraper:latest
```

### Run on ACI

```bash
az container create \
  --resource-group <rg-name> \
  --name walmart-scraper-run \
  --image <acr-name>.azurecr.io/walmart-scraper:latest \
  --registry-login-server <acr-name>.azurecr.io \
  --registry-username <acr-username> \
  --registry-password <acr-password> \
  --cpu 2 \
  --memory 4 \
  --environment-variables \
    PROXY_HOST=<proxy-host> \
    PROXY_PORT=<proxy-port> \
    PROXY_USER=<proxy-user> \
    PROXY_PASS=<proxy-pass> \
  --command-line "python run.py --zipcode 10001 --csv /data/Walmart_Category_URLs.csv --db /data/walmart.db --checkpoint /data/checkpoint.json --log-dir /logs" \
  --azure-file-volume-account-name <storage-account> \
  --azure-file-volume-account-key <storage-key> \
  --azure-file-volume-share-name scraper-data \
  --azure-file-volume-mount-path /data \
  --restart-policy Never
```

---

## Secrets Management (Key Vault)

Store proxy credentials and any API keys in Azure Key Vault:

```bash
az keyvault secret set --vault-name <kv-name> --name PROXY-HOST --value "<host>"
az keyvault secret set --vault-name <kv-name> --name PROXY-PORT --value "<port>"
az keyvault secret set --vault-name <kv-name> --name PROXY-USER --value "<user>"
az keyvault secret set --vault-name <kv-name> --name PROXY-PASS --value "<pass>"
```

Use a Managed Identity on the ACI instance to retrieve secrets at runtime.

---

## Log Ingestion

The scraper writes JSONL logs to `<log-dir>/<run_id>.log.jsonl`.
Mount an Azure File Share at `/logs` and set up a Diagnostic Setting to push
log files to Log Analytics, or use Azure Monitor Agent to tail the JSONL files.

**Sample KQL query for blocked runs:**
```kusto
// Find runs where canary block was detected
union *
| where TimeGenerated > ago(7d)
| where RawData contains '"block_detected": true'
| project TimeGenerated, RawData
```

---

## Scheduling

Use an **Azure Logic App** with a Recurrence trigger to fire the scraper daily:

1. Recurrence trigger: daily at 06:00 UTC
2. Action: `Create or update container group` (ACI REST API)
3. After run completes: delete the container group to avoid idle billing

Alternatively, use **Azure Functions** (Timer trigger) to start the ACI job via
the Azure Management SDK.

---

## Cost Estimates (rough)

| Resource | Est. monthly cost |
|----------|-------------------|
| ACI (2 vCPU, 4 GB RAM, ~6 hrs/day) | ~\$15–\$30 USD |
| Azure File Share (10 GB) | ~\$1–\$2 USD |
| Log Analytics (1 GB/day) | ~\$3–\$5 USD |
| ACR (Basic tier) | ~\$5 USD |

Total: **~\$25–\$40/month** for daily scraping runs.

---

## Checklist Before First Live Run

- [ ] Proxy credentials stored in Key Vault
- [ ] `Walmart_Category_URLs.csv` uploaded to Azure File Share
- [ ] `select_store()` implemented (Phase 2)
- [ ] `iter_category_product_urls()` implemented (Phase 3)
- [ ] `scrape_product()` selectors filled in (Phases 4 & 5)
- [ ] Canary URL set and tested
- [ ] Test run with `--mode simulated` passes
- [ ] Log ingestion verified in Log Analytics
